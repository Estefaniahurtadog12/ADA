from sys import stdin

def flechas(puntAlcance, puntacion, flechasDispo, soluciones):
    #Si se alcanza la puntuación deseada, agregamos la secuencia de puntuacio a soluciones.
    if puntAlcance == 0:
        solu1(soluciones)
    else:
        resultado = puntAlcance
        # exploramos todas las posibles secuencias de puntuaciones que al sumar nos darian la cantidad que necesitamos
        actuSoluciones(resultado, puntacion, flechasDispo, soluciones)

#agrega la secuencia de puntuaciones actual a la lista de soluciones
def solu1(soluciones):
    if not soluciones[1]:
        soluciones[1] = list(soluciones[0])
    elif len(soluciones[1]) > len(soluciones[0]):
        soluciones[1] = list(soluciones[0])

# actualiza las soluciones mediante la exploracion de todas los casos posibles de las puntuaciones
def actuSoluciones(resultado, puntacion, flechasDispo, soluciones):
    i = flechasDispo - 1
    while i >= 0:
        if resultado >= int(puntacion[i]):
            if not soluciones[1]:
                Solu0(resultado, puntacion, i, soluciones)
            elif len(soluciones[0]) < len(soluciones[1]):
                Solu0(resultado, puntacion, i, soluciones)
        i -= 1
#todas las posibles secuencias de puntuaciones
def Solu0(resultado, puntacion, i, soluciones):
    temp = resultado - int(puntacion[i])
    soluciones[0].append(puntacion[i])
    flechas(temp, puntacion, i + 1, soluciones)
    soluciones[0].pop()

#lectura de datos 
def main():
    cantcasos = int(stdin.readline())
    for contador in range(1, cantcasos + 1):
        entrada = stdin.readline().split()
        n = int(entrada[0])
        s = int(entrada[1])
        p = list(map(int, stdin.readline().split()))
        soluciones = [[], []]
        flechas(s, p, n, soluciones)
        #orden descendente
        soluciones[1].sort(reverse=True) 
        if len(soluciones[1]) == 0:
            print(f'Case {contador}: impossible')
        else:
            soluciones_str = ' '.join(str(x) for x in soluciones[1])
            print(f'Case {contador}: [{len(soluciones[1])}] {soluciones_str}')
main()