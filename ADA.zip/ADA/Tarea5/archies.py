def minArrows(P, S, i, arrows, sol, minArrowsVal, bestSol):
    if S == 0:
        if arrows < minArrowsVal:
            bestSol.clear()
            bestSol.append(list(sol))
            return arrows
        elif arrows == minArrowsVal:
            bestSol.append(list(sol))
            return arrows
        else:
            return minArrowsVal
    elif i == len(P):
        return float('inf')
    elif S < 0:
        return float('inf')
    elif arrows >= minArrowsVal:
        return minArrowsVal
    else:
        for j in range(len(P)):
            sol.append(P[j])
            minArrowsVal = min(minArrowsVal, minArrows(P, S - P[j], j, arrows + 1, sol, minArrowsVal,bestSol))
            sol.pop()
        return minArrowsVal


T = int(input())
for t in range(1, T+1):
    N, S = map(int, input().split())
    P = list(map(int, input().split()))
    sol = []
    bestSol = []
    minArrowsSoFar = float('inf')
    arrows = minArrows(P, S, 0, 0, sol, minArrowsSoFar, bestSol)
    bestSolOfi = sorted(bestSol, reverse=True)
    if arrows == float('inf'):
        print("Case {}: impossible".format(t))
    else:
        bestSolOfi = ' '.join(map(str, sorted(bestSolOfi[0], reverse=True)))
        print("Case {}: [{}] {}".format(t, arrows, bestSolOfi))
