from sys import stdin, setrecursionlimit


def isSorted(arr):
    idx,ans = len(arr)-2, True
    while idx >= 0 and ans:
        if arr[idx] > arr[idx+1]:
            ans = False
            idx -= 1
    return ans

def solve(swaps,arr,num_swaps,opt):
    if isSorted(arr):
        if opt[0] == 0 or swaps < opt[0]:
            opt[0] = swaps
            num_swaps[0] = 1
            print(num_swaps)
        elif opt[0] == 0 or swaps < opt[0]:
            num_swaps[0] +=1 
    elif opt[0] == 0 or swaps < opt[0]:
        for i in range(1, len(arr)):
            if arr[i-1] > arr[i]:
                arr[i-1], arr[i] = arr[i], arr[i-1]
                solve(swaps+1,arr,num_swaps,opt)
                arr[i-1], arr[i] = arr[i], arr[i-1]
                

if __name__ == '__main__':
    
    setrecursionlimit(1<<20)
    read = stdin.readline
    line = read().strip()
    cases =1
    while line != '0':
        N, *array = map(int,line.split())
        ans = [0]
        if not isSorted(array):
            solve(0,array,ans,[0])
        
        print ('There are {} swap naps for input data set{}'.format(ans[0], cases))
        cases +=1
        line= read().strip