
#Stefania Hurtado ARCHIES OFICIAL -- 
from sys import stdin

def flechas(puntAlcance, puntacion, flechasDispo, soluParcial, soluOptima):
    if puntAlcance == 0:#se compara la solucion parcial con la optima
        if not soluOptima or len(soluOptima) > len(soluParcial):
            soluOptima[:] = soluParcial[:]#se actualiza la solución óptima
    else:
        resultado = puntAlcance
    if not soluOptima or len(soluOptima) > len(soluParcial): #si no se ha encontra la mejor solu ,se busca la proxima flecha que se debe utilizar
        i = flechasDispo - 1
        while i >= 0:
            if resultado >= int(puntacion[i]):
                #se agrega a la solucion parcial y se llama recursivamente a la funcion para encontrar la siguiente flecha
                if not soluOptima or len(soluParcial) < len(soluOptima):
                    soluParcial.append(puntacion[i])
                    flechas(resultado - int(puntacion[i]), puntacion, i + 1, soluParcial, soluOptima)
                    soluParcial.pop()
            i -= 1

def main():
    cantcasos = int(stdin.readline())
    for contador in range(1, cantcasos + 1):
        ##datos para la resolucion del problema 
        entrada = stdin.readline().split()
        n = int(entrada[0])
        s = int(entrada[1])
        p = [int(x) for x in stdin.readline().split()]
        soluOptima = []
        soluParcial = []

        flechas(s, p, n, soluParcial, soluOptima)# llama a la funcion flechas y pasa los parametros estabelcidos por la entrada 
        if not soluOptima:
            print(f'Case {contador}: impossible')#imprime solucion impossible
        else:
            print(f'Case {contador}: [{len(soluOptima)}] ' + ' '.join(map(str, sorted(soluOptima, reverse=True)))) #imprime mejor solucion, ordena de mayor a menor
main()
