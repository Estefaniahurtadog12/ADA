##arreglar esta!!!!!!!
import sys

def fle(p, s, i, flechas, sol, minflechaVal, solOpti):
    if s == 0: #flechas disponibles 
        return mejorSol(flechas, minflechaVal, solOpti, sol) #mejor solucion hasta el momento
    elif not(0 <= i < len(p)) or s < 0 or flechas >= minflechaVal or flechas + (s + max(p) - 1) // max(p) >= minflechaVal:
        return n+1 
    else:
        j = 0
        while j < len(p):
            sol.append(p[j])
            minflechaVal = min(minflechaVal, fle(p, s - p[j], j, flechas + 1, sol, minflechaVal,solOpti))
            sol.pop()
            j += 1
        return minflechaVal

def mejorSol(flechas, minflechaVal, solOpti, sol):
    if flechas <= minflechaVal:
        if flechas < minflechaVal:
            solOpti.clear()
        solOpti.append(list(sol))
        return flechas
    else:
        return minflechaVal


t = int(sys.stdin.readline())
case = 1
while case <= t:
    n, s = map(int, sys.stdin.readline().split())
    p = list(map(int, sys.stdin.readline().split()))
    sol = []
    solOpti = []
    fleSoFar = n + 1
    p.sort(reverse=True) # PARAASEGURAMOS QUE solOpti ESTE ORDENADO DE MAYOR A MENOR
    flechas = fle(p, s, 0, 0, sol, fleSoFar, solOpti)
    if flechas == n + 1:
        print("Case {}: impossible".format(case))
    else:
        print("Case {}: [{}] {}".format(case, flechas, ' '.join(map(str, solOpti[0]))))
    case += 1

        