
def mapping(cambios, arregloNum):
    global cantCombi, solOp
    if sorted(arregloNum) == arregloNum:
        if cambios == solOp:
            cantCombi += 1
        elif cambios < solOp:
            cantCombi = 1 if cambios > 0 else 0
            solOp = cambios
    else:
        i = 1
        while i < len(arregloNum):
            if arregloNum[i] < arregloNum[i - 1]:
                copiLista = intercambiar(arregloNum, i, i-1)
                mapping(cambios + 1, copiLista)
            i += 1
