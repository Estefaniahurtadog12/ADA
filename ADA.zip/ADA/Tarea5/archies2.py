def flechas(P, S, i, flecha, sol, minflechasVal, bestSol):
    if S == 0:
        if flecha <= minflechasVal:
            if flecha < minflechasVal:
                bestSol.clear()
            bestSol.append(list(sol))
            return flecha
        else:
            return minflechasVal
    elif i == len(P) or S < 0 or flecha >= minflechasVal:
        return N+1
    else:
        for j in range(len(P)):
            sol.append(P[j])
            minflechasVal = min(minflechasVal, flechas(P, S - P[j], j, flecha + 1, sol, minflechasVal,bestSol))
            sol.pop()
        return minflechasVal


T = int(input())
for t in range(1,T+1):
    N,S = map(int,input().split())
    P = list(map(int,input().split()))
    sol = []
    bestSol = []
    flechasSoFar = N+1
    flecha = flechas(P,S,0,0,sol,flechasSoFar,bestSol)
    bestSolOfi = sorted(bestSol , key=lambda x: tuple(x[::-1]), reverse=True)
    if flecha == N+1:
        print("Case {}: impossible".format(t))
    else:
        print("Case {}: [{}] {}".format(t ,flecha,' '.join(map(str,bestSolOfi[0][::-1]))))
