from sys import stdin

def textSegmentation5(S, P, N, sols, solsOpt):
    if S == 0:
        if not solsOpt or len(solsOpt) > len(sols):
            solsOpt[:] = sols[:]
    else:
        resultado = S
    if not solsOpt or len(solsOpt) > len(sols):
        i = N - 1
        while i >= 0:
            if resultado >= int(P[i]):
                sols.append(P[i])
                textSegmentation5(resultado - int(P[i]), P, i + 1, sols, solsOpt)
                sols.pop()
            i -= 1


def main():
    cases = int(stdin.readline())
    for cont in range(1, cases + 1):
        vals = stdin.readline().split()
        n, s = int(vals[0]), int(vals[1])
        p = [int(x) for x in stdin.readline().split()]
        solsOpt = []
        sols = []

        textSegmentation5(s, p, n, sols, solsOpt)
        # imprimen los datos correspondientes a la solución
        if not solsOpt:
            print(f'Case {cont}: impossible')
        else:
            print(f'Case {cont}: [{len(solsOpt)}] ' + ' '.join(map(str, sorted(solsOpt, reverse=True))))

main()
