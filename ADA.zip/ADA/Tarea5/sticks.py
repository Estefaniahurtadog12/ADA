import sys

def dfs(idx, st, total_sum, tm):
    global goal, m, n, flag, A, B, used
    if total_sum == goal:
        if tm+1 == m:
            return 1
        if dfs(0, 1, 0, tm+1):
            return 1
        return 0
    if st == 1:
        for i in range(n):
            if not used[i]:
                used[i] = 1
                if dfs(i+1, 0, A[i], tm):
                    return 1
                used[i] = 0
    else:
        for i in range(idx, n):
            if not used[i] and total_sum+A[i] <= goal and total_sum+B[i] >= goal:
                if not (i and A[i] == A[i-1] and not used[i-1]):
                    used[i] = 1
                    if dfs(i+1, 0, total_sum+A[i], tm):
                        return 1
                    used[i] = 0
                    if total_sum+A[i] == goal:
                        return 0
    return 0

while True:
    n = int(input())
    if n == 0:
        break
    A = list(map(int, input().split()))
    sum_A = sum(A)
    used = [0]*n
    A.sort(reverse=True)
    B = [0]*(n+1)
    for i in range(n-1, -1, -1):
        B[i] = B[i+1]+A[i]
    L = A[0]
    flag = 0
    for L in range(L, (sum_A//2)+1):
        if sum_A % L:
            continue
        goal = L
        m = sum_A//L
        flag = dfs(0, 1, 0, 0)
        if flag:
            break
    if not flag:
        goal = sum_A
    print(goal)
