import sys

#Intercambio de posiciones
def intercambiar(lista, i, j):
    copiLista = lista[:] # copia de la lista original
    copiLista[i], copiLista[j] = copiLista[j], copiLista[i]
    return copiLista

# cambios = numero cambios realizados , arregloNum= arreglo de numero que se haran los cambios

def mapping(cambios, arregloNum):
    global cantCombi, solOp
    if sorted(arregloNum) == arregloNum:
        if cambios == solOp:
            cantCombi += 1
        elif cambios < solOp:
            cantCombi = 1 if cambios > 0 else 0
            solOp = cambios
    else:
        i = 1
        while i < len(arregloNum):
            if arregloNum[i] < arregloNum[i - 1]:
                copiLista = intercambiar(arregloNum, i, i-1)
                mapping(cambios + 1, copiLista)
            i += 1


inputs = input().strip().split()  # Leer la primera línea de entrada
tc = 1
while inputs[0] != '0':
    n = int(inputs[0])
    listNum = list(map(int, inputs[1:]))  # Convertir los números cantCombitantes a enteros
    cantCombi, solOp = 0, sys.maxsize
    mapping(0, listNum)
    print(f"There are {cantCombi} swap maps for input data set {tc}.")
    tc += 1
    inputs = input().strip().split()  # Leer la siguiente línea de entrada

