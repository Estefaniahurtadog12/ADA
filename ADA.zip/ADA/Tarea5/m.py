import sys

def dfs(cnt, vec):
    global res, least
    sorted = True
    for i in range(1, len(vec)):
        if vec[i] < vec[i - 1]:
            sorted = False
            vec[i], vec[i - 1] = vec[i - 1], vec[i]
            dfs(cnt + 1, vec)
            vec[i], vec[i - 1] = vec[i - 1], vec[i]
    if sorted:
        if cnt and cnt == least:
            res += 1
        elif cnt < least:
            res = int(cnt > 0)
            least = cnt


if __name__ == "__main__":
    tc = 1
    for line in sys.stdin:
        inputs = line.strip().split()  # dividir la cadena de entrada en varios números
        n = int(inputs[0])
        if n == 0:
            break
        vec = list(map(int, inputs[1:]))  # convertir los números restantes a enteros
        res, least = 0, sys.maxsize
        dfs(0, vec)
        print(f"There are {res} swap maps for input data set {tc}.")
        tc += 1
