import math

def calDist(point1, point2):
    distX = point1[0] - point2[0]
    distY = point1[1] - point2[1]
    dist = math.sqrt(abs(distX * distX) + abs(distY * distY))
    return dist if dist != 0 else float('inf')

class UnionFind:
    def __init__(self, n):
        self.parent = list(range(n))
        self.rank = [0] * n

    def find(self, i):
        if self.parent[i] != i:
            self.parent[i] = self.find(self.parent[i])
        return self.parent[i]

    def union(self, i, j):
        root_i = self.find(i)
        root_j = self.find(j)
        if root_i == root_j:
            return False
        if self.rank[root_i] > self.rank[root_j]:
            self.parent[root_j] = root_i
        else:
            self.parent[root_i] = root_j
            if self.rank[root_i] == self.rank[root_j]:
                self.rank[root_j] += 1
        return True

def ejecucionProblema(points, receptores):
    edges = []
    n = len(points)
    for i in range(n):
        for j in range(i+1, n):
            weight = calDist(points[i], points[j])
            if weight != float('inf'):
                edges.append((weight, i, j))
    edges.sort()

    uf = UnionFind(n)
    count = n
    i = 0
    while count > receptores:
        w, u, v = edges[i]
        if uf.union(u, v):
            count -= 1
        i += 1

    print(math.ceil(edges[i-1][0]))

n_casos = int(input())

for caso in range(n_casos):
    receptores = int(input())
    points = []
    while True:
        entrada = input().split()
        if entrada[0] == '-1':
            break
        x, y = map(int, entrada)
        points.append((x, y))
    ejecucionProblema(points, receptores)
