
import math

def ejecucionProblema(points,receptores):
    
    selection_sort(points)
    points.append((math.inf,math.inf))
    #print(points);
    dicdistancia = {}
    dicminimos = {}
    lista1 = []
    for i in range(len(points)):
        dicdistancia[str(points[i])] = lista1
        dicminimos[str(points[i])] =math.inf
    dis = 0
    limstatemp =[]
    for i in range(1,len(points)):
        dis = math.inf
        limstatemp =[]
        for j in range(0,i):  
            if j<=i-1:
                dis = math.ceil(calDist(points[i-1],points[j]))
                limstatemp.append(dis)
                if dis<dicminimos[str(points[i-1])] and dis !=0:
                    dicminimos[str(points[i-1])]=dis
        
        dicdistancia[str(points[i-1])]= limstatemp
                    
    print(dicdistancia)
 
    dicminimos = {key: value for key, value in dicminimos.items() if value != math.inf}

    print("minimos:",dicminimos)
    n = 0

    listaPosResectores={}
    while n < receptores:
       maxminimo = max(dicminimos.values())
       n=n+1

   
       llave_max = max(dicminimos, key=lambda k: dicminimos[k])
       print("maxminimo:",maxminimo)
       listaPosResectores[str(llave_max)] =maxminimo
       del dicminimos[str(llave_max)]
 
   

    print("lista receptores",listaPosResectores)


    print("ECD:",min(listaPosResectores.values()))
    
        


def calDist(point1,point2):
    distX =point1[0]-point2[0];
    distY =point1[1]-point2[1];    
    return math.sqrt(abs(distX*distX)+abs(distY*distY))
def selection_sort(points):
    
    n = len(points)
    for i in range(n):
        min_idx = i
        for j in range(i+1, n):
            if points[j][0] < points[min_idx][0]:
                min_idx = j
        points[i], points[min_idx] = points[min_idx], points[i]
    #print(points)
    return points

#points=[(1,3),(2,9),(6,3),(5,4),(7,7),(8,5)]
receptores =2
#points=[(1,1),(8,7),(2,1)]
points=[(9750,6459),(9949,7740),(1113,7800)]
#points=[(9750, 6459), (9949, 7740), (1113, 7800)]
#points = [(6749, 272), (5950, 5845), (7496, 5292), (630, 1152), (6702, 6991), (162, 2131), (7721, 7610), (7838, 8235), (9986, 429), (1758, 3166), (4294, 107), (649, 4036), (7399, 2242), (9764, 8894), (1195, 6557), (2888, 841), (6484, 6342), (1428, 9135), (4945, 8746), (1254, 1382), (165, 4494), (1811, 8990), (2512, 5928), (1039, 3409), (6549, 7265), (7889, 5083), (3843, 2755), (6307, 4967), (984, 8158), (1129, 9419), (4430, 8404), (3003, 7279), (8722, 8155), (4198, 8628), (8296, 8294), (4338, 4337), (8236, 1712), (8583, 2160), (469, 7709), (7258, 2458), (9880, 3564), (7191, 4159), (3933, 2573), (1835, 8797), (9706, 3826), (4591, 6519), (3034, 3935), (1473, 9300), (6706, 9785), (5362, 2088), (22, 3940), (6462, 2918), (5850, 7628), (7062, 7336), (2769, 7032), (2506, 5970), (9945, 9742), (1491, 4155), (2478, 2493), (2511, 8336), (6861, 9567), (3056, 4565), (7125, 9291), (3208, 8068), (5055, 6937), (6356, 9680), (7036, 9075), (1437, 8697), (48, 4484), (2403, 5848), (8595, 4742), (6733, 4694), (7909, 6914), (9939, 5839), (3620, 4877), (3324, 3053), (3068, 5043), (6052, 8111), (1383, 3864), (3692, 7950), (3415, 4357), (3719, 2511), (9125, 9734), (9242, 6629), (946, 2875), (5130, 8865), (2377, 8528), (3356, 3862), (2299, 1715), (847, 2204), (1123, 8304), (282, 9022), (7917, 3426), (3905, 9816), (2130, 


ejecucionProblema(points,receptores)

'''2
9750 6459
9949 7740
1113 7800
-1
'''