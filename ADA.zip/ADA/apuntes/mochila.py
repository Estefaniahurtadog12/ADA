def phi(n,m,W,B):
    if n == 0 or m == 0:
        ans =0
    else:
        if W[n-1] <= m:
            ans = max(phi(n-1, m- W[n-1], W,B), phi(n-1),m)
        else:
            ans = phi(n-1,m)
    return ans

def phi(n,m,W,B,mem):
    if(n,m) in mem:
        ans = mem(n,m)
    else:
        if n == 0 or m ==0:
            ans = 0
        else:
            if W[n-1] <= m:
                ans = max(phi(n-1, m  - W[n-1],W, B, mem)+ phi(n-1),m,W,B,mem)
            else:
                ans = phi(n-1,m,W,B,mem)
        mem[(n,m)] = ans
    return ans

def tabular(M,W,B):
    N =len(W)
    tab = [[0 for _ in range(M+1)]] for _ in range (N+1)
    for n in range(1, N+1):
        for m in range(M + 1):
            if W[n-1]<= m:
                tab[1][m] = max(tab[0][m - W(n-1)] + B(n-1))

            else:
                tab[1][m] = tab[0][m]
        tab[0] =list(tab[1])
        return tab[1][M]


def tabular(M,W,B):
    N =len(W)
    tab = [[0 for _ in range(M+1)]] for _ in range (N+1)
    for n in range(1, N+1):
        for m in range(M + 1):
            if W[n-1]<= m:
                tab[n][m] = max(tab[n-1](m - W(n-1)) + B(n-1))

            else:
                tab[n][m] = tab[n-1][m]
        return tab[N][M]