
N = 0
longiMin = 10000000
result = 0
listaConstru = []
solOp = []


def backtracking(k):
    global N, longiMin, result, listaConstru, solOp
    if len(listaConstru) < longiMin:
        if k == N:
            longiMin = len(listaConstru)
            solOp.clear()
            i = 0
            while i < len(listaConstru):
                solOp.append(listaConstru[i])
                i += 1

        i = len(listaConstru) - 1
        while i >= 0:
            if k + listaConstru[i] <= N:
                listaConstru.append(k + listaConstru[i])
                backtracking(k + listaConstru[i])
                listaConstru.pop()
            i -= 1

N = int(input())
listaConstru.append(1)
backtracking(1)

print("chain : ", end="")
for i in range(len(solOp)):
    print(solOp[i], end=" ")
print("\nlength : ", len(solOp) - 1)
