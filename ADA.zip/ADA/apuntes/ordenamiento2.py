import math

def ejecucionProblema(points, receptores):
    selection_sort(points)
    points.append((math.inf, math.inf))
    dicdistancia = {}
    dicminimos = {}
    lista1 = []
    for i in range(len(points)):
        dicdistancia[str(points[i])] = lista1
        dicminimos[str(points[i])] = math.inf
    dis = 0
    limstatemp = []
    for i in range(1, len(points)):
        dis = float('inf')
        limstatemp = []
        for j in range(0, i):
            if j <= i-1:
                dist = calDist(points[i-1], points[j])
                if dist != float('inf'):
                    dis = math.ceil(dist)
                    limstatemp.append(dis)
                    if dis < dicminimos[str(points[i-1])] and dis != 0:
                        dicminimos[str(points[i-1])] = dis
        dicdistancia[str(points[i-1])] = limstatemp

    dicminimos = {key: value for key, value in dicminimos.items() if value != math.inf}

    n = 0
    listaPosResectores = {}
    while n < receptores:
        maxminimo = max(dicminimos.values())
        n += 1
        llave_max = max(dicminimos, key=lambda k: dicminimos[k])
        listaPosResectores[str(llave_max)] = maxminimo
        del dicminimos[str(llave_max)]

    print(min(listaPosResectores.values()))

def calDist(point1, point2):
    distX = point1[0] - point2[0]
    distY = point1[1] - point2[1]
    dist = math.sqrt(abs(distX * distX) + abs(distY * distY))
    return dist if dist != 0 else float('inf')

def selection_sort(points):
    n = len(points)
    for i in range(n):
        min_idx = i
        for j in range(i + 1, n):
            if points[j][0] < points[min_idx][0]:
                min_idx = j
        points[i], points[min_idx] = points[min_idx], points[i]
    return points

n_casos = int(input())

for caso in range(n_casos):
    receptores = int(input())
    points = []
    while True:
        entrada = input().split()
        if entrada[0] == '-1':
            break
        x, y = map(int, entrada)
        points.append((x, y))
    ejecucionProblema(points, receptores)
