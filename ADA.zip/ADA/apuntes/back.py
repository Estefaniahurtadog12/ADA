def texsegmetacion(n, S, D):
    if n == len(S):
        ans = True
    else:
        k = n + 1
        ans = False
        while k <= len(S) and not ans:
            if S[n:k] in D:
                ans = texsegmetacion(k,S,D)
            k + 1
    return ans    
cad = "ABAACAABDECABA"
d ={"ABAA", "ABAAC", "ABA", "ACA", "ACAABD","AABDE", "AAA","ECABA", "BA", "CCA", "ABDE", "CABA","BBA"}
print(texsegmetacion(0,cad,d))