import math

def distance(x1, y1, x2, y2):
    return math.sqrt((x1 - x2) ** 2 + (y1 - y2) ** 2)

def can_connect_with_ecd(sensors, ecd, receivers):
    graph = {i: [] for i in range(len(sensors))}
    for i in range(len(sensors)):
        for j in range(i+1, len(sensors)):
            if distance(*sensors[i], *sensors[j]) <= ecd:
                graph[i].append(j)
                graph[j].append(i)
    components = []
    visited = [False] * len(sensors)
    for i in range(len(sensors)):
        if not visited[i]:
            component = []
            queue = [i]
            visited[i] = True
            while queue:
                node = queue.pop(0)
                component.append(node)
                for neighbor in graph[node]:
                    if not visited[neighbor]:
                        queue.append(neighbor)
                        visited[neighbor] = True
            components.append(component)
    return len(components) <= receivers

def find_min_ecd(sensors, receivers):
    lo = 0
    hi = max(distance(*sensors[i], *sensors[j]) for i in range(len(sensors)) for j in range(i+1, len(sensors)))
    while lo < hi:
        mid = (lo + hi) // 2
        if can_connect_with_ecd(sensors, mid, receivers):
            hi = mid
        else:
            lo = mid + 1
    return math.ceil(hi)

# read input
t = int(input())
for _ in range(t):
    receivers = int(input())
    sensors = []
    while True:
        x, y = map(int, input().split())
        if x == -1:
            break
        sensors.append((x, y))
    print(find_min_ecd(sensors, receivers))
