
from math import inf

def subsetSum(arreglo, pesos, n, T, sumaActual, pesoActual, solution):
    if sumaActual == T:
        return pesoActual
    if n == 0:
        return -inf
    maxPeso = -inf
    i = 0
    while i < n:
        solution.append(arreglo[i])
        maxPeso = max(maxPeso, subsetSum(arreglo, pesos, i, T, sumaActual + arreglo[i], pesoActual + pesos[i], solution))
        solution.pop()
        i += 1
    return maxPeso


arreglo = [3,1,4,2,6]
pesos = [5,6,3,6,2]
n = len(arreglo)
T = 5
sumaActual = 0
pesoActual = 0
solution = []

maxPeso = subsetSum(arreglo, pesos, n, T, sumaActual, pesoActual, solution)

print("El máximo peso del subconjunto del arreglo cuyos elementos suman T es:", maxPeso)
