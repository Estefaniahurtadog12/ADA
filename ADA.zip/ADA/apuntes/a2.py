
from typing import List

nodosTotales = 0
contadorSubconjuntos = 0

def elemeEncontrados(A:List[int], size:int)->None:
    global contadorSubconjuntos
    contadorSubconjuntos += 1
    for i in range(size):
        print(A[i], end=' ')
    print()

def sumando(s:List[int], t:List[int], tamaconjuProblem:int, tamaSubConMome:int, sumaSubConMome:int, ite:int, sumaObjetivo:int)->None:
    global nodosTotales
    nodosTotales += 1

    if sumaObjetivo == sumaSubConMome:
        elemeEncontrados(t,tamaSubConMome)

        if ite + 1 < tamaconjuProblem and sumaSubConMome - s[ite] + s[ite + 1] <= sumaObjetivo:
            sumando(s, t, tamaconjuProblem, tamaSubConMome - 1, sumaSubConMome - s[ite], ite + 1, sumaObjetivo)
        return

    elif ite < tamaconjuProblem and sumaSubConMome + s[ite] <= sumaObjetivo:
        for i in range(ite, tamaconjuProblem):
            t[tamaSubConMome] = s[i]
            if sumaSubConMome + s[i] <= sumaObjetivo:
                sumando(s, t, tamaconjuProblem, tamaSubConMome + 1, sumaSubConMome + s[i], i + 1, sumaObjetivo)

def subconjun(s:List[int], size:int, sumaObjetivo:int)->None:
    t = [0]*size
    total = 0
    s = sorted(s)
    for i in range(size):
        total += s[i]
    if s[0] <= sumaObjetivo and total >= sumaObjetivo:
        sumando(s, t, size, 0, 0, 0, sumaObjetivo)

arre = [1,3,5,7,9]
T = 8
size = len(arre)
subconjun(arre,size,T)
print("nodos contruidos ",nodosTotales)
print("subconjuntos para la solucion:", contadorSubconjuntos)
