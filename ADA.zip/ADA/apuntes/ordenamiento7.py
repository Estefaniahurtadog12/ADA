from math import sqrt, ceil

class E:
    def __init__(self, a, b, c):
        self.x = a
        self.y = b
        self.v = c

def findp(x, p):
    if p[x] == x:
        return x
    p[x] = findp(p[x], p)
    return p[x]

def joint(x, y, rank, p):
    x = findp(x, p)
    y = findp(y, p)
    if x == y:
        return 0
    if rank[x] > rank[y]:
        rank[x] += rank[y]
        p[y] = x
    else:
        rank[y] += rank[x]
        p[x] = y
    return 1

testcase = int(input())
for t in range(testcase):
    n = int(input())
    m = 0
    x = [0]*1000
    y = [0]*1000
    while True:
        x[m], y[m] = map(int, input().split())
        if x[m] == -1:
            break
        m += 1

    D = [None]*1000000
    e = 0
    for i in range(m):
        for j in range(i+1, m):
            dist = (x[i]-x[j])*(x[i]-x[j]) + (y[i]-y[j])*(y[i]-y[j])
            D[e] = E(i, j, dist)
            e += 1

    D = sorted(D, key=lambda e: e.v)
    p = [i for i in range(1000)]
    rank = [1]*1000
    component = m
    for i in range(e):
        if joint(D[i].x, D[i].y, rank, p):
            component -= 1
        if component <= n:
            print(ceil(sqrt(D[i].v)))
            break
