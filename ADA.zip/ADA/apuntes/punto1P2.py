

def subconjunto_suma_mitad(A):
    total = sum(A)
    if total % 2 != 0:
        return False
    mitad = total // 2
    return backtracking(A, mitad, len(A)-1)

def backtracking(A, objetivo, i):
    if objetivo == 0:
        return True
    if i < 0 or objetivo < 0:
        return False
    incluir = backtracking(A, objetivo - A[i], i-1)
    excluir = backtracking(A, objetivo, i-1)
    return incluir or excluir

A = [2, 1,3,2,4]
resultado = subconjunto_suma_mitad(A)
print(resultado) # True

B = [2, 1, 5]
resultado = subconjunto_suma_mitad(B)
print(resultado) # False


