import heapq

import heapq


def dijkstra(a, b, c, d):
    # create a list of all possible volumes in the jugs
    volumes = set()
    for i in range(a + 1):
        for j in range(b + 1):
            volumes.add(i * c + j * (c - i))

    # initialize distances and closest values for each volume
    dist = {v: float('inf') for v in volumes}
    closest = float('inf')
    dist[c] = 0

    # initialize the heap with the starting volume
    heap = [(0, c)]

    # run Dijkstra's algorithm
    while heap:
        d1, v1 = heapq.heappop(heap)
        if d1 > dist[v1]:
            continue
        if abs(v1 - d) < abs(closest - d):
            closest = v1
        for v2 in volumes:
            d2 = d1 + abs(v1 - v2)
            if d2 < dist[v2]:
                dist[v2] = d2
                heapq.heappush(heap, (d2, v2))

    return dist[closest], closest


# leer la entrada y procesar cada caso de prueba
# leer la entrada y procesar cada caso de prueba
t = int(input())
for _ in range(t):
    a, b, c, d = map(int, input().split())
    dist, closest = dijkstra(a, b, c, d)
    print(dist, closest)

