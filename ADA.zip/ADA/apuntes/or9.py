import sys
import math

nPadre = []
registro = []

def calDist(point1, point2):
    #formula de la distancia euclidiana "sqrt.(x^2 + y^2)""
    #point1 (coordenada x) point2(coordenaday)
    distX = point1[0] - point2[0]
    distY = point1[1] - point2[1]
    return math.sqrt(abs(distX*distX)+abs(distY*distY))

#funcion findset profe clase kruskal
def encontrar(i):
    ans = None
    if i == nPadre[i]:
        ans = i
    else:
        nPadre[i] = encontrar(nPadre[i])
        ans = nPadre[i]
    return ans

#funcion unionset clase krukal
def kruskal(i, j):
    raizI = encontrar(i)
    raizJ = encontrar(j)
    if raizI == raizJ:
        return False
    nPadre[raizJ] = raizI
    return True

def ejecucionProblema(points, receptores):
    global nPadre, registro
    listaDistancia = [] #aristas del grafo -- las calculo segun la distancia del sensor
    n = len(points)
    #inicia un bucle que recorre todos los indices i desde 0 hasta n-1
    for i in range(n):
        for j in range(i+1, n):
            peso = calDist(points[i], points[j])
             #Si la distancia entre los puntos es finita (es decir, si no son el mismo punto).
            if peso != math.inf:
                listaDistancia.append((peso, i, j))#Agrega tres elementos a la lista listaDistancia,
                #el primer elemento es la distancia entre los puntos i y j, y los otros dos elementos son los indices i y j.
    listaDistancia.sort() #ordenamos la tupla
    
    conta = n
    nPadre = list(range(n))
    registro = [0] * n
    i = 0
    terminado = False
    while i < len(listaDistancia) and not terminado:
        w, u, v = listaDistancia[i]
        conta -= 1 if kruskal(u, v) else 0
        dista = math.ceil(w) if conta <= receptores else None
        terminado = dista is not None
        i += 1
    print(dista)

#lectura de la entrada 
casos = int(sys.stdin.readline())
for caso in range(casos):
    receptores = int(sys.stdin.readline())
    points = []
    entrada = sys.stdin.readline().strip()
    while entrada != '-1':
        x, y = map(int, entrada.split())
        points.append((x, y))
        entrada = sys.stdin.readline().strip()
    ejecucionProblema(points, receptores)