/*Seleccionar los títulos y directores de las películas del año 2000 o posterior*/
db.collection.find({
    YearP: {
      $gte: 2000
    }
  },
  {
    Title: 1,
    Director: 1
  })

/*Seleccionar los actores, el título y los datos de imdb de las películas con unimdbRating mayor que 8.1*/
  db.collection.find({
    "imdb.imdbRating": {
      $gt: 8.1
    }
  },
  {
    titulo: 1,
    actores: 1,
    imdbRating: 1,
    "imdb.imdbRating": 1
  })

/*Seleccionar el título, el país y los lenguajes de las películas que tienen registrados como lenguajes English y French*/
db.collection.find({
    Languages: {
      $all: [
        "English",
        "French"
      ]
    }
  },
  {
    Title: 1,
    Country: 1,
    Languages: 1
  })

/*Seleccionar el título y el género de las películas en las que Steven Spielberg contribuyó con el screenplay*/
db.collection.find({
    Writers: {
      $elemMatch: {
        name: "Steven Spielberg",
        contribution: "screenplay"
      }
    }
  },
  {
    Title: 1,
    Genre: 1,
    _id: 0
  })

/*Listar el título de las películas cuyo país es USA*/
db.collection.aggregate([
    {
      $match: {
        Country: "USA"
      }
    },
    {
      $sort: {
        Title: 1
      }
    },
    {
      $project: {
        _id: 0,
        Title: 1
      }
    }
  ])
/*Calcular los puntos imdb de cada una de las películas las películas cuyo país es USA (los puntos se calculan multiplicando el rating por los votos)*/
db.collection.aggregate([
    {
      $match: {
        Country: "USA"
      }
    },
    {
      $project: {
        _id: 0,
        Title: 1,
        imdbPuntos: {
          $multiply: [
            "$imdb.imdbRating",
            "$imdb.imdbVotes"
          ]
        }
      }
    }
  ])

/*Para cada país, calcule el promedio del metascore de las películas de ese país*/
db.collection.aggregate([
    {
      $group: {
        _id: "$Country",
        avgMetaScore: {
          $avg: "$Metascore"
        }
      }
    }
  ])

/*Para cada país, calcule el promedio del metascore y la cantidad de las películas de ese país*/
db.collection.aggregate([
    {
      $group: {
        _id: "$Country",
        avgMetaScore: {
          $avg: "$Metascore"
        },
        nro: {
          $sum: 1
        }
      }
    }
  ])

/*Agregar el atributo Website a la película Blade Runner*/
db.collection.update({
    Title: "Blade Runner"
  },
  {
    $set: {
      Website: "https://www.bladerunnermovie.com"
    }
  })