#puntoOFICIAL BUG SENSOR!!
#Stefania Hurtado Gonzalez 
import sys
import math


def ejecucionProblema(points, receptores):
    listaDistancia = [] #aristas del grafo -- las calculo segun la distancia del sensor
    n = len(points)
    #inicia un bucle que recorre todos los indices i desde 0 hasta n-1
    for i in range(n):
        for j in range(i+1, n):
            peso = calDist(points[i], points[j]) #calcula la distancia entre los puntos i y j
            #Si la distancia entre los puntos es finita (es decir, si no son el mismo punto).
            if peso != math.inf:
                listaDistancia.append((peso, i, j))#Agrega tres elementos a la lista listaDistancia,
                #el primer elemento es la distancia entre los puntos i y j, y los otros dos elementos son los índices i y j.
    listaDistancia.sort() #ordena la tupla

    nPadre = list(range(n))
    registro = [0] * n
    conta = n
    i = 0
    while conta > receptores:
        w, u, v = listaDistancia[i]
        if unionset(nPadre, registro, u, v):
            conta -= 1
        i += 1
        dista = math.ceil(listaDistancia[i-1][0])
    print(dista)

def calDist(point1, point2):
    #formula de la distancia euclidiana "sqrt.(x^2 + y^2)""
    #point1 (coordenada x) point2(coordenaday)
    distX = point1[0] - point2[0]
    distY = point1[1] - point2[1]
    return math.sqrt(abs(distX*distX)+abs(distY*distY))

#pertencen al mismo conjunto 

class DisjointSet:
    def __init__(self, nPadre):
        self.nPadre = nPadre

    def findset(self, i):
        # encontrar la raíz del conjunto que contiene i
        raiz = i
        while self.nPadre[raiz] != raiz:
            raiz = self.nPadre[raiz]
        # actualizar el padre de los nodos en el camino de i a la raíz
        while self.nPadre[i] != raiz:
            i, self.nPadre[i] = self.nPadre[i], raiz
        return raiz

    def unionset(self, registro, i, j):
        # se encuentra la raíz de cada elemento i y j utilizando la función findset
        raizI = self.findset(i)
        raizJ = self.findset(j)
        # si ya estan en el mismo conjunto, se devuelve False
        if raizI == raizJ:
            return False
        # se actualiza el padre del conjunto y el registro de la raiz
        if registro[raizI] < registro[raizJ]:
            self.nPadre[raizI] = raizJ
        elif registro[raizI] > registro[raizJ]:
            self.nPadre[raizJ] = raizI
        else:
            self.nPadre[raizI] = raizJ
            registro[raizJ] += 1
        # se devuelve True para indicar que se ha unido un nuevo conjunto
        return True
 



#lectura de la entrada 
casos = int(sys.stdin.readline())
for caso in range(casos):
    receptores = int(sys.stdin.readline())
    points = []
    entrada = sys.stdin.readline().strip()
    while entrada != '-1':
        x, y = map(int, entrada.split())
        points.append((x, y))
        entrada = sys.stdin.readline().strip()
    ejecucionProblema(points, receptores)

