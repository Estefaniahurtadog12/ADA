def cirugia(n,t,A):
    ans = None
    if n == 0:
        return 0
    elif cirguia(n-1,t):
        if n != 0 and A[n-1][1] > t:
            return 0
    else:
        cirguia((n-1, A[n][0]))

A = 1 A = [ (0, 14), (16, 24), (29, 31),
2 (2, 6), (9, 17), (22, 30),
3 (6, 10), (15, 20), (24, 32),
4 (2, 9), (11, 15), (16, 23), (24, 28) ]
A.sort(key = lambda x: x[1])