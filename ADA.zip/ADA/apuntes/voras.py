def actividades(A):
    A.sort(key = lambda x: x[1]) #ordena segun el primer criterio 
    ans, n, N, t = 0, 0, len(A), 0
    lans = []
    while n != N:
        if A[n][0] >= t:
            ans += 1
            t += A[n][1]
            lans.append(A[n])
        n += 1
        #print(lans)
    return lans   

def phi(n, t, A):
    ans = 0
    if n == len(A):
        ans = 0
    else:
        if A[n][0] >= t:
            ans = 1 + phi(n+1, A[n][1], A)
        else:
            ans = phi(n+1, t, A)
            
    return ans


Act = [(3,6),(1,4),(2,4),(0,3),(3,7),(2,5),(1,3),(6,9),(4,7),(2,6)]
print(actividades(Act))
