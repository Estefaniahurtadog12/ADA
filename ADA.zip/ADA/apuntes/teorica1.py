def ultimaFinali(cursos):
    finalizacionUltima = float('-inf')
    seleccionarCurso = None
    for curso in cursos:
        if curso['fin'] > finalizacionUltima:
            finalizacionUltima = curso['fin']
            seleccionarCurso = curso
    return seleccionarCurso

def ultimaInicio(cursos):
    inicioUltima = float('-inf')
    seleccionarCurso = None
    for curso in cursos:
        if curso['inicio'] > inicioUltima:
            inicioUltima = curso['inicio']
            seleccionarCurso = curso
    return seleccionarCurso

def menosConflic(cursos):
    conflicmenor = float('inf')
    seleccionarCurso = None
    for curso in cursos:
        conflictos = len([c for c in cursos if c['inicio'] < curso['fin'] and c['fin'] > curso['inicio']])
        if conflictos < conflicmenor:
            conflicmenor = conflictos
            seleccionarCurso = curso
    return seleccionarCurso

def masConflic(cursos):
    conflicmayor = float('-inf')
    seleccionarCurso = None
    for curso in cursos:
        conflictos = len([c for c in cursos if c['inicio'] < curso['fin'] and c['fin'] > curso['inicio']])
        if conflictos > conflicmayor:
            conflicmayor = conflictos
            seleccionarCurso = curso
    return seleccionarCurso

def prograCursos(cursos, select_func):
    programacion = []
    while cursos:
        seleccionarCurso = select_func(cursos)
        if seleccionarCurso is None:
            break
        programacion.append(seleccionarCurso)
        cursos = [c for c in cursos if c['fin'] <= seleccionarCurso['inicio']]
    return programacion

cursos = [
    {'id': 'A', 'inicio': 8, 'fin': 9, 'dura': 1},
    {'id': 'B', 'inicio': 9, 'fin': 11, 'dura': 2},
    {'id': 'C', 'inicio': 10, 'fin': 13, 'dura': 3},
    {'id': 'D', 'inicio': 12, 'fin': 14, 'dura': 2},
    {'id': 'E', 'inicio': 14, 'fin': 15, 'dura': 1}
]

resulA = prograCursos(cursos, ultimaFinali)
resulC = prograCursos(cursos, ultimaInicio)
resulE = prograCursos(cursos, menosConflic)
resulG = prograCursos(cursos, masConflic)

print("Resultado a): ", [c['id'] for c in resulA])
print("Resultado c): ", [c['id'] for c in resulC])
print("Resultado e): ", [c['id'] for c in resulE])
print("Resultado g): ", [c['id'] for c in resulG])
