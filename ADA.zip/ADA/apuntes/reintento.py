sols = []
flag = False

def solve(n,sol,N):
    global flag
    if n == N:
        print(sol)
        sols.append(sol)
    else:
        for f in range(N):
            if check(sol,n,f):
                sol[n] = f
                solve(sol, n+ 1 , N)
def check(sol, n, f):
    ans, i = True, 0
    while ans and i < n:
        ans = sol[i] != f and sol[i] != f - n + i
        i += 1
    return ans
N=10
q = [-1 for _ in range(N)]
solve(q,0,N)

for i in range(len(sols)):
    print(*sols[i])
