from typing import List

nodosTotales = 0
contadorSubconjuntos = 0

def elemeEncontrados(A:List[int], size:int)->None:
#elementos encontrados de un subconjunto,actualiza contador de subconjuntos
    global contadorSubconjuntos
    contadorSubconjuntos += 1
    for i in range(size):
        print(A[i], end=' ')
    print()

def sumando(s:List[int], t:List[int], tamaconjuProblem:int, tamaSubConMome:int, sumaSubConMome:int, ite:int, sumaObjetivo:int)->None:
    #encontrar subconjuntos de s que sumen sumaObjetivo
    global nodosTotales
    nodosTotales += 1

    #suma actual del subconjunto igual a objetivo = elementos encontrados
    if sumaObjetivo == sumaSubConMome:
        elemeEncontrados(t, tamaSubConMome)

        # elementos por evaluar y se cumple la condición
        if ite + 1 < tamaconjuProblem and sumaSubConMome - s[ite] + s[ite + 1] <= sumaObjetivo:
            sumando(s, t, tamaconjuProblem, tamaSubConMome - 1, sumaSubConMome - s[ite], ite + 1, sumaObjetivo)
        return

    elif ite < tamaconjuProblem and sumaSubConMome + s[ite] <= sumaObjetivo:
        i = ite
        while i < tamaconjuProblem:
            t[tamaSubConMome] = s[i]
            # si se puede agregar elementos al subconjunto y la suma actual del subconjunto ms el elemento siguiente es menor o igual al objetivo
            if sumaSubConMome + s[i] <= sumaObjetivo:
                sumando(s, t, tamaconjuProblem, tamaSubConMome + 1, sumaSubConMome + s[i], i + 1, sumaObjetivo)
            i += 1

def subconjun(s:List[int], size:int, sumaObjetivo:int)->None:
    t = [0]*size
    total = 0
    s = sorted(s)
    i = 0
    while i < size:
        total += s[i]
        i += 1
    if s[0] <= sumaObjetivo and total >= sumaObjetivo:
        sumando(s, t, size, 0, 0, 0, sumaObjetivo)


arre = [1,3,5,7,9]
T = 8
size = len(arre)
subconjun(arre,size,T)

print("nodos contruidos ",nodosTotales)
print("subconjuntos para la solucion:", contadorSubconjuntos)
