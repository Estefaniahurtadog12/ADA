#Stefania Hurtado Gonzalez 
#sensores 
import sys
import numpy
def calDist(point1, point2):
    #formula de la distancia euclidiana
    #point1 (coordenada x) point2(coordenaday)
    distX = point1[0] - point2[0]
    distY = point1[1] - point2[1]
    dist = ((distX * distX) + (distY * distY)) ** 0.5
    #distancia = 0, retorna infinito para evitar divisiones por cero
    return dist if dist != 0 else float('inf')

def encontrar(nPadre, i):
    #encontrar la raiz de un conjunto de elementos
    if nPadre[i] != i:
        #si el elemento no es su propia raíz, se actualiza su padre
        nPadre[i] = encontrar(nPadre, nPadre[i])
    #devuelve la raiz del conjunto
    return nPadre[i]

def union(nPadre, rango, i, j):
    #se encuentra la raiz de cada elemento i y j utilizando la función encontrar
    raizI = encontrar(nPadre, i)
    raizJ = encontrar(nPadre, j)
    #si se encuentra en el mismo conjunto devuelve false
    if raizI == raizJ:
        return False
    #si no esta en el conjunto, se actualiza el nodo padre y el rango de la raiz y devuelve true
    if rango[raizI] > rango[raizJ]:
        nPadre[raizJ] = raizI
    else:
        nPadre[raizI] = raizJ
        if rango[raizI] == rango[raizJ]:
            rango[raizJ] += 1
    return True

def ejecucionProblema(points, receptores):
    edges = [] #aristas del grafo
    n = len(points)
    #inicia un bucle que recorre todos los índices i desde 0 hasta n-1
    for i in range(n):
        for j in range(i+1, n):
            peso = calDist(points[i], points[j]) #calcula la distancia entre los puntos i y j
            #Si la distancia entre los puntos es finita (es decir, si no son el mismo punto).
            if peso != float('inf'):
                edges.append((peso, i, j))#Agrega tres elementos a la lista edges,
                #el primer elemento es la distancia entre los puntos i y j, y los otros dos elementos son los índices i y j.
    edges.sort() #ordena la tupla

    nPadre = list(range(n))
    rango = [0] * n
    conta = n
    i = 0
    while conta > receptores:
        w, u, v = edges[i]
        if union(nPadre, rango, u, v):
            conta -= 1
        i += 1
    #print(int(edges[i-1][0]+0.5)) #--- diferencia de un punto  (toca redondear el numero si es decimal)
    print(round(edges[i-1][0] + 0.5))

#lectura de la entrada 
casos = int(input())
for caso in range(casos):
    receptores = int(input())
    points = []
    while True:
        entrada = input().split()
        if entrada[0] == '-1':
            break
        x, y = map(int, entrada)
        points.append((x, y))
    ejecucionProblema(points, receptores)
