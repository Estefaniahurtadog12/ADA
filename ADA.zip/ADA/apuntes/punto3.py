
def seleccion_actividades(actividades):
    actividades_ordenadas = sorted(actividades, key=lambda x: x[1] - x[0])
    seleccionadas = []
    fin = -1
    for actividad in actividades_ordenadas:
        if actividad[0] >= fin:
            seleccionadas.append(actividad)
            fin = actividad[1]
    return seleccionadas

actividades = [(0, 10), (1, 3), (4, 6)]
resultado = seleccion_actividades(actividades)
print(resultado) # [(1, 3)]
