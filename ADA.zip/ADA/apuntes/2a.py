
sols = []
def textSegmentation4(n, sol, S, D):
    global sols
    if n == len(S):
        sols.append(list(sol))
    else:
        k = n + 1
        while k <= len(S):
            if S[n:k] in D:
                sol.append(k - 1)
                textSegmentation4(k, sol, S, D)
                sol.pop()
            k += 1

S = 'ABAACAABDECABA'
D = {'ACA', 'ACAABD', 'AABDE', 'AAA', 'CCA', 'ABDE', 'CABA', 'BBA', 'ABAA', 'ABAAC', 'ABA', 'ECABA','BA'}
textSegmentation4(0, [], S, D)
print("El número de particiones de S en palabras es:", len(sols))
