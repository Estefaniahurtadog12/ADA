import matplotlib.pyplot as plt

# Define las entidades
paciente = plt.Rectangle((0, 0), 3, 1, fc="white")
habitacion = plt.Rectangle((0, 2), 3, 1, fc="white")
hospitalizacion = plt.Rectangle((4, 1), 3, 1, fc="white")
personal_medico = plt.Rectangle((8, 0), 3, 1, fc="white")

# Define las relaciones
relacion1 = plt.Polygon([[3, 0.5], [4, 1.5], [4, 0.5]], closed=True, fc="white", ec="black")
relacion2 = plt.Polygon([[3, 2.5], [4, 1.5], [4, 2.5]], closed=True, fc="white", ec="black")
relacion3 = plt.Polygon([[7, 1.5], [8, 0.5], [8, 1.5]], closed=True, fc="white", ec="black")
relacion4 = plt.Polygon([[4, 1.5], [7, 1.5]], closed=True, fc="white", ec="black")

# Dibuja las entidades y relaciones
plt.gca().add_patch(paciente)
plt.gca().add_patch(habitacion)
plt.gca().add_patch(hospitalizacion)
plt.gca().add_patch(personal_medico)
plt.gca().add_patch(relacion1)
plt.gca().add_patch(relacion2)
plt.gca().add_patch(relacion3)
plt.gca().add_patch(relacion4)

# Agrega las etiquetas
plt.text(1.5, 0.5, "Paciente", ha="center", va="center")
plt.text(1.5, 2.5, "Habitación", ha="center", va="center")
plt.text(5.5, 1.5, "Hospitalización", ha="center", va="center")
plt.text(9.5, 0.5, "Personal médico", ha="center", va="center")

# Agrega las etiquetas de las relaciones
plt.text(3.5, 1, "Tiene", ha="center", va="center")
plt.text(3.5, 2, "Está asignada a", ha="center", va="center")
plt.text(7.5, 1, "Atiende", ha="center", va="center")

# Establece los límites del eje y oculta los ticks
plt.xlim([-1, 12])
plt.ylim([-1, 4])
plt.xticks([])
plt.yticks([])

# Muestra el diagrama
plt.show()
