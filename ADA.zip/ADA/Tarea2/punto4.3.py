#version final punto 4 practico
#punto4.3.py es el final.
#Stefania Hurtado
import math
import sys

def triangulo():
    casos = int(sys.stdin.readline().strip())
    while casos > 0:
        casos -= 1
        numCasos = int(sys.stdin.readline().strip())
        A = []
        for i in range(numCasos):
            A.append(float(sys.stdin.readline().strip()))

        sum = 0
        for i in range(numCasos):
            if i >= len(A):
                break
            sum += A[i]

        limInfe = 0
        limSupe = sum
        media = A[0]
        flag = 1
        for i in range(numCasos):
            if i >= len(A):
                break
            limInfe = max(limInfe, A[i]/2)

        if sum - limInfe * 2 < limInfe * 2:
            flag = 0

        for iterador in range(40):
            media = (limInfe + limSupe) / 2
            sumAngulos = 0
            for i in range(numCasos):
                if i >= len(A):
                    break
                sumAngulos += math.asin((A[i]/2) / media) * 2
            if sumAngulos > 2 * math.pi:
                limInfe = media
            else:
                limSupe = media

        construArea = 0
        radio = media
        for i in range(numCasos):
            if i >= len(A):
                break
            construArea += calcuArea(radio, radio, A[i])
        if not flag:
            construArea = 0

        print("%.3f" % construArea)

def calcuArea(a, b, c):
    semiPerimetro = (a + b + c) / 2
    try:
        area = math.sqrt(semiPerimetro * (semiPerimetro - a) * (semiPerimetro - b) * (semiPerimetro - c))
        if area <= 0:
            return 0
        return area
    except:
        return 0

triangulo()
