#La complejidad temporal de este algoritmo es O(log N), ya que cada iteración reduce a la mitad el tamaño del subarreglo. 
#La complejidad espacial es O(1), ya que no se usa espacio adicional en relación con el tamaño del arreglo de entrada.
def mayoria(A, x):
    
    #busca si el elemento x es mayoritario en el arreglo A.
    #A debe estar ordenado ascendentemente.
    
    n = len(A)
    izquierda = 0
    derecha = n - 1
    while izquierda <= derecha:
        mid = (izquierda + derecha) // 2
        if A[mid] == x:
            # si x es mayoritario
            if (mid == 0 or A[mid - 1] < x) and (mid + n // 2 >= n or A[mid + n // 2] > x):
                return True
            else:
                # busqueda en el lado derecho del arreglo
                izquierda = mid + 1
        elif A[mid] < x:
            # busqueda en el lado derecho del arreglo
            izquierda = mid + 1
        else:
            # busqueda en el lado izquierdo del arreglo
            derecha = mid - 1
    return False
