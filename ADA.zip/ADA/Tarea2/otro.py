#version final de punto de suenos 
#otro.py
#primer envio debe ser este.
import sys 

def sueño():

    frecuencia = {}

    for entrada in sys.stdin:
        numSueños = int(entrada.strip())
        frecuencia = {}
        valorMax = 0
        for i in range(numSueños):
            mitad = int(input().strip())
            valorMax = max(valorMax, mitad)
            if mitad not in frecuencia:
                frecuencia[mitad] = 0
            frecuencia[mitad] += 1
        mitad = numSueños // 2
        totalNumRango = 0
        mediana = []
        flag = True
        define = numSueños % 2 != 0 # impar o par
        chuleados = 0 # num contado
        for i in range(valorMax + 1):
            if i not in frecuencia:
                frecuencia[i] = 0
            if frecuencia[i] == 0:
                continue
            chuleados = chuleados + frecuencia[i]
            if flag and chuleados >= mitad:
                flag = False
                mediana.append(i)
                if not define:
                    totalNumRango += frecuencia[i]
            if chuleados >= mitad + 1:
                if define:
                    totalNumRango += frecuencia[i]
                else:
                    if i != mediana[0]:
                        totalNumRango += frecuencia[i]
                mediana.append(i)
                break
        if define:
            resultado = 1
        else:
            resultado = mediana[1] - mediana[0] + 1
        print(mediana[0], totalNumRango, resultado)

sueño()
