
## float("inf") / ("-inf")
## 3.1 version casi final del punto 3 practico 

def buscando(izquierda, dere):
    if izquierda > dere:
        return
    raiz = izquierda
    minSuma = float("inf")
    maxSumDere = float("-inf")
    for i in range(izquierda, dere + 1):
        if i != dere and num[i] == num[i + 1]:
            continue
        maxSumIzqui = sum[i - 1] - sum[izquierda - 1] if i != 0 else 0
        sumArDere = sum[dere] - sum[i]
        diferencia = abs(sumArDere - maxSumIzqui)
        sumandoDere = maxSumIzqui
        if diferencia < minSuma:
            raiz = i
            minSuma = diferencia
            maxSumDere = sumandoDere
        if diferencia == minSuma and sumandoDere > maxSumDere:
            raiz = i
            minSuma = diferencia
            maxSumDere = sumandoDere
    print(num[raiz], end="")
    if izquierda != dere:
        print("(", end="")
        buscando(izquierda, raiz - 1)
        if raiz != izquierda and raiz != dere:
            print(",", end="")
        buscando(raiz + 1, dere)
        print(")", end="")


casos = int(input().strip())
for _ in range(casos):
    secuencia = int(input().strip())
    num = list(map(int, input().strip().split()))
    num.sort()
    sum = [0] * (secuencia + 1)
    sum[0] = num[0]
    for i in range(1, secuencia):
        sum[i] = sum[i - 1] + num[i]
    print("Case #{}: ".format(_ + 1), end="")
    buscando(0, secuencia - 1)
    print()
