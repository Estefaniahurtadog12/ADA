import sys

# función que busca el nodo raíz que minimiza la suma de diferencias
# izquierda-derecha en el árbol
def find_kupellakes_bst( left, right ):
    # si el índice izquierdo es mayor que el derecho, no hay más nodos que agregar
    if left > right:
        return ""
    else:
        # se inicializa la raíz con el índice izquierdo
        raiz = left
        # se inicializan los valores mínimos de suma en infinito y los máximos de suma en negativo infinito
        min_suma = float( 999999 )
        max_sum_right = float( 999999 )
        for i in range( left, right + 1 ):
            # se salta los índices iguales al final y que tengan el mismo valor que el siguiente
            if not ( (i == right) or (lis[i] != lis[i + 1]) ):
                continue
            elif i == 0:
                max_left = 0
            else:
                # se calcula la suma de los valores a la izquierda de la raíz
                max_left = suma[ i - 1 ] - suma[ left - 1 ]
            # se calcula la suma de los valores a la derecha de la raíz
            right_sum = suma[ right ] - suma[ i ]
            # se calcula la diferencia absoluta entre las sumas de izquierda y derecha
            difference = abs( right_sum - max_left )
            # se guarda la suma máxima a la derecha de la raíz
            sumando_right = max_left
            # si la diferencia es menor que la mínima registrada, se actualizan los valores
            if min_suma > difference:
                min_suma = difference
                max_sum_right = sumando_right
                raiz = i
            # si la diferencia es igual a la mínima registrada y la suma a la derecha de la raíz es mayor
            # que la máxima registrada, se actualizan los valores
            elif difference == min_suma and sumando_right > max_sum_right:
                raiz = i
                min_suma = difference
                max_sum_right = sumando_right

            # se convierte el valor de la raíz a string
            result = str( lis[raiz] )
            # se construye el árbol recursivamente
            result = build_bst( left, right, result, raiz )
            return result

# función que construye el árbol a partir del nodo raíz
def build_bst( left, right, result, raiz ):
    # si el índice izquierdo es distinto del derecho, se construyen los nodos hijos
    if left != right:
        result += "("
        result += find_kupellakes_bst( left, raiz - 1 )
        if raiz != left and raiz != right:
            result += ","
        result += find_kupellakes_bst( raiz + 1, right )
        result += ")"
    return result

# programa principal
if _name_ == "_main_":
    # se lee el número de casos de prueba
    T = int(input())
    for case in range( 1, T+1 ):
        # se lee el tamaño del array de valores
        n = int( input() )
        # se lee el array de valores y se ordena
