#Stefania Hurtado 
# Version oficial (book2.py) 
import sys

def asigna(maxNumPaginas):
    pagiActual = 0
    escriUsadas = 0
    for indiceLibro in range(cantLibros - 1, -1, -1): #ultima pag ,lee hasta el 1 libro, -1 en cada iteracion
        if numPagi[indiceLibro] + pagiActual > maxNumPaginas:
            escriUsadas += 1
            if escriUsadas == escribas:
                return False
            pagiActual = numPagi[indiceLibro]
        else:
            pagiActual += numPagi[indiceLibro]
    return True

def asignaMin(sum, pagMayor):
    minPaginas = pagMayor
    maxiPagiEscribas = sum
    while minPaginas < maxiPagiEscribas:
        media = minPaginas + (maxiPagiEscribas - minPaginas) // 2
        if asigna(media):
            maxiPagiEscribas = media
        else:
            minPaginas = media + 1
    return minPaginas

def dividir(maxPaginas):
    pagiActual = 0
    indiceEscriba = escribas - 1
    for indiceLibro in range(cantLibros - 1, -1, -1):
        if numPagi[indiceLibro] + pagiActual > maxPaginas or indiceEscriba == indiceLibro + 1:
            indiceEscriba -= 1
            final[indiceLibro] = True
            pagiActual = 0
        pagiActual += numPagi[indiceLibro]

casos = int(sys.stdin.readline().strip())
for indiceCaso in range(casos):
    cantLibros, escribas = map(int, sys.stdin.readline().strip().split())
    numPagi = list(map(int, sys.stdin.readline().strip().split()))
    totalPagi = sum(numPagi)
    pagMayor = max(numPagi)
    maxiPagiEscribas = asignaMin(totalPagi, pagMayor)
    final = []
    for i in range(cantLibros):
        final.append(False)
    dividir(maxiPagiEscribas)
    result = [str(numPagi[0])]
    if final[0]:
        result.append(" /")
    for indiceLibro in range(1, cantLibros):
        result.append(" {}".format(numPagi[indiceLibro]))
        if final[indiceLibro]:
            result.append(" /")
    print("".join(result))
