def buscando(izquierda, dere):
    if izquierda == dere:
        return (0, num[izquierda])
    medio = (izquierda + dere) // 2
    izqSum, izqMax = buscando(izquierda, medio)
    derSum, derMax = buscando(medio + 1, dere)
    cSum = 0
    cMax = float("-inf")
    for i in range(medio, izquierda - 1, -1):
        cSum += num[i]
        cMax = max(cSum, cMax)
    cSum = 0
    rMax = float("-inf")
    for i in range(medio + 1, dere + 1):
        cSum += num[i]
        rMax = max(cSum, rMax)
    centro = cMax + rMax
    return (max(izqSum, derSum, centro), max(izqMax, derMax, centro))

# leer la cantidad de casos de prueba
t = int(input().strip())

for caso in range(t):
    # leer la longitud de la secuencia
    secuencia = int(input().strip())
    # leer la secuencia y convertir a lista de enteros
    num = list(map(int, input().strip().split()))
    # llamar a la función buscando y mostrar los resultados
    res = buscando(0, secuencia-1)
    print("Case #{}: {} {}".format(caso+1, res[0], res[1]))

