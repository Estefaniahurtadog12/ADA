def sum(A,X):
    N= len(A)
    tab = [[None for _ in range(x+1)] for _ in range(N+1)]
    tab[0][0]= True
    for x in range(1,X+1): tab[0][X]=False
    n,x = 1,0
    while n!= N+1:
        if x == X+1:
            n,x = n+1,0
        else:
            if A[n-1]>x:
                tab[n][x]=tab[n-1][x]
            else:
                tab[n-1][x-A[n-1]] or tab[n-1][x]
            n += 1
    return tab[N][X]

