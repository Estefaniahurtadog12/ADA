#hacer sus respectivas correciones 
#version final punto4.py
#acomodar ciclos
#varibles 
import math

eps = 0.00000001
pi = math.acos(-1)

def heron(a, b, c):
    if a + b < c or b + c < a or c + a < b:
        return 0
    s = (a + b + c) / 2
    return math.sqrt(s * (s - a) * (s - b) * (s - c))

testcase = int(input().strip())
for i in range(testcase):
    n = int(input().strip())
    A = []
    for i in range(n):
        A.append(float(input().strip()))
    sum = sum(A)
    l = 0
    r = sum
    mid = A[0]
    ok = 1
    for i in range(n):
        l = max(l, A[i] / 2)
    if sum - l * 2 < l * 2:
        ok = 0
    for it in range(40):
        mid = (l + r) / 2
        theta = 0
        for i in range(n):
            theta += math.asin(A[i] / 2 / mid) * 2
        if theta > 2 * pi:
            l = mid
        else:
            r = mid

    area = 0
    R = mid
    for i in range(n):
        area += heron(R, R, A[i])
    if not ok:
        area = 0
    print("%.3lf" % area)
