import numpy as np
from math import sin, cos, exp

def f(x):
    return np.array([sin(x[0] + x[1]) - exp(x[0] - x[1]), cos(x[0] + 6) - x[0]**2 * x[1]**2])

def J(x):
    return np.array([
        [cos(x[0] + x[1]) - exp(x[0] - x[1]), cos(x[0] + x[1])],
        [-2*x[0]*x[1]**2, -2*x[1]*x[0]**2]
    ])

def raphson(f, J, x0, tol=1e-6, maxItera=100):
    x = np.array(x0, dtype=float)
    for i in range(maxItera):
        fx = f(x)
        Jx = J(x)
        deltaX = np.linalg.solve(Jx, -fx)
        x += deltaX
        if np.linalg.norm(deltaX) < tol:
            return x

    raise ValueError("no converge")

# Valores iniciales
x0 = [1, 1]

# Resolver el sistema de ecuaciones no lineales
x = raphson(f, J, x0, maxItera=100)

# Imprimir la solución
print("aproximacion:", x)
