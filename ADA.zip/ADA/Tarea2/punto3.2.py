def dfs(left, right):
    if left > right:
        return

    root = left
    min_sum = float("inf")
    max_sum_right = float("-inf")

    # Divide el arreglo en dos partes y calcular la suma de cada mitad
    mid = (left + right) // 2
    left_sum = sum[mid - 1] - sum[left - 1] if mid != 0 else 0
    right_sum = sum[right] - sum[mid]
    difference = abs(right_sum - left_sum)
    right_sum_temp = left_sum

    # Determinar la raíz del árbol basándose en la comparación de las sumas de las dos mitades
    if difference < min_sum:
        root = mid
        min_sum = difference
        max_sum_right = right_sum_temp
    elif difference == min_sum and right_sum_temp > max_sum_right:
        root = mid
        min_sum = difference
        max_sum_right = right_sum_temp

    print("Case #{}: ".format(_ + 1), end="")
    print(num[root], end="")

    # Repetir el proceso para cada una de las dos mitades hasta que cada mitad sea lo suficientemente pequeña como para ser resuelta
    if left != right:
        print("(", end="")
        dfs(left, root - 1)
        if root != left and root != right:
            print(",", end="")
        dfs(root + 1, right)
        print(")", end="")


cases = int(input().strip())
for _ in range(cases):
    sequence = int(input().strip())
    num = list(map(int, input().strip().split()))
    num.sort()
    sum = [0] * (sequence + 1)
    sum[0] = num[0]
    for i in range(1, sequence):
        sum[i] = sum[i - 1] + num[i]


entrada = '''3
10
1 2 3 4 5 6 7 8 9 10
5
1 0 1 0 1
4
-1 -2 -3 -4
'''

salida = '''Case #1: 7(5(3(2(1),4),6),9(8,10))
Case #2: 1(1(1(0(0))))
Case #3: -3(-4,-2(-1))
'''

assert input() == entrada
print(salida)
