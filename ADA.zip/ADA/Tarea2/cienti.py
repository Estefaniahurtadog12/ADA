import matplotlib.pyplot as plt
import numpy as np

def plot_function():
    # Define la función a tramos
    def f(x):
        if x < 1:
            return x ** 2 + 1
        else:
            return np.sqrt(x - 1) + 2

    # Defina el intervalo de x
    x = np.linspace(0, 4, 100)

    # Evalúa la función para cada valor de x en el intervalo
    y = [f(xi) for xi in x]

    # Grafica la función
    plt.plot(x, y, 'b-', linewidth=2)

    # Etiquetas de los ejes y título de la gráfica
    plt.xlabel('x')
    plt.ylabel('f(x)')
    plt.title('Gráfica de f(x)')

    # Muestra la gráfica
    plt.show()
