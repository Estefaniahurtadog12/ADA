import math

def main():
    testcase = int(input().strip())
    while testcase > 0:
        testcase -= 1
        n = int(input().strip())
        A = []
        for i in range(n):
            A.append(float(input().strip()))

        sum = 0
        for i in range(n):
            if i >= len(A):
                break
            sum += A[i]

        l = 0
        r = sum
        mid = A[0]
        ok = 1
        for i in range(n):
            if i >= len(A):
                break
            l = max(l, A[i]/2)

        if sum - l * 2 < l * 2:
            ok = 0

        for it in range(40):
            mid = (l + r) / 2
            theta = 0
            for i in range(n):
                if i >= len(A):
                    break
                theta += math.asin((A[i]/2) / mid) * 2
            if theta > 2 * math.pi:
                l = mid
            else:
                r = mid

        area = 0
        R = mid
        for i in range(n):
            if i >= len(A):
                break
            area += heron(R, R, A[i])
        if not ok:
            area = 0

        print("%.3f" % area)

def heron(a, b, c):
    if a + b < c or b + c < a or c + a < b:
        return 0
    s = (a + b + c)/2
    return math.sqrt(s * (s - a) * (s - b) * (s - c))

main()
