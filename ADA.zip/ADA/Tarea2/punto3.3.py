##version final punto 3
##parcial Stefania Hurtado
import sys
import math

# funcion que busca el nodo raíz que minimiza la suma de diferencias
def buscando(izquierda, dere):
    if izquierda > dere:
        return
    raiz = izquierda
    minSuma = float("inf") #infinito +
    maxSumDere = float("-inf")#infinito -
    for i in range(izquierda, dere + 1):
        #compara los valores que son iguales y si son diferentes sigue en la siguiente condicion.
        if not ((i == dere) or (num[i] != num[i + 1])):
            continue
        #
        elif i == 0:
            maxSumIzqui = 0
        else:
            maxSumIzqui = sum[i - 1] - sum[izquierda - 1]
        sumArDere = sum[dere] - sum[i]
        diferencia = abs(sumArDere - maxSumIzqui)
        sumandoDere = maxSumIzqui
        if diferencia < minSuma:
            raiz = i
            minSuma = diferencia
            maxSumDere = sumandoDere
        elif diferencia == minSuma and sumandoDere > maxSumDere:
            raiz = i
            minSuma = diferencia
            maxSumDere = sumandoDere
    print(num[raiz], end="")
    #faltan nodos por visitar
    if izquierda != dere:
        print("(", end="")
        buscando(izquierda, raiz - 1)
        #posiscion no puede ser igual a la raiz no es igual al izquierdo o derecho, mejor dicho estan vacios
        if raiz != izquierda and raiz != dere:
            print(",", end="")
        buscando(raiz + 1, dere)
        print(")", end="")


casos = int(sys.stdin.readline().strip())
for caso in range(1, casos + 1):
    secuencia = int(sys.stdin.readline().strip())
    num = list(map(int, sys.stdin.readline().strip().split()))
    num.sort()
    sum = [0] * (secuencia + 1)
    sum[0] = num[0]
    for i in range(1, secuencia):
        sum[i] = sum[i - 1] + num[i]
    print("Case #{}: ".format(caso), end="")
    buscando(0, secuencia - 1)
    print()
