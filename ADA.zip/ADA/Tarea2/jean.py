from sys import stdin

def validacion(lista,capacidadEvaluar,cantEscribas):
    val=False
    contEscriba=0
    posicionLista=0
    while(contEscriba<cantEscribas):
        acumuladorEscriba=0
        if posicionLista==0:
            for i in range(posicionLista,len(lista)):
                if((acumuladorEscriba+lista[i])<=capacidadEvaluar):
                    acumuladorEscriba+=lista[i]
                    posicionLista=i
        else:
            for i in range(posicionLista+1,len(lista)):
                if((acumuladorEscriba+lista[i])<=capacidadEvaluar):
                    acumuladorEscriba+=lista[i]
                    posicionLista=i
        contEscriba+=1
    print(posicionLista)
    if(posicionLista==len(lista)-1):
        val=True
    else:
        val=False
    return val