import sys

arr = [0 for _ in range(1005)]
A = [0 for _ in range(1005)]

def positionFind(i, j):
    pos = i
    mn = sys.maxsize
    mx = 0
    for k in range(i, j + 1):
        if k != j and A[k] == A[k + 1]:
            continue
        l = arr[k - 1] - arr[i - 1]
        r = arr[j] - arr[k]
        dif = abs(l - r)
        if dif < mn:
            mn = dif
            mx = l
            pos = k
        if l > mx and dif == mn:
            mx = l
            pos = k
    return pos

def construction(i, j):
    if j < i:
        return

    pos = positionFind(i, j)
    data = arr[pos] - arr[pos - 1]
    print(data, end='')
    if i != j:
        print('(', end='')
        construction(i, pos - 1)
        if i != pos and j != pos:
            print(',', end='')
        construction(pos + 1, j)
        print(')', end='')

tc = int(input().strip())
for Case in range(1, tc + 1):
    n = int(input().strip())

    A = list(map(int, input().strip().split()))

    A.sort()
    arr[0] = 0
    for i in range(1, n + 1):
        arr[i] = arr[i - 1] + A[i - 1]
    print("Case #{}: ".format(Case), end='')
    construction(0, n - 1)
    print()
