import sys

MAX = 65537

data = [0] * MAX

for line in sys.stdin:
    n = int(line.strip())
    data = [0] * MAX
    for i in range(n):
        m = int(input().strip())
        data[m] += 1
    
    m = n // 2
    numbers = 0
    median = []
    insert = True
    isOdd = n % 2 != 0
    j=0
    for i in range(MAX):
        if data[i] == 0:
            continue
        j = j + data[i]

        if insert and j >= m:
            insert = False
            median.append(i)

            if not isOdd:
                numbers += data[i]
        if j >= m + 1:
            if isOdd or i != median[0]:
                numbers += data[i]
            median.append(i)
            break

    if isOdd:
        print(median[1], numbers, 1)
    else:
        print(median[0], numbers, median[0] == median[1] and 1 or median[1] - median[0] + 1)
