import sys

# Definir el tamaño máximo de la matriz
MAX_SIZE = 1010

# Crear una lista de longitud máxima para numHoyo
numHoyo = [0] * MAX_SIZE

# Crear una matriz de longitud máxima para dp
dp = [[-1] * MAX_SIZE for _ in range(MAX_SIZE)]

# Crear una matriz de longitud máxima para peso
peso = [[0] * MAX_SIZE for _ in range(MAX_SIZE)]

INF = float("inf")

def resolver(pos, actual):
    global numHoyo, dp, peso, INF

    # Si llegamos al final, no hay más costos para añadir
    if pos == numHoyo[actual]:
        return 0

    # Si ya hemos resuelto este subproblema, devolver la respuesta previa
    if dp[pos][actual] != -1:
        return dp[pos][actual]

    # Por defecto, asignar infinito como el valor mínimo
    min_costo = INF

    # Explorar todas las opciones de salto
    for salto in range(-1, 2):
        siguiente = actual + salto

        # Si estamos dentro del rango válido
        if 0 <= siguiente < MAX_SIZE and numHoyo[siguiente] > pos:
            # Calcular el costo del salto
            costo = peso[actual][siguiente] + resolver(pos+1, siguiente)
            # Actualizar el valor mínimo
            min_costo = min(min_costo, costo)

    # Guardar la respuesta en la matriz dp
    dp[pos][actual] = min_costo

    # Devolver la respuesta
    return min_costo


for linea in sys.stdin:
    # Leer los valores de entrada
    n, m = map(int, linea.split())
    numHoyo = [0] * MAX_SIZE

    # Leer los datos de entrada
    for i in range(m):
        posicion, cantidad = map(int, input().split())
        numHoyo[posicion] = cantidad

    # Calcular los pesos entre los agujeros
    for i in range(MAX_SIZE):
        for j in range(MAX_SIZE):
            if i == j:
                peso[i][j] = 0
            elif numHoyo[i] == 0 or numHoyo[j] == 0:
                peso[i][j] = INF
            else:
                peso[i][j] = abs(i - j) + numHoyo[j]

    # Encontrar el mejor punto de inicio y calcular el costo mínimo
    min_costo = INF
    for i in range(MAX_SIZE):
        if numHoyo[i] > 0:
            dp = [[-1] * MAX_SIZE for _ in range(MAX_SIZE)]
            costo = resolver(0, i)
            min_costo = min(min_costo, costo)

    # Imprimir el resultado
    print(min_costo)
