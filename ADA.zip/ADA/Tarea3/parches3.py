from sys import stdin, setrecursionlimit
from collections import deque

def solve(A, B, n, x, t1, t2, mem):
    ans = None
    if n == len(A): ans = 0
    elif (n, x) in mem: ans = mem[(n, x)]
    elif n == len(A)-1 and x == -1: ans = t1
    elif n == len(A)-1: ans = 0
    else:
        if x != -1: ans = solve(A, B, n+1, max(x-B[n], -1), t1, t2, mem)
        else:
            ans = min(t1 + solve(A, B, n+1, max(t1-B[n], -1), t1, t2, mem),
                      t2 + solve(A, B, n+1, max(t2-B[n], -1), t1, t2, mem))
        mem[(n, x)] = ans
    return ans

if __name__ == "__main__":
    setrecursionlimit(1<<20)

    for line in stdin:
        num, c, t1, t2 = map(int, line.split())
        patches = [int(x) for x in stdin.readline().strip().split()]
        distances = [patches[i+1] - patches[i] for i in range(num-1)]
        new_t1, new_t2 = min(t1, t2), max(t1, t2)

        ans = solve(patches, distances, 0, -1, new_t1, new_t2, dict())

        for shift in range(num-1):
            if patches[0] + (c-patches[-(shift+1)]) > new_t2:
                break
            else:
                shift += 1

        patch_new = deque()
        i = 0
        while i < len(patches):
            patch_new.append(patches[i])
            i += 1


        for shift in range(shift):

            diff = c-patch_new[-1]
            patch_new.pop()

            for i in range(num-1):
                patch_new[i] += diff
            patch_new.appendleft(0)

            dist = [patch_new[i+1]-patch_new[i] for i in range(num-1)]

            ans = min(ans, solve(patch_new, dist, 0, -1, new_t1, new_t2, dict()))

        print(ans)
