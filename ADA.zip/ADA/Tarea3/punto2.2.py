##punto oficial ejercicio practico #2
#Stefania Hurtado 
import sys

numHoyo = [0] * 1010
dp = [[-1] * 1010 for _ in range(1010)]
peso = [[0] * 1010 for _ in range(1010)]
INF = float("inf")

def memori(pos, st):
    global dp
    if pos == n:
        return 0
    ret = dp[pos][st]
    if ret != -1:
        return ret
    ret = INF
    for i in range(pos, n):
        if peso[st][i] - peso[st][pos] <= t1:
            next = i
        else:
            break
    ret = min(ret, memori(next+1, st) + t1)

    for i in range(pos, n):
        if peso[st][i] - peso[st][pos] <= t2:
            next = i
        else:
            break
    ret = min(ret, memori(next+1, st) + t2)
    dp[pos][st] = ret
    return ret

for line in sys.stdin:
    try:
        n, c, t1, t2 = map(int, line.split())
        numHoyo = list(map(int, next(sys.stdin).split()))

        for i in range(n):
            tmp = 0
            for j in range(n):
                if i+j >= n:
                    tmp = c - numHoyo[i]
                    peso[i][j] = numHoyo[(i+j)%n] + tmp
                else:
                    peso[i][j] = numHoyo[(i+j)%n] - numHoyo[i]

        total = INF
        for i in range(n):
            dp = [[-1] * n for _ in range(n)]
            total = min(total, memori(0, i))
        print(total)

    except:
        break
