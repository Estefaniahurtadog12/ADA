Listar para cada cliente las compras que son mayores que el promedio de lo que ese cliente compra en un dia

WITH diario AS   (SELECT cc, fecha,

                         SUM(cantidad*precio) AS totalDia

                  FROM compra GROUP BY cc,fecha ),

     promedio AS (SELECT cc, AVG(totalDia) AS promedioDia

                  FROM diario GROUP BY cc )

SELECT cc, nombre, fecha, prod AS producto

FROM   cliente NATURAL JOIN compra NATURAL JOIN promedio

WHERE  cantidad*precio > promedioDia;

WITH promedio (SELECT codconcepto,valor,
AVG())