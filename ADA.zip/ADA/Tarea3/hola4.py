hole = [0] * 1010
dp = [-1] * 1010
graph = [[0] * 1010 for _ in range(1010)]
INF = float("inf")

def call(pos, st):
    global dp
    if pos == n:
        return 0
    ret = dp[pos]
    if ret != -1:
        return ret
    ret = INF
    for i in range(pos, n):
        if graph[st][i] - graph[st][pos] <= t1:
            next = i
        else:
            break
    ret = min(ret, call(next+1, st) + t1)

    for i in range(pos, n):
        if graph[st][i] - graph[st][pos] <= t2:
            next = i
        else:
            break
    ret = min(ret, call(next+1, st) + t2)

    dp[pos] = ret
    return ret


while True:
    try:
        n, c, t1, t2 = map(int, input().split())
        hole = list(map(int, input().split()))

        for i in range(n):
            tmp = 0
            for j in range(n):
                if i+j >= n:
                    tmp = c - hole[i]
                    graph[i][j] = hole[(i+j)%n] + tmp
                else:
                    graph[i][j] = hole[(i+j)%n] - hole[i]

        dp = [-1] * n
        ans = INF
        for i in range(n):
            dp = [-1] * n
            ans = min(ans, call(0, i))
        print(ans)

    except:
        break
