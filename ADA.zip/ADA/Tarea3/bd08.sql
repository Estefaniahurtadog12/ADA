
ALTER TABLE Banco
ADD paginaWeb VARCHAR( 100 );

UPDATE ( SELECT nombre, paginaWeb as newP FROM Banco ) banco
SET banco.newP = 'https://www.davivienda.com/wps/portal/personas/nuevo'
WHERE banco.nombre = 'Davivienda';

UPDATE ( SELECT nombre, paginaWeb as newP FROM Banco ) banco
SET banco.newP = 'https://www.bancolombia.com/personas'
WHERE banco.nombre = 'Banco de Colombia';



ALTER TABLE Cargo
MODIFY nombre VARCHAR2( 15 );



ALTER TABLE empleado
MODIFY nombre VARCHAR2( 10 ) NULL;


ALTER TABLE empSucursal
RENAME COLUMN bonificacion to porcBonifica;


ALTER TABLE sucursal 
ADD CONSTRAINT nombre UNIQUE(nombre, codciudad);


ALTER TABLE pagoNomina
ADD nroPago NUMBER(10);

/*a*/
UPDATE pagoNomina
SET nroPago = (ROWNUM + 1000);

/*b*/
ALTER TABLE detallePago
DROP PRIMARY KEY;

ALTER TABLE detallePago
DROP CONSTRAINT SYS_C0015859;

ALTER TABLE pagoNomina
DROP PRIMARY KEY;

ALTER TABLE pagoNomina
ADD PRIMARY KEY (nroPago);

ALTER TABLE detallePago
ADD nroPago NUMBER(10);

ALTER TABLE detallePago
ADD FOREIGN KEY (nroPago) REFERENCES pagoNomina(nroPago);


UPDATE ( SELECT pagonomina.nroPago as nro, detallepago.nroPago AS newP FROM detallepago JOIN pagonomina ON pagonomina.idempleado = detallepago.idempleado and pagonomina.fechapago = detallepago.fechapago ) pago
SET pago.newP = nro;

ALTER TABLE detallePago
ADD PRIMARY KEY (nroPago, codconcepto);
















