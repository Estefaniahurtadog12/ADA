import sys

def dp(n, e, memo):
    if n == N:
        return 0
    if (n, e) in memo:
        return memo[(n, e)]
    ans = T[n] + dp(n+1, e+E[n], memo)
    if e > 0:
        ans = min(ans, (T[n]>>1) + dp(n+1, e+E[n]-1, memo))
    memo[(n, e)] = ans
    return ans

def phi(T, E):
    memo = {}
    return dp(0, 0, memo)

# Leer el número de casos
cases = int(input())

# Procesar cada caso
for case in range(cases):
    # Leer los valores de T y E para este caso
    T_list = []
    E_list = []

line = input().strip().split()
N = int(line[0])

for i in range(N):
    T, E = map(int, input().strip().split())
    print(phi(T, E))


