class Mission:
    def __init__(self, t, b):
        self.t = t
        self.b = b
        self.used = False

    def __lt__(self, other):
        return self.t > other.t  # Ordenar en orden descendente según el tiempo de la misión

while True:
    n = int(input().strip())
    if n == 0:
        break

    missions = []
    for i in range(n):
        t, b = map(int, input().strip().split())
        missions.append(Mission(t, b))

    for i in range(n - 1, -1, -1):
        m1 = missions[i]
        if m1.b > 0:
            tmp = []
            for j in range(i + 1, n):
                m2 = missions[j]
                if not m2.used:
                    tmp.append(m2)
            tmp.sort()
            for j in range(min(len(tmp), m1.b)):
                tmp[j].used = True

    total = 0
    for m in missions:
        total += m.t // 2 if m.used else m.t
    print(total)
