# Author: Luis Alfredo Rodriguez Lopez
from sys import stdin, setrecursionlimit
from collections import deque

def solve(A, B, n, x, t1, t2, mem):
    ans = None
    if n == len(A): ans = 0
    elif (n, x) in mem: ans = mem[(n, x)]
    elif n == len(A)-1 and x == -1: ans = t1
    elif n == len(A)-1: ans = 0
    else:
        if x != -1: ans = solve(A, B, n+1, max(x-B[n], -1), t1, t2, mem)
        else:
            ans = min(t1 + solve(A, B, n+1, max(t1-B[n], -1), t1, t2, mem),
                      t2 + solve(A, B, n+1, max(t2-B[n], -1), t1, t2, mem))
        mem[(n, x)] = ans
    return ans

if __name__ == "__main__":
    setrecursionlimit(1<<20)

    read = stdin.readline
    line = read().strip()

    while line:
        num, c, t1, t2 = map(int, line.split())
        patches = [int(x) for x in read().strip().split()]
        distances = [patches[i+1] - patches[i] for i in range(num-1)]
        new_t1, new_t2 = min(t1, t2), max(t1, t2)

        ans = solve(patches, distances, 0, -1, new_t1, new_t2, dict())

        shift = 0
        while (shift+1 != num
                and patches[0] + (c-patches[-(shift+1)]) <= new_t2):
            shift += 1

        patch_new = deque()
        for x in patches: patch_new.append(x)

        while shift != 0:
            diff = c-patch_new[-1]
            patch_new.pop()

            for i in range(num-1): patch_new[i] += diff
            patch_new.appendleft(0)

            dist = [patch_new[i+1]-patch_new[i] for i in range(num-1)]

            ans = min(ans, solve(patch_new, dist, 0, -1, new_t1, new_t2, dict()))
            shift -= 1

        print(ans)
        line = read().strip()
