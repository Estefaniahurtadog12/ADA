def solve(arr, n, suma_actual, S, mem):
    ans = None
    if n == len(arr) or suma_actual > S: ans = False
    elif (n, suma_actual) in mem: ans = mem[(n, suma_actual)]
    elif suma_actual == S: ans = True
    else:
        ans = solve(arr, n+1, suma_actual+arr[n], S, mem) or solve(arr, n+1, suma_actual, S, mem)
        mem[(n, suma_actual)] = ans
    return ans

if __name__ == "__main__":
    a = [2, 1, 3, 2, 4]
    b = 6
    print(solve(a, 0, 0, b, {}))

    a = [2, 3, 7, 8]
    b = 12
    print(solve(a, 0, 0, b, {}))

    a = [2, 1, 5]
    b = 4
    print(solve(a, 0, 0, b, {}))