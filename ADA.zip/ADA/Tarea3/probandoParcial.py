def omin (A):
    N = len(str(A))
    r,n = float('inf'),0
    while n!= N:
        r,n = min(r, A[n]), n+1
    return r

omin(2)

