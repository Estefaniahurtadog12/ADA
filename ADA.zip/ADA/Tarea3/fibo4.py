from sys import stdin

def fibo(nivel):
    num1 =0
    num2 = 1
    iterador = 2
    while iterador <= nivel:
        num1,num2 = num2, num1 + num2
        iterador += 1
        
    return num2 if nivel != 0 else num1
    

entrada = stdin.readlines()

for entradaOfi in entrada:
    entradaOfi = entradaOfi.strip()
    if entradaOfi == '0':
        break
    numero = int(entradaOfi)
    ans = fibo(numero)
    
    print(ans)
