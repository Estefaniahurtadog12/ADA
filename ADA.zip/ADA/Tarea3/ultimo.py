def encontrar_segmento_decreciente(a):
    n = len(a)

    # Caso base: si el arreglo tiene menos de 2 elementos, no hay segmento decreciente
    if n < 2:
        return -1

    # Caso base: si el arreglo es decreciente, todo el arreglo es el segmento decreciente
    if a[0] >= a[n-1]:
        return 0

    # Dividir el arreglo en dos mitades y encontrar el segmento decreciente en cada mitad
    mitad = n // 2
    i = encontrar_segmento_decreciente(a[:mitad])
    j = encontrar_segmento_decreciente(a[mitad:])

    # Combinar los resultados de las dos mitades para encontrar el segmento decreciente en todo el arreglo
    return encontrar_segmento_decreciente_combinado(a, i, j, mitad)


def encontrar_segmento_decreciente_combinado(a, i, j, mitad):
    if i == -1:
        return j + mitad
    elif j == -1:
        return i

    k = j + mitad
    while j < len(a) - 1 and a[j] >= a[j+1]:
        j += 1

    while i > 0 and a[i-1] >= a[i]:
        i -= 1

    if j - i + 1 > 0 and k - i + 1 > 0 and j - k + 1 > 0:
        return i

    if j - i + 1 < 0:
        return k

    if k - i + 1 < 0:
        return i

    if j - k + 1 < 0:
        return j + mitad

    return -1


# Ejemplo de uso
a = [5,7,9]
indice = encontrar_segmento_decreciente(a)
if indice != -1:
    segmento = a[indice]
    print(f"El segmento decreciente es {segmento}")
else:
    print("No hay segmento decreciente en el arreglo")
