import sys
from sys import stdin
#guardamos info en diccionario memo, utilizamos memorizacion, con tabulaicon da time limit (memorizacion)

def phi(infoViaje, viajeActual, reservaActual, memo={}):
    if viajeActual == len(infoViaje):
        resultado = 0
    elif (viajeActual, reservaActual) in memo:
        resultado = memo[(viajeActual, reservaActual)]
    else:
        resultado = infoViaje[viajeActual][0] + phi(infoViaje, viajeActual+1, reservaActual+infoViaje[viajeActual][1], memo)
        if reservaActual > 0:
            reserva = (infoViaje[viajeActual][0] >> 1) + phi(infoViaje, viajeActual+1, reservaActual-1 +infoViaje[viajeActual][1], memo)
            resultado = min(resultado, reserva)
        memo[(viajeActual, reservaActual)] = resultado
    return resultado

def main():

    for entradaOfi in sys.stdin:
        entradaOfi = entradaOfi.strip()
        if entradaOfi == '0':
            break

        cantViaje = int(entradaOfi)
        viaje = [[]] * cantViaje

        i = 0
        while i < cantViaje:
            tiempo, reservaMateria = map(int, input().strip().split())
            viaje[i] = [tiempo, reservaMateria]
            i += 1

        resultado = phi(viaje, 0, 0, {})
        print(resultado)

main()

