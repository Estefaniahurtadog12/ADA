def solve(T):
    n = len(T)
    dp = [[0] * n for _ in range(n)]
    max_length = 0
    for i in range(n):
        for j in range(n):
            if i == 0 or j == n-1:
                dp[i][j] = int(T[i] == T[n-1-j])
            elif T[i] == T[n-1-j]:
                dp[i][j] = dp[i-1][j-1] + 1
            else:
                dp[i][j] = 0
            if dp[i][j] > max_length and i <= n-1-j-dp[i][j]:
                max_length = dp[i][j]
    return max_length
    
    #return longest
if __name__ == "__main__":
    a = "ALGORITHM"
    print(a,solve(a))
    a = "RECURSION"
    print(a,solve(a))
    a = "REDIVIDE"
    print(a,solve(a))
    a = "DYNAMICPROGRAMMINGMANYTIMES"
    print(a,solve(a))