from sys import stdin
from collections import deque
acumulado = {}
# Función recursiva para encontrar la solución óptima
def definitivo(parche, distancia, i, last, t1, t2, acumulado):
    # Si ya hemos recorrido todas las posiciones, retornamos 0
    if i == len(distancia):
        return 0

    # Si ya hemos calculado la solución óptima para esta posición, la retornamos
    if (i, last) in acumulado:
        return acumulado[(i, last)]

    # Calculamos la solución óptima para no cambiar el neumático actual
    opcion1 = distancia[i] + definitivo(parche, distancia, i+1, last, t1, t2, acumulado)

    # Si podemos cambiar el neumático actual y aún quedan más por cambiar, calculamos la solución óptima para hacerlo
    if last < i - 1 and parche[i+1] - parche[last+1] <= t2:
        opcion2 = t1 + definitivo(parche, distancia, i+1, i, t1, t2, acumulado)
    else:
        opcion2 = float('inf')

    # Elegimos la mejor opción y la almacenamos en el diccionario acumulado
    resultado = min(opcion1, opcion2)
    acumulado[(i, last)] = resultado

    return resultado

# Procesamos cada conjunto de datos
for entrada in stdin:
    # Leemos la información de entrada
    numParche, c, t1, t2 = map(int, entrada.split())
    entrada = stdin.readline().strip()
    posiciones = entrada.split()
    parche = []
    for posicion in posiciones:
        neumatico = int(posicion)
        parche.append(neumatico)

    # Calculamos las distancias entre las posiciones
    distancia = []
    for i in range(numParche - 1):
        distancia.append(parche[i+1] - parche[i])

    # Definimos los nuevos tiempos límites
    nuevoT1 = min(t1, t2)
    nuevoT2 = max(t1, t2)

    # Calculamos la solución óptima para el conjunto de datos
    resultado = definitivo(parche, distancia, 0, -1, nuevoT1, nuevoT2, dict())

    # Realizamos las posibles sustituciones de neumáticos y calculamos la solución óptima para cada una
    for reemplazo in range(numParche-1):
        if parche[0] + (c-parche[-(reemplazo+1)]) > nuevoT2:
            break
        else:
            reemplazo += 1

    nuevoParche = deque()
    for posicion in parche:
        nuevoParche.append(posicion)

    for reemplazo in range(reemplazo):
        dife = c - nuevoParche[-1]
        nuevoParche.pop()

        for i in range(numParche-1):
            nuevoParche[i] += dife

        nuevoParche.appendleft(0)

        distNuevo = []
        for i in range(numParche - 1):
            distNuevo.append(nuevoParche[i+1] - nuevoParche[i])

        resultado = min(resultado, definitivo(nuevoParche, distNuevo, 0, -1,nuevoT1, nuevoT2, acumulado))

        print(resultado)

