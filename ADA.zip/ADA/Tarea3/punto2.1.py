profHoyo = [0] * 1010
dp = [[-1] * 1010 for _ in range(1010)]
peso = [[0] * 1010 for _ in range(1010)]
INF = float("inf")

def call(posiActual, posiInicial):
    global dp
    if posiActual == n:
        return 0
    ret = dp[posiActual][posiInicial]
    if ret != -1:
        return ret
    ret = INF
    for i in range(posiActual, n):
        if peso[posiInicial][i] - peso[posiInicial][posiActual] <= t1:
            sigui = i
        else:
            break
    ret = min(ret, call(sigui+1, posiInicial) + t1)

    for i in range(posiActual, n):
        if peso[posiInicial][i] - peso[posiInicial][posiActual] <= t2:
            sigui = i
        else:
            break
    ret = min(ret, call(sigui+1, posiInicial) + t2)
    dp[posiActual][posiInicial] = ret
    return ret

while True:
    try:
        n, c, t1, t2 = map(int, input().split())
        profHoyo = map(int, input().split())

        for i in range(n):
            tmp = 0
            for j in range(n):
                if i+j >= n:
                    tmp = c - profHoyo[i]
                    peso[i][j] = profHoyo[(i+j)%n] + tmp
                else:
                    peso[i][j] = profHoyo[(i+j)%n] - profHoyo[i]

        resultado = INF
        for i in range(n):
            dp = [[-1] * n for _ in range(n)]
            resultado = min(resultado, call(0, i))
        print(resultado)

    except EOFError:
        break
