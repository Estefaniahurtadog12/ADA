from sys import stdin

def fibonacci(n):
    a, b = 0, 1
    for _ in range(2, n+1):
        a, b = b, a + b
    return b if n != 0 else a

if __name__ == "__main__":
    read = stdin.readline
    line = read().strip()

    while line != '0':
        num = int(line)
        ans = fibonacci(num)
        print(ans)
        line = read().strip()