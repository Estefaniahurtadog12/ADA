lista_de_listas = [[0, 20], [15, 35]]

resultado = [sum(sublista) for sublista in zip(*lista_de_listas)]

print(resultado) # resultado: [25, 85]
