import sys
from collections import deque

sys.setrecursionlimit(1000000) #no hay desbordamiento hasta un 1000000 de recursiones

def definitivo(distanciaHorario, distanciaCubreParche, hueco, posActualNeumatico, t1, t2, memory):
    if hueco == len(distanciaHorario):
         resultado = 0 
    elif (hueco, posActualNeumatico) in memory: 
        resultado = memory[(hueco, posActualNeumatico)]
    elif hueco == len(distanciaHorario)-1 and posActualNeumatico == -1:
         resultado = t1
    elif hueco == len(distanciaHorario)-1:
         resultado = 0
    else:
        if posActualNeumatico != -1:
            resultado = definitivo(distanciaHorario, distanciaCubreParche, hueco + 1, max(posActualNeumatico-distanciaCubreParche[hueco], -1), t1, t2, memory) 
        else:  
            resultado = min(t1 + definitivo(distanciaHorario, distanciaCubreParche, hueco + 1, max(t1-distanciaCubreParche[hueco], -1), t1, t2, memory),
                      t2 + definitivo(distanciaHorario, distanciaCubreParche, hueco + 1, max(t2-distanciaCubreParche[hueco], -1), t1, t2, memory))
        memory[(hueco, posActualNeumatico)] = resultado
    return resultado

while True:
    entrada = sys.stdin.readline().strip()
    if not entrada:
        break
    numParche, c, t1, t2 = map(int, entrada.split())
    parche = [int(posActualNeumatico) for posActualNeumatico in sys.stdin.readline().strip().split()]
    distancia = []
    i = 0
    while i < numParche - 1:
        distancia.append(parche[i+1] - parche[i])
        i += 1
    nuevoT1 = min(t1, t2)
    nuevoT2 =max(t1, t2)
    resultado = definitivo(parche, distancia, 0, -1, nuevoT1, nuevoT2, dict())
    
    reemplazo = 0
    while reemplazo < numParche-1:
        if parche[0] + (c-parche[-(reemplazo+1)]) > nuevoT2:
            break
        else:
            reemplazo += 1

    nuevoParche = deque(parche)

    for reemplazo in range(reemplazo):
        dife = c - nuevoParche[-1]
        nuevoParche.pop()
        i = 0
        while i < numParche-1:
            nuevoParche[i] += dife
            i += 1
        nuevoParche.appendleft(0)
        distNuevo = [nuevoParche[i+1] - nuevoParche[i] for i in range(numParche-1)]
        resultado = min(resultado, definitivo(nuevoParche, distNuevo, 0, -1, nuevoT1, nuevoT2, dict()))
    print(resultado)

