import sys


def phi(A, n, d, memo={}):
    def phi_aux(A, n, d):
        if n == len(A):
            return 0
        elif (n, d) in memo:
            return memo[(n, d)]
        else:
            resultado = A[n][0] + phi_aux(A, n+1, d+A[n][1])
            if d > 0:
                reserva = (A[n][0] >> 1) + phi_aux(A, n+1, d-1 +A[n][1])
                resultado = min(resultado, reserva)
            memo[(n, d)] = resultado
            return resultado

    return phi_aux(A, n, d)



def main():
    for entradaOfi in sys.stdin:
        entradaOfi = entradaOfi.strip()
        if entradaOfi == '0':
            break

        cantViaje = int(entradaOfi)
        viaje = [() for _ in range(cantViaje)]

        for i in range(cantViaje):
            tiempo, reservaMateria = map(int, input().strip().split())
            viaje[i] = (tiempo, reservaMateria)

        resultado = phi(viaje, 0, 0)
        print(resultado)


if __name__ == '__main__':
    main()
