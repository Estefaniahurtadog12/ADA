from sys import stdin

def phi(A, n, d,memo={}):
    resultado = None
    if n ==len(A):
        resultado = 0
    elif (n,d) in memo:
        resultado = memo[(n,d)]
    else:
        resultado = A[n][0] + phi(A,n+1,d+A[n][1],memo)
        if d > 0:
            reserva = (A[n][0]>>1) + phi(A, n+1, d-1+A[n][1],memo)
            resultado = min(resultado, reserva)
        memo[(n,d)] = resultado
    return resultado

if __name__ == '__main__':
    entrada = stdin.readline
    entradaOfi = read().strip

    while entradaOfi != '0':
        cantViaje = int(entradaOfi)
        viaje = [[]] * cantViaje

        for i in range(cantViaje):
            tiempo, reservaMateria = map(int, read().strip().split())
            viaje[i] = [tiempo,reservaMateria]
        resultado = phi(viaje, 0, 0, {})
        print(resultado)