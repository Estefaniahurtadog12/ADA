from sys import stdin

def solucion(distanciaHorario, distanciaCubreParche, hueco, posActualNeumatico, t1, t2, memory):
 
    if hueco == len(distanciaHorario):
        resultado = 0 #ya cubre
    elif (hueco, posActualNeumatico) in memory:
        resultado = memory[(hueco, posActualNeumatico)]
    else:
        if hueco == len(distanciaHorario) - 1 and posActualNeumatico == -1:
            resultado = t1 # tira parche 
        elif hueco == len(distanciaHorario) - 1:
            resultado = 0
        else:
            if posActualNeumatico != -1:
                nueva_posicion = max(posActualNeumatico - distanciaCubreParche[hueco], -1)
                resultado = solucion(distanciaHorario, distanciaCubreParche, hueco + 1, nueva_posicion, t1, t2, memory)
            else:
                nuevaPosT1 = max(t1 - distanciaCubreParche[hueco], -1)
                nuevaPosT2 = max(t2 - distanciaCubreParche[hueco], -1)
                resultadoT1 = t1 + solucion(distanciaHorario, distanciaCubreParche, hueco + 1, nuevaPosT1, t1, t2, memory)
                resultadoT2 = t2 + solucion(distanciaHorario, distanciaCubreParche, hueco + 1, nuevaPosT2, t1, t2, memory)
                resultado = min(resultadoT1, resultadoT2)
            memory[(hueco, posActualNeumatico)] = resultado
    return resultado

def main():
    lines = stdin.readlines()
    for i in range(0, len(lines), 2):
        numParche, c, t1, t2 = map(int, lines[i].strip().split())
        parche = list(map(int, lines[i + 1].strip().split()))
        distancia = [parche[j + 1] - parche[j] for j in range(numParche -1)]
        memory = {}
        nuevoT1 = min(t1, t2)
        nuevoT2 = max(t1, t2)
        resultado = solucion(parche, distancia, 0, -1, nuevoT1, nuevoT2, memory)

        desplazamiento = 0
        while desplazamiento + 1 != numParche and parche[0] + (c-parche[-(desplazamiento + 1)]) <= nuevoT2:
            desplazamiento += 1

        j = 0
        while j < desplazamiento:
            diff = c - parche[-1]
            parche.pop()
            # Desplaza los parches
            nuevosParches = []
            for p in parche:
                nuevosParches.append(p + diff)
            nuevosParches.append(0)
            parche = nuevosParches
            # Calcula las distancia
            distancia = []
            for k in range(numParche - 1):
                distancia.append(parche[k +1] - parche[k])
            # resultado
            resultado = min(resultado, solucion(parche, distancia, 0, -1, nuevoT1, nuevoT2, memory))
            j += 1
        print(resultado)
main()