def solve(S, n, m, mem = {}):
    ans = None
    if m <= n: ans = 0
    elif (n, m) in mem: ans = mem[(n,m)]
    else:
        if m+1 != len(S) and n-1 >= 0 and S[n-1] != S[m+1] and S[n] == S[m]:
            ans = max(solve(S,n+1,m,mem), solve(S,n,m-1,mem))
            ans = max(ans,(solve(S,n+1,m-1,mem)))
        elif S[n] == S[m]:
            ans = 1 + solve(S, n+1, m-1, mem)
        else:
            ans = max(solve(S, n+1, m, mem), solve(S, n, m-1, mem))
        mem[(n, m)] = ans
    return ans

if __name__ == "__main__":
    a = "ALGORITHM"
    print(a,solve(a, 0, len(a) - 1, {}))
    a = "RECURSION"
    print(a,solve(a, 0, len(a) - 1, {}))
    a = "REDIVIDE"
    print(a,solve(a, 0, len(a) - 1, {}))
    a = "DYNAMICPROGRAMMINGMANYTIMES"
    print(solve(a, 0, len(a) - 1, {}))