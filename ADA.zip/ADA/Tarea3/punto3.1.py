#punto 3 oficial 

import sys

F = [0]*100

def Fibo():
    global F
    F[0], F[1] = 0, 1
    for i in range(2, 86):
        F[i] = F[i-1] + F[i-2]

def main():
    Fibo()
    for entrada in sys.stdin:
        N = int(entrada.strip())
        if N == 0:
            break
        print(F[N])

main()
