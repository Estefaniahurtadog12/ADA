class Mission:
    def __init__(self, t, b):
        self.t = t
        self.b = b
        self.used = False

def solve(n, m, missions):
    dp = [[0] * (m + 1) for _ in range(n + 1)]

    for i in range(1, n + 1):
        for j in range(m + 1):
            # no hacer la misión actual
            dp[i][j] = dp[i - 1][j]

            # hacer la misión actual si se puede y mejora el valor óptimo
            if j > 0 and missions[i - 1].b >= j and not missions[i - 1].used:
                missions[i - 1].used = True
                dp[i][j] = max(dp[i][j], dp[i - 1][j - 1] + missions[i - 1].t // 2)

    total = 0
    for j in range(m + 1):
        total = max(total, dp[n][j])
    return total

while True:
    n = int(input().strip())
    if n == 0:
        break

    missions = []
    for i in range(n):
        t, b = map(int, input().strip().split())
        missions.append(Mission(t, b))

    missions.sort(key=lambda m: (float("inf") if m.b == 0 else m.t / m.b, m.b), reverse=True)
 

    
    m = sum(m.b for m in missions)
    m = min(m, n)  # no se pueden hacer más de n misiones
    count = 0
    for i in range(n):
        if m == 0:
            break
        if not missions[i].used:
            missions[i].used = True
            m -= 1
            count += 1
    total = 0
    for m in missions:
        total += m.t // 2 if m.used else m.t
    print(total)
