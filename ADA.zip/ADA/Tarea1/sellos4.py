import sys

def main():
    iterador = int(input().strip())  
    for i in range(iterador):
        
        repetidos = set() 
        totales = set() 
        estampillas = {}  
        amigos = int(input().strip())  

        for iterador2 in range(amigos):
            l = list(map(int, input().split()))[1:]
            estampillas[iterador2] = set(l)
            
            repetidos = repetidos.union(estampillas[iterador2].intersection(totales))  
            totales = totales.union(estampillas[iterador2])  

        total = [0] * amigos
        for iterador2 in range(amigos):
            total[iterador2] = len(estampillas[iterador2] - repetidos) / len(totales - repetidos) * 100
        
        print("Case {}:".format(i + 1), *("{0:.6f}%".format(x) for x in total))

main()
