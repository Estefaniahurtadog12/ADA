import sys

def orquesta():
    lines = sys.stdin.readlines()
    i = 0
    resultados = []
    while i < len(lines):
        lineaCompleta = lines[i].split()
        p, n = int(lineaCompleta[0]), int(lineaCompleta[1])
        A = []
        for j in range(n):
            if i + j + 1 >= len(lines):
                break
            A.append(int(lines[i + j + 1].split()[0]))
        if not A:
            i += n + 1
            continue
        izq, der = 1, max(A)
        while izq < der:
            mid = (izq + der) // 2
            usados = 0
            for j in A:
                usados += (j + mid - 1) // mid
            if usados > p:
                izq = mid + 1
            else:
                der = mid
        resultados.append(izq)
        i += n + 1
    print(*resultados)

orquesta()
