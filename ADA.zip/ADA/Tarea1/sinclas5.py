import sys
import heapq
import math

read = stdin.readline
line = read().strip()

while line:
    line = line.split()
    allowed_scores = int(line[0])
    num_instruments = int(line[1])
    # instruments = Pqueue()
    instruments = []

    # adding one score to each instrument group
    line = read().strip().split()
    for i in range(num_instruments):
        # instruments.push(InstrumentGroup(int(line[i]), 1))
        heapq.heappush(instruments,[ -int(line[i]), 1, int(line[i]) ])
        allowed_scores -= 1

    # assign the remaining scores to each Instrument Group according to priority
    while allowed_scores != 0:
        curr_instrument = heapq.heappop(instruments)
        curr_instrument[1] += 1
        # curr_instrument.update_priority()
        curr_instrument[0] = -ceil(curr_instrument[2]/curr_instrument[1])
        # push the current group instrument again to the queue with the updated priority
        # instruments.push(curr_instrument)
        heapq.heappush(instruments, curr_instrument)
        allowed_scores -=1

    # print(instruments.pop()[1])
    print(-heapq.heappop(instruments)[0])
    #print(-heapq.heappop(curr_instrument[0]))
    line = read().strip()