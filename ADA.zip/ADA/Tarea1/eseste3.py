def check(mid, k, n):
    need = 0
    for i in range(n):
        need = arr[i] // mid
        if arr[i] % mid:
            need += 1
        if k < need:
            return False
        k -= need
    return True

def bsearch(k, n):
    lo = 1
    hi = 1010
    mn = 3

    while hi - lo > 2:
        mid = (lo + hi) // 2
        if check(mid, k, n):
            mn = mid
            hi = mid
        else:
            lo = mid + 1
    while mn - 1 and check(mn - 1, k, n):
        mn -= 1
    return mn
    

while True:
    try:
        k, n = map(int, input().split())
        arr = list(map(int, input().split()))
        ans = bsearch(k, n)
        print(ans)
    except:
        break