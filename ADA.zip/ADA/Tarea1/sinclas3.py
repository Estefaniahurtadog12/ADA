import sys
import heapq
def orquesta():
    line = sys.stdin.readline() 
    while line:
        lineaCompleta = line.split()
        p, n = int(lineaCompleta[0]), int(lineaCompleta[1])
        A = [int(x) for x in sys.stdin.readline().split()]
        valorMaximo = max(A)
        colaPrioridad = []
        heapq.heappush(colaPrioridad, 1)
        media = heapq.heappop(colaPrioridad)
        usados = 0
        for i in A:
            usados += (i + media - 1) // media
        while usados > p:
            heapq.heappush(colaPrioridad, media + 1)
            media = heapq.heappop(colaPrioridad)
            usados = 0
            for i in A:
                usados += (i + media - 1) // media
        print(media)
        line = sys.stdin.readline()

orquesta()
