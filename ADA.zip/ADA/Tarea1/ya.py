from sys import stdin
from collections import deque

entra = int(stdin.readline())
equipo = entra
cont = 1
while(entra != 0):
    prinEquipos = {}
    colaEquipos = [deque() for i in range(entra)]
    colaLista = deque()
    for i in range(0, entra):
        queue = deque()
        linea = stdin.readline()
        lineaYa = linea.split()
        for j in range(1, equipo):
            prinEquipos[lineaYa[j]] = i
    print("Escenario #{}".format(cont))
    entra = stdin.readline().strip()
    entra = entra.split()
    while entra[0] != 'STOP':
        if entra[0] == "ENQUEUE":
            indice = prinEquipos.get(entra[1])
            if(len(colaEquipos[indice]) == 0):
                colaLista.append(indice)
            colaEquipos[indice].append(entra[1])
        elif entra[0] == "DEQUEUE":
            indice = colaLista[0]
            print(colaEquipos[indice].popleft())
            if(len(colaEquipos[indice]) == 0):
                colaLista.popleft()
        entra = stdin.readline().strip()
        entra = entra.split()
    print("terminando")
    cont = cont + 1
    equipo = int(stdin.readline())
    entra = equipo
