import sys

def sellos ():

    iterador = int(input())

    for i in range(iterador):
        entrada = int(input()) 
        repetidos = set() 
        pEstampilla = {}
        total = set() 

        

        for i in range(entrada):
            linea = input().split()

            pEstampilla[i] = set(linea[1:])
            
            repetidos = repetidos.union(pEstampilla[i].intersection(total))
            total = total.union(pEstampilla[i])

        resultados = "" 

        for i in range(entrada):
            unicas = len(pEstampilla[i].difference(repetidos))
            resultados += " {0:.6f}%".format((unicas / len(total - repetidos)) * 100)

        print("Caso " + str(i-1) + ":" + resultados)

sellos()