import sys

def orquesta():
    line = sys.stdin.readline() 
    while line:
        lineaCompleta = line.split()
        p, n = int(lineaCompleta[0]), int(lineaCompleta[1])
        A = [int(x) for x in sys.stdin.readline().split()]
        valorMaximo = max(A)
        media = 1
        usados = sum((i + media - 1) // media for i in A)
        while usados  < n:
            media += 1
            usados = sum((i + media - 1) // media for i in A)
        print(media)
        line = sys.stdin.readline()

orquesta()
