from sys import stdin
import heapq

def main():
    lectu = stdin.readline
    entrada = lectu().strip()
    while entrada:
        p, cantInstru = map(int, entrada.split())
        ins = []

        entrada = lectu().strip().split()
        for i in range(cantInstru):
            total = int(entrada[i])
            heapq.heappush(ins, (-total, total))
            p -= total

        while p > 0:
            instru = heapq.heappop(ins)
            instru = (-instru[0] + 1, instru[1])
            heapq.heappush(ins, instru)
            p -= 1

        print(heapq.heappop(ins)[1])
        entrada = lectu().strip()

main()
