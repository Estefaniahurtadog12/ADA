
def main():
    iterador = int(input())
    while(iterador > 0):
        lis1 = []
        lis2 = []
        for iterador in range(iterador):
            #lis1.append(iterador)
            #print(lis1)
            cont = 0
            while(iterador > 0):
                cont = cont + 1
                print(cont)
                lis1.append(cont)


        #print(iterador) //aqui se queda en un bucle infinito
        #for iterador in range(iterador):
            #print(iterador)
            
            
    ##for i in range(4):
        #m = int( input() )
        #print(m)
    #colaGeneral = {}
    #colaEquipos = []
    #with 

main()




