def orquesta():
    while True:
        try:
            lineaCompleta = input().split() # divide en una lista de cadenas
        except EOFError: #final de la entrada (fin del archivo)
            break
        p, n = int(lineaCompleta[0]), int(lineaCompleta[1]) #asigna los dos primeros elementos de lineaCompleta a  p y n.
        A = [int(x) for x in input().split()] # recibe otra entrada, la parte en una lista de cadenas y la convierte en una lista de enteros
        valorMinimo, valorMaximo = 1, max(A) # valor maximo de la lista y valor minimo de lista
        resultado = 1
        while valorMinimo <= valorMaximo: # se repite hasta que sea el valor correcto
            media = (valorMinimo + valorMaximo) // 2
            usados = 0 # cantidad de partituras a usar
            for i in A: # recorro la lista y sumo la cantidad que se necesita calculandolo ( i + media - 1)/media
                usados += (i + media - 1) // media
            if usados <= p: # si los usadors es menor que las partituras entonces el valor maximo de usados será media-1
                valorMaximo = media - 1
                resultado = media # y este es el resultado
            else:
                valorMinimo = media + 1 # de lo contrario se actualiza valor minimo
        print(resultado)

orquesta()