def bin2(A,x):
    N, ans = len(A), None
    if N == 0:
        ans = False
    else:
        low, hi = 0, n
        while low +1 != hi:
            mid = low + ((hi - low)>> 1)
            if A[mid ] <= x:
                low = mid
            else:
                hi = mid
        ans = A[low] ==  x 
    return ans