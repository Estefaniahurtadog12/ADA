from collections import deque

testCases = int(input().strip())
input_data = input().strip().split()
maxLong = int(input_data[0])
cars = int(input_data[1])
if cars <= 0:
    print("La cantidad de automóviles debe ser mayor que 0")
else:
    for _ in range(testCases):
        maxLong *= 100
        carLong = [int(input().strip().split()[0]) for i in range(cars)]
        sides = [deque(), deque()]
        for i in range(cars):
            data = input().strip().split()
            if not data:
                break
            if len(data) != 3:
                print("La entrada debe contener exactamente dos valores")
                continue
            l, side = data
            l = int(l)
            if side[0] == 'l':
                sides[0].append(l)
            else:
                sides[1].append(l)

        side = 0
        moves = 0
        while len(sides[0]) > 0 or len(sides[1]) > 0:
            currentLong = 0
            for j in range(len(sides[side])):
                try:
                    if carLong[sides[side][j]] + currentLong <= maxLong:
                        currentLong += carLong[sides[side].popleft()]
                    else:
                        break
                except IndexError:
                    print("Error: índice fuera de rango")
                    break

            moves += 1
            side = (side + 1) % 2
        print(moves)
