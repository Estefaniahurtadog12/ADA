#Stefania Hurtado --- Tengo miedoooooo

#Lectura de archivo de entrada.
with open("int.txt", "r") as lectura:
    line = lectura.readline()
    while line:
        print(line)
        line = lectura.readline()
qGenaral = [] #cola general 
qEquipos = [] #cola equipos (personal)


