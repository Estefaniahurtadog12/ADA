from collections import deque

def team_queue(num_teams, team_descriptions, commands):
    team_queues = {i: deque() for i in range(num_teams)}
    team_indices = {}
    for i, (num_elements, elements) in enumerate(team_descriptions):
        for element in elements:
            team_indices[element] = i
            team_queues[i].append(element)
    queue = deque()
    output = []
    for command in commands:
        if command[0] == "ENQUEUE":
            element = command[1]
            team = team_indices[element]
            if team not in queue:
                queue.append(team)
            team_queues[team].append(element)
        elif command[0] == "DEQUEUE":
            while team_queues[queue[0]] == 0:
                queue.popleft()
            output.append(team_queues[queue[0]].popleft())
        elif command[] == "STOP":
            

    return output

