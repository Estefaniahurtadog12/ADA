import sys

def porcentaje(entrada, pEstampilla, repetidos, total):
    resultados = "" 
    for i in range(entrada):
        unicas = len(pEstampilla[i].difference(repetidos))
        resultados += " {0:.6f}%".format((unicas / len(total - repetidos)) * 100)
    return resultados

def sellos():
    iterador = int(sys.stdin.readline().strip())
    for i in range(iterador):
        entrada = int(sys.stdin.readline().strip()) 
        repetidos = set() 
        pEstampilla = {}
        total = set() 

        for j in range(entrada):
            linea = sys.stdin.readline().strip().split()
            pEstampilla[j] = set(linea[1:])
            repetidos |= pEstampilla[j].intersection(total)
            total |= pEstampilla[j]

        resultados = porcentaje(entrada, pEstampilla, repetidos, total)
        print("Case " + str(i + 1) + ":" + resultados)

sellos()
