from sys import stdin
import heapq


def main():
    lectu = stdin.readline
    entrada = lectu().strip()
    while entrada:
        p, cantInstru = map(int, entrada.split())
        ins = []
        
        entrada = lectu().strip().split()
        for i in range(cantInstru):
            total = int(entrada[i])
            heapq.heappush(ins, (-total, total))
            p -= total

        while ins:
            instru = heapq.heappop(ins)
            if p > 0:
                p -= 1
                instru = (-instru[0] + 1, instru[1])
                heapq.heappush(ins, instru)
            else:
                break
        #print(instru[1])
        print(-heapq.heappop(ins)[0])
        entrada = lectu().strip()

main()
