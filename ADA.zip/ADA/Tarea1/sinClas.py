import sys 
import heapq

def orquesta():
    for line in sys.stdin:
        lineaCompleta = line.split() #divide la línea en una lista de cadenas
        p, n = int(lineaCompleta[0]), int(lineaCompleta[1])
        A = [int(x) for x in sys.stdin.readline().split()]
        valorMaximo = max(A)
        colaPrioridad = []
        heapq.heappush(colaPrioridad, 1) #agrega un elemento con valor 1 a la cola de prioridad.
        while True:
            media = heapq.heappop(colaPrioridad) #quita el elemento con valor mínimo de la cola de prioridad.valor a evaluar.
            usados = 0
            for i in A:
                usados += (i + media - 1) // media
            if usados <= p: # si usados es menor o igual a la cantidad de partituras es un valor valido
                print(media)
                break
            else:
                heapq.heappush(colaPrioridad, media + 1)
                if media + 1 > valorMaximo: #valor menor que el esperado
                    break

orquesta()
