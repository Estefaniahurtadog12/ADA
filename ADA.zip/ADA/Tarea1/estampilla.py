import sys

# Lee el número de casos de prueba
k = int(input().strip())

# Contador de casos de prueba
case_number = 1

# Procesa cada caso de prueba
while k > 0:
    # Número de amigos
    n = int(input().strip())

    # Diccionario de estampillas únicas por amigo
    unique_stamps = {}

    # Procesa la lista de estampillas por amigo
    for i in range(n):
        # Lee la cantidad de estampillas y la lista
        m, *stamps = map(int, input().strip().split())

        # Agrega las estampillas únicas a la lista
        for stamp in stamps:
            if stamp not in unique_stamps:
                unique_stamps[stamp] = i

    # Calcula la cantidad de estampillas únicas
    unique_count = len(unique_stamps)

    # Calcula el porcentaje de ingresos para cada amigo
    income_percents = [0.0] * n
    for stamp, owner in unique_stamps.items():
        income_percents[owner] += 100.0 / unique_count

    # Imprime los resultados
    print("Case {}: {}".format(case_number, ' '.join("{:.6f}%".format(p) for p in income_percents)))

    # Actualiza el contador de casos de prueba
    case_number += 1
    k -= 1
