import queue

def ferry_crossing(n, t, m, cars):
    left_cars = queue.Queue()
    right_cars = queue.Queue()
    time = 0
    bank = "left"
    result = []
    
    for car in cars:
        arrival_time, side = car
        if side == "left":
            left_cars.put(arrival_time)
        else:
            right_cars.put(arrival_time)
        if bank == "left":
            while not left_cars.empty() and n > 0:
                time = max(time, left_cars.get())
                n -= 1
            if n > 0 or not right_cars.empty():
                time += t
                bank = "right"
        else:
            while not right_cars.empty() and n > 0:
                time = max(time, right_cars.get())
                n -= 1
            if n > 0 or not left_cars.empty():
                time += t
                bank = "left"
        result.append(time)
    return result

num_cases = int(input())
for i in range(num_cases):
    n, t, m = map(int, input().split())
    cars = [tuple(map(str, input().split())) for _ in range(m)]
    cars = [(int(time), side) for time, side in cars]
    result = ferry_crossing(n, t, m, cars)
    for res in result:
        print(res)
    if i < num_cases - 1:
        print()
