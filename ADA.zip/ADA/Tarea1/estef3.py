import heapq
from sys import stdin
entra = stdin.readline()
comando =entra.split()
print(comando)
def main():
    while entra != 0:
        p, n = [x for x in input().strip().split()]
        if p == 0 and n == 0:
            break
        musicians = [int(x) for x in input().strip().split()]
        musicians.sort(reverse=True)
        i = 0
        while p >0 and i < n:
            p -= (musicians[i] + 1) // 2
            i += 1
        if p >=0:
            print(musicians[i-1])
        else:
            print((musicians[i-1] * 2 - 2 * p)) # 12
        

main()
