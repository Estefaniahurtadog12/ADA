from queue import Queue

LEFT = 0 
RIGHT = 1

c = int(input().strip()) #Entrada (casos de prueba ingresados por el usuario)
for k in range(c): # iterador la cantidad de veces que indiquen los casos de prueba
    n, t, m = map(int, input().strip().split()) #  n = cantidad max Autos - t= tiempo de cruce - m= num total autos
    cars = [Queue(), Queue()] # 2 colas
    tiempo = [0] * m #tiempo en pasar de izquierda a derecha o derecha izqueierda
    for i in range(m): #se informa tiempo de llegada y agregamos a la cola dependiente si es left o right
        llegada, bank = input().strip().split()
        llegada = int(llegada)
        if bank == 'left':
            cars[LEFT].put((i, llegada))
        else:
            cars[RIGHT].put((i, llegada))

    time = 0 #tiempo inicializado en 0
    index = LEFT #index inicializado en left

    while not (cars[LEFT].empty() and cars[RIGHT].empty()): #ocurre cuando ambas colas estan vacias
        primero = float('inf')
        if not cars[LEFT].empty():
            primero = cars[LEFT].queue[0][1] # auto mas antiguo
        if not cars[RIGHT].empty():
            primero = min(primero, cars[RIGHT].queue[0][1])

        time = max(time, primero) #tempo llegada mas temprano

        contCar = 0
        while not cars[index].empty() and contCar < n and cars[index].queue[0][1] <= time:
            i, llegada = cars[index].get()
            tiempo[i] = time + t
            contCar += 1
        time += t
        index = RIGHT if index == LEFT else LEFT
    for i in range(m):
        print(tiempo[i])
        
    if k != c-1:
        print("") #espacio en la salida
        #print(" ")
   