from collections import defaultdict

def team_queue_simulation():
    kcase = 0
    while True:
        n = int(input())
        if n == 0:
            break
        team_queues = defaultdict(list)
        team_order = []
        team_members = {}
        for i in range(n):
            m = int(input())
            for j in range(m):
                t = int(input())
                team_members[t] = i
        print("Scenario #{}".format(kcase + 1))
        kcase += 1
        while True:
            command = input().split()
            if command[0] == "STOP":
                break
            elif command[0] == "ENQUEUE":
                t = int(command[1])
                team = team_members[t]
                if team not in team_order:
                    team_order.append(team)
                team_queues[team].append(t)
            else:
                team = team_order[0]
                print(team_queues[team].pop(0))
                if not team_queues[team]:
                    team_order.pop(0)
        print()

team_queue_simulation()