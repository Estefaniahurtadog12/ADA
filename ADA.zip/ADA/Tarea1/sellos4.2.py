import sys

def porcentaje(entrada, pEstampilla, repetidos, total):
    resultados = "" 
    for i in range(entrada):
        unicas = len(pEstampilla[i].difference(repetidos))
        resultados += " {0:.6f}%".format((unicas / len(total - repetidos)) * 100)
    return resultados

def sellos():
    iterador = int(sys.stdin.readline().strip())
    for i in range(iterador):
        entrada = int(sys.stdin.readline().strip()) 
        repetidos = set() 
        pEstampilla = {}
        total = set() 

        for i in range(entrada):
            linea = sys.stdin.readline().strip().split()
            pEstampilla[i] = set(linea[1:])
            repetidos |= pEstampilla[i].intersection(total)
            total |= pEstampilla[i]

        resultados = porcentaje(entrada, pEstampilla, repetidos, total)
        print("Case " + str(i) + ":" + resultados)

sellos()
