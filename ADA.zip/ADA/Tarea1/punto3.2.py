def check(mid, k, n):
    need = sum((arr[i] + mid - 1) // mid for i in range(n))
    return need <= k

def bsearch(k, n):
    lo = max(arr)
    hi = sum(arr)
    mn = 3

    while lo < hi:
        mid = (lo + hi) // 2
        if check(mid, k, n):
            hi = mid
        else:
            lo = mid + 1

    return lo

while True:
    try:
        k, n = map(int, input().split())
        arr = [list(map(int, input().split())) for i in range(k)]
        ans = [bsearch(k, n) for k, n in arr]
        print(*ans)
    except:
        break
