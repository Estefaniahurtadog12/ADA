
with open("int.txt") as comando:
    for comandos in comando:
        comandos = comando.readlines()[0].rstrip()
        print(comando)
# Creo un diccionario para almacenar los equipos y sus elementos
equipos = {}

# Creo una lista para almacenar la cola de equipos
cola_equipos = []

# Procesar los comandos
for comando in comandos:
    if comando.startswith("ENQUEUE"):
        # Obtener el nombre del equipo y el elemento
        equipo, elemento = comando.split()[1:]

        # Agregar el elemento al equipo
        if equipo not in equipos:
            equipos[equipo] = [elemento]
        else:
            equipos[equipo].append(elemento)

        # Agregar el equipo y el elemento a la cola de equipos
        cola_equipos.append((equipo, elemento))
    elif comando == "DEQUEUE":
        # Procesar el primer elemento en la cola de equipos
        equipo, elemento = cola_equipos.pop(0)
        equipos[equipo].remove(elemento)
        print(elemento)
    elif comando == "STOP":
        break
    elif comando == "0":
        print("Fin")
