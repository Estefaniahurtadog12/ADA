def binario(A,x,low,hi):
    ans = None
    if low == hi:
        ans = False
    elif low +1 == hi:
        ans = A[low] == x
    else:
        mid = ( (hi - low) >> 1)
        if A[mid] < x :
            ans = binario(A,x,mid,hi)
        elif A[mid] > x :
            ans = binario (A, x, low, mid)
        else:
            ans = True

    return ans

    ### algoritmo de busqueda binaria por recursion
    