queue = []
with open("entrada.txt", "r") as file:
    for line in file:
        command = line.strip().split()
        if command[0] == "ENQUEUE":
            queue.append(int(command[1]))
        elif command[0] == "DEQUEUE":
            if len(queue) > 0:
                print(queue.pop(0))
            else:
                print("ya esta en la la cola")
        elif command[0] == "STOP":
            
            break
print(queue)
