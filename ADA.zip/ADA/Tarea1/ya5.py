from sys import stdin
from collections import deque

def entrada():
    return int(stdin.readline())

def equipoNew(numEquipo):
    equipos = {}
    equiposCola = [deque() for _ in range(numEquipo)]
    for i in range(numEquipo):
        linea = stdin.readline().split()
        for j in range(1, len(linea)):
            equipos[linea[j]] = i
    return equipos, equiposCola

def condi():
    return stdin.readline().strip().split()

def enqueue(equipos, equiposCola, prinCola, entra1):
    indice = equipos[entra1[1]]
    if not equiposCola[indice]:
        prinCola.append(indice)
    equiposCola[indice].append(entra1[1])

def dequeue(equiposCola, prinCola):
    if prinCola:
        indice = prinCola[0]
        print(equiposCola[indice].popleft())
        if not equiposCola[indice]:
            prinCola.popleft()

def escenario(numEscenario, numEquipo):
    equipos, equiposCola = equipoNew(numEquipo)
    prinCola = deque()
    print("Scenario #{}".format(numEscenario))
    entra1 = condi()
    while entra1[0] != "STOP":
        if entra1[0] == "DEQUEUE":
            dequeue(equiposCola, prinCola)
        elif entra1[0] == "ENQUEUE":
            enqueue(equipos, equiposCola, prinCola, entra1)
        entra1 = condi()
    print("")

numEquipo = entrada()
numEscenario = 1
while numEquipo != 0:
    escenario(numEscenario, numEquipo)
    numEscenario += 1
    numEquipo = entrada()
