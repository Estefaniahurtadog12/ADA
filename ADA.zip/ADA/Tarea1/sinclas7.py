from sys import stdin
from math import ceil
import heapq

def main():
    lectu = stdin.readline
    entrada = lectu().strip()

    while entrada:
        partituras, cantInstru = map(int, entrada.split()) 
        ins = []
        entrada = lectu().strip().split()
        for i in range(cantInstru):
            total = int(entrada[i])
            heapq.heappush(ins, [-total, 1, total])
            partituras -= 1

        while partituras > 0:
            posInstru = heapq.heappop(ins)
            posInstru[1] += 1
            posInstru[0] = -ceil(posInstru[2]/posInstru[1])
            heapq.heappush(ins, posInstru)
            partituras -= 1
        print(-heapq.heappop(ins)[0])
        entrada = lectu().strip()

main()
