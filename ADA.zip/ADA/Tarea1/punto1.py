class TeamQueue:
    def __init__(self, teams):
        self.teams = {i:[] for i in range(teams)} # dictionary to store the team information
        self.next_element = [0 for _ in range(teams)] # list to store the indices of the next element in each team list
        
    def enqueue(self, element, team):
        self.teams[team].append(element) # append the element to the appropriate team list
        self.next_element[team] += 1 # update the index of the next element for that team

    def dequeue(self):
        # find the team list with the smallest index of the next element
        team = self.next_element.index(min(self.next_element))
        element = self.teams[team][self.next_element[team]]
        self.next_element[team] += 1 # update the index of the next element for that team
        return element

def process_commands(teams, commands):
    tq = TeamQueue(teams)
    for command in commands:
        cmd, *args = command.split()
        if cmd == "ENQUEUE":
            tq.enqueue(int(args[0]), int(args[1]))
        elif cmd == "DEQUEUE":
            print(tq.dequeue())
        elif cmd == "STOP":
            break

t = int(input())
while t:
    teams = int(input())
    commands = []
    for _ in range(teams):
        n, team = input().split()
        for i in range(int(n)):
            commands.append("ENQUEUE {} {}".format(i, team))
    commands += [input() for _ in range(int(input()))]
    process_commands(teams, commands)
    t -= 1
    