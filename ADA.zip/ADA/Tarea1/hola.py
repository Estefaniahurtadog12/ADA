def main():
    iterador = int(input())
    while(iterador > 0):
        lis1 = []
        lis2 = []
        print([iterador])


main()



