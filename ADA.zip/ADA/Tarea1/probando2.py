#Stefania Hurtado --- Tengo miedoooooo

#Lectura de archivo de entrada.
with open('pro.txt', 'r') as f:
    lineas = f.readlines()
lineas_sin_espacios = [linea.replace(" ", "") for linea in lineas]
print(lineas_sin_espacios)

opcion1 = "ENQUEUE"
opcion2 = "DEENQUEUE"
opcion3 = "STOP"
opcion4 = "0"
qGenaral = [] #cola general 
qEquipos = [] #cola equipos (personal)
if lineas.startswith("HOLA"):
    if True:
        qEquipos.put(lineas.startswith[i])




