""" Desarrollado por Sebastian Tobar Quintero 

Descripción: ... """

import sys
  
K = int(sys.stdin.readline()) # Numero de casos

for i in range(K):
    pe = {} # Relación persona-estampillas
    er = set() # Conjunto de estampillas repetidas
    et = set() # Conjunto de estampillas totales

    N = int(sys.stdin.readline()) # Numero de amigos

    for j in range(N):
        l = sys.stdin.readline().split()

        pe[j] = set(l[1:])
        
        er = er.union(pe[j].intersection(et)) # Si están repetidas se añaden a er
        et = et.union(pe[j]) # Se añaden las nuevas estampillas al total

    ans = "" 

    for j in range(N): # Se calcula el resultado y se añade a la cadena 'ans'
        ans += " {0:.6f}%".format((len(pe[j] - er)/len(et - er)) * 100)

    print("Case " + str(i + 1) + ":" + ans) # Y se imprime

