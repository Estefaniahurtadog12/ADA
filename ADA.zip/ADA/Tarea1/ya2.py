from sys import stdin ## leer archivo de entrada (input definido)
from collections import deque # nos permite manipular la cola por ambos lados

entra = int(stdin.readline())
equipo = entra
cont = 1
while(entra != 0):
    prinEquipos = {} #informacion para guardar en diccionario
    colaEquipos = deque() ## creamos la cola utilizando esta funcion para manipular nuestra cola con los metodos ya sugeridos por dicha funcion
    colaLista = deque()
    for i in range(0,equipo): #desde la primera posicion hasta el numero generado por la entrada 
        cola = deque()
        colaEquipos.append(cola)
        linea = stdin.readline()
        lineaYa = linea.split()
        for j in range(1,len(lineaYa)):
            prinEquipos[lineaYa[j]] = i
    print("Escenario #{}".format(cont))
    entra = stdin.readline().strip()##lee lo que hay en la linea y elimina los espacios que se encuentren en la linea
    entra = entra.split() #la cadena me la vuelve una lista con particiones, para acceder al dato desde la posición
    while(entra[0]) != 'STOP':
        if(entra[0] == "ENQUEUE"):
            indice = prinEquipos.get(entra[1])
            if(len(colaEquipos[indice]) == 0):
                colaLista.append(indice)
            colaEquipos[indice].append(entra[1])
        elif(entra[0] == "DEQUEUE"):
            indice = colaLista[0]
            print(colaEquipos[indice].popleft()) #solo elimina por la izquierda
            if not colaEquipos[indice]:
                if colaEquipos[indice].popleft() == 0:
                    colaLista.popleft()
                
            #if(len(colaEquipos[indice].popleft() == 0)):
                #colaLista.popleft()
        entra = stdin.readline().strip()
        entra = entra.split()
print("terminando")
cont = cont + 1
equipo = int(stdin.readline())
entra = equipo







