iterador = int(input())
i = int
while(iterador > 0):
    lis1 = []## cantidad de veces que ingresa un equipo o itera ---- iterador
    lis2 = []## Linea completa
    lis3 = []## lista de equipos general
    lis4 = []## participantes del equipo, ultima lista actualizada
    for i in range(iterador):
        lis1.append(iterador)
        #print(lis1)
        with open("int.txt") as entrada:
            for linea in entrada:
                linea =entrada.readline()[0:].split()
                #print(linea)
                lis2.append([linea[1:]])
                #print(lis2) 
                #print(lis2[1:]) ##--- me imprime las listas con la linea 2 muchas veces
                if len(linea)>0:
                    lis4.append(linea)
                    len(lis2)*0
                    repeticiones = linea[0]
                    #print(repeticiones)
                    print(lis4[0:])
                elif linea not in lis4:
                    lis3.append(linea.extend(linea))
                    #print(lis3)
                    #lis3.extend(linea[:0])
                    #print(lis3)
                elif linea in lis4:
                    lis3.append[1:](linea.extend(linea))
                    print(lis3)
            

            ################################ ESTO ES LO PROFIN.PY########################
           
                


                        #break
                   # else:
                    #    for linea in entrada:
                     #       linea =entrada.readline()[0:].strip()
                #print(linea)
                            #lis2.append([linea])
                            #print(lis2)



    break