def main():
    # freopen("WA.txt", "w", stdout)
    while True:
        try:
            A, B = map(int, input().split())
        except EOFError:
            break

        Count = 1
        dA = 0
        dB = 0

        while dB - dA < A:
            dA += A
            dB += B
            Count += 1

        print(Count)

if __name__ == "__main__":
    main()
