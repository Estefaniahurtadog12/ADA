from queue import Queue

LEFT = 0 
RIGHT = 1

c = int(input().strip()) #Entrada (casos de prueba ingresados por el usuario)
for _ in range(c):
    n, t, m = map(int, input().strip().split()) #  n = cantidad max Autos - t= tiempo de cruce - m= num total autos
    cars = [Queue(), Queue()]
    uploaded_time = [0] * m
    for i in range(m):
        arrival_time, bank = input().strip().split()
        arrival_time = int(arrival_time)
        if bank == 'left':
            cars[LEFT].put((i, arrival_time))
        else:
            cars[RIGHT].put((i, arrival_time))

    time = 0
    index = LEFT
    while not (cars[LEFT].empty() and cars[RIGHT].empty()):
        earliest_car = float('inf')
        if not cars[LEFT].empty():
            earliest_car = cars[LEFT].queue[0][1]
        if not cars[RIGHT].empty():
            earliest_car = min(earliest_car, cars[RIGHT].queue[0][1])

        time = max(time, earliest_car)

        car_count = 0
        while not cars[index].empty() and car_count < n and cars[index].queue[0][1] <= time:
            i, arrival_time = cars[index].get()
            uploaded_time[i] = time + t
            car_count += 1

        time += t
        index = RIGHT if index == LEFT else LEFT

    for i in range(m):
        print(uploaded_time[i])
    if c > 1:
        print("")