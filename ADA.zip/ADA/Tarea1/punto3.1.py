def check(mid, k, n):
    need = sum((arr[i] + mid - 1) // mid for i in range(n))
    return need <= k

def bsearch(k, n):
    lo = 1
    hi = sum(arr)
    mn = 3

    while lo < hi:
        mid = (lo + hi) // 2igu
        if check(mid, k, n):
            hi = mid
        else:
            lo = mid + 1

    return hi

try:
    while True:
        k, n = map(int, input().split())
        arr = list(map(int, input().split()))
        ans = bsearch(k, n)
        print(ans)
except EOFError:
    pass
