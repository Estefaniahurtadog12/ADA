import sys
import heapq
import math

class GrupoMusica(object):
    def __init__(self, total, partitura): #construcotor
        self.total = total
        self.prioridad = total
        self.partitura = partitura
    def __lt__(self, other): # self < other
        return self.prioridad > other.prioridad

def solve(p, n, mus):
    heapq.heapify(mus)
    while p > 0:
        p -= 1
        grupo = heapq.heappop(mus)
        grupo.partitura += 1
        grupo.prioridad = math.ceil(grupo.total/grupo.partitura)
        heapq.heappush(mus, grupo)
        
    return mus[0].prioridad

input_data = sys.stdin.read().strip().split('\n')
input_data = input_data[1:]
index = 0

while index < len(input_data):
    p = int(input_data[index].split()[0])
    n = int(input_data[index].split()[1])
    index += 1
    
    #mus = list(map(int, input_data[index].split()))
    mus = list()
    for data in input_data[index].split():
        p -= 1
        mus.append(GrupoMusica(int(data),1))
    
    
    index += 1
    print(solve(p, n, mus))
