import sys


def dna(cadSelect, iter, numCambios,nucleotidos):
    global lisCombi 
    cadenaVacia = str()
    if numCambios == 0 or iter == len(cadSelect):
        lisCombi.append(list(cadSelect))
    else:
        i = 0
        while i < len(nucleotidos):
            if cadSelect[iter] != nucleotidos[i]:
                letraSinCambi = cadSelect[iter]
                cadSelect[iter] = nucleotidos[i]
                dna(cadSelect, iter + 1, numCambios - 1, nucleotidos)
                cadSelect[iter] = letraSinCambi
            else:
                dna(cadSelect, iter + 1, numCambios, nucleotidos)
            i += 1


nucleotidos = ['A', 'C', 'G', 'T']
cases = int(sys.stdin.readline())
for case in range(cases):
    lisCombi = []
    cadenaVacia, maxcambi = map(int, sys.stdin.readline().split())
    cadenaIngresada = list(sys.stdin.readline().strip())
    dna(cadenaIngresada, 0, maxcambi,  nucleotidos)
    print(len(lisCombi))
    print("\n".join(map(lambda element: "".join(element), lisCombi)))

