import sys
# Esta función se encarga de leer los valores de L y N desde la entrada estándar
def read_inputs():
    line = sys.stdin.readline().strip()
    L, N = map(int, line.split())
    return L, N
# Esta función se encarga de leer las coordenadas y radios de los círculos
# y almacenarlos en el arreglo P como pares de enteros
def calculate_coordinates(x, r):
    return (x - r, x + r)
def read_circles(N, P):
    i = 0
    while i < N:
        line = sys.stdin.readline().strip()
        x, r = map(int, line.split())
        P.append(calculate_coordinates(x, r))
        i += 1
# Esta función se encarga de calcular la respuesta para un caso de prueba específico
def calculate_answer(L, N, P):
    # Ordenar los pares de coordenadas por la coordenada izquierda
    P.sort()
    # Inicializar la posición en 0, el índice de la lista en 0 y la respuesta en N
    pos = 0
    i = 0
    ans = N
    # Mientras la posición actual sea menor que la longitud L:
    while pos < L:
        # Inicializar auxiliar en la posición actual
        aux = pos    
        # Mientras haya círculos que intersecten con la posición actual:
        while i < N and P[i][0] <= pos:
            # Actualizar el auxiliar con la coordenada derecha del círculo actual
            aux = max(aux, P[i][1])
            i += 1
        # Si el auxiliar no cambió, no se pueden cubrir más posiciones
        if aux == pos:
            ans = -1
            pos = L
        else:
            # Actualizar la posición con el auxiliar y disminuir la respuesta en 1
            pos = aux
            ans -= 1
    # Si no se pudieron cubrir todas las posiciones, retornar -1, sino retornar la respuesta
    return ans
# Esta función se encarga de escribir la respuesta en la salida estándar
def write_answer(ans):
    print(ans)

def main():
    while True:
        L, N = read_inputs()
        if L == 0:
            break
        P = []
        read_circles(N, P)
        ans = calculate_answer(L, N, P)
        write_answer(ans)

if __name__ == '__main__':
    sys.exit(main())
