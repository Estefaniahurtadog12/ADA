from sys import stdin

def textSegmentation5(S, P,N ,m, k,cadena):
    n = str()
    if S == 0:
        # Concatenate the elements of P into a single string
        for i in P:
            n += i
        k.append(n)
    elif m == len(P):
        # Concatenate the elements of P into a single string
        for i in P:
            n += i
        k.append(n)
    else:
        for i in range(4):
            if P[m] == cadena[i]:
                textSegmentation5(S, P,N,m+1, k, cadena)
            else:
                tmp = P[m]
                P[m] = cadena[i]
                textSegmentation5(S-1,P,N,m+1,k,cadena)
                P[m] = tmp

def main():
    cases = int(stdin.readline())
    while cases > 0:
        #cont += 1
        vals = list(map(int, stdin.readline().split()))
        n, s = vals[0], vals[1]
        p = stdin.readline().split()
        p = list(p[0])
        print(p)
        sols = []
        cadena = [ 'A','C','G','T' ]    
        textSegmentation5(s, p,n ,0, sols,cadena  )
        tam = (len(sols))
        print(tam)

        i = 0
        while i < tam:
            print(sols[i])
            i += 1
        # imprimen los datos correspondientes a la solución
        cases -= 1
    
main()