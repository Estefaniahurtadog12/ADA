
from functools import reduce

def restar(x,y): 
    return y-x
    
result=[]
list_index=[]

def job_scheduling(jobs):
    global result
    prev_finish = 0
    jobs_parciales = []
    if len(jobs) == 0:
        return 1
    else:
        for job in jobs:
            start, finish = job          # 0, 20
            rango = range(start,finish+1)  # rango 0 - 20
            if start == 0:
                result.append(job)
                prev_finish = finish
            elif prev_finish in rango:
                #print(prev_finish,'prev_finish')
                #print(job,'adicionar')
                jobs_parciales.append(job)
                prev_finish = finish
        if len(jobs_parciales) > 0:
            jobs_parciales.sort(key=lambda x: x[1], reverse=True)
            result.append(jobs_parciales[0])
        n = 0
        for list in result:
            resultado = reduce(restar, list)
            n += resultado

        if n >= 40:
            return f'longitud {n}, Ya estan las estaciones completas,'
        else:
            for item in result:
              jobs.remove(item)
            return job_scheduling(jobs_parciales)

       

#jobs = [[0,10],[10,30],[30,50]]a
#jobs = [[0,20],[8,28],[10,40]]
#jobs = [[0,20],[8,28], [10,40] ] # oeriginal
#jobs = [[0,10],[3,19],[10,30],[27,33],[30,50]]
jobs = [[-10,10],[0,20],[10,30],[20,40],[30,50]]
#jobs = [[-2,40],[-3,111],[-28,108],[-13,99],[6,62],[40,44],[40,48]]
print(job_scheduling(jobs))
print(result)
