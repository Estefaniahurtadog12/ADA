import sys 
def generate_mutations():
    T = int(sys.stdin.readline().strip())
    for _ in range(T):
        N, K = map(int, sys.stdin.readline().split())
        sequence = sys.stdin.readline().strip()
        bases = ['A', 'C', 'G', 'T']
        mutations = set()
        def mutate(sequence, K):
            if K == 0:
                mutations.add(sequence)
            else:
                new_sequences = [sequence[:i] + base + sequence[i+1:] for i in range(N) for base in bases]
                for new_sequence in new_sequences:
                    mutate(new_sequence, K-1)
        mutate(sequence, K)
        mutations = sorted(list(mutations))
        print(len(mutations))
        for mutation in mutations:
            print(mutation)

# Example usage
generate_mutations()