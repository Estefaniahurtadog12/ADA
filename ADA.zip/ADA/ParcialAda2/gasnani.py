from sys import stdin

def max_gas_stations_to_close(L, G, gas_stations):
    intervals = []
    for x, r in gas_stations:
        intervals.append((max(0, x-r), min(L, x+r)))
    intervals.sort()
    
    farthest_point = 0
    closed_stations = 0
    i = 0
    while i < len(intervals):
        if intervals[i][0] > farthest_point:
            return -1
        max_end = intervals[i][1]
        while i < len(intervals) - 1 and intervals[i+1][0] <= farthest_point:
            i += 1
            max_end = max(max_end, intervals[i][1])
        while i < len(intervals) - 1 and intervals[i+1][0] == intervals[i][0]:
            i += 1
            max_end = max(max_end, intervals[i][1])
        closed_stations += 1
        farthest_point = max_end
        i += 1
    if farthest_point < L:
        return -1
    return G - closed_stations
L = 40
G = 5
#gas_stations = [(5, 5), (20, 10), (40, 10)]
#gas_stations = [(5, 5), (11, 8), (20, 10),(30,3),(40,10)]
gas_stations = [(0, 10), (10,10), (20, 10),(30,10),(40,10)]
result = max_gas_stations_to_close(L, G, gas_stations)
print(result) # Output: 0


