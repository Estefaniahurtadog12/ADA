import sys


def dna(cadSelect, iter, numCambios, lisCombi, nucleotidos):
    
    cadenaVacia = str()
    if numCambios == 0 or iter == len(cadSelect):
        lisCombi.append(list(cadSelect))
    else:
        i = 0
        while i < len(nucleotidos):
            if cadSelect[iter] != nucleotidos[i]:
                tmp = cadSelect[iter]
                cadSelect[iter] = nucleotidos[i]
                dna(cadSelect, iter + 1, numCambios - 1, lisCombi, nucleotidos)
                cadSelect[iter] = tmp
            else:
                dna(cadSelect, iter + 1, numCambios, lisCombi, nucleotidos)
            i += 1


nucleotidos = ['A', 'C', 'G', 'T']
cases = int(sys.stdin.readline())
for case in range(cases):
    lisCombi = []
    cadenaVacia, maxcambi = map(int, sys.stdin.readline().split())
    cadenaIngresada = list(sys.stdin.readline().strip())
    dna(cadenaIngresada, 0, maxcambi, lisCombi, nucleotidos)
    print(len(lisCombi))
    print("\n".join(map(lambda element: "".join(element), lisCombi)))

