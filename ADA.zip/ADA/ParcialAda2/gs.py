while True:
    L, N = map(int, input().split())
    if L == 0:
        break
    P = []
    for i in range(N):
        x, r = map(int, input().split())
        P.append((x-r, x+r))
    P.sort()
    pos, i, ans = 0, 0, N
    while pos < L:
        aux = pos
        while i < N and P[i][0] <= pos:
            aux = max(aux, P[i][1])
            i += 1
        if aux == pos:
            break
        pos = aux
        ans -= 1
    print(-1 if pos < L else ans)