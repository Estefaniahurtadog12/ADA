#aceptado por uva, utilizanod memorizacion y programaicon dinamica
#cambiar variables y comentarios 
#explciar 
#punto 11335 
import sys
# PRIMER CODIGO , ES EL QUE MENOS TIEMPO SE DEMORA.S
def main()
      # memori para almacenar los resultados previamente calculados

    def dp(posLadron, veloPolicia,memori = {}):
        if posLadron[0] < 0 or posLadron[1] < 0 or veloPolicia[0] < 0 or veloPolicia[1] < 0:
            return float('inf')  # caso base, devuelve infinito para evitar salirse de los límites

        # Si ya se ha calculado el resultado, lo devuelve directamente de la memori
        if (tuple(posLadron), tuple(veloPolicia)) in memori:
            return memori[(tuple(posLadron), tuple(veloPolicia))]

        cop_pos = [0, 0]
        k = 0

        # calcula el número de iteraciones necesarias para que el policía alcance al ladrón
        while cop_pos[0] < posLadron[0] or cop_pos[1] < posLadron[1]:
            posLadron[0] += thief_speed[0]
            posLadron[1] += thief_speed[1]
            veloPolicia[0] += 1
            veloPolicia[1] += 1
            cop_pos[0] += veloPolicia[0]
            cop_pos[1] += veloPolicia[1]
            k += 1

        # guarda el resultado en la memori y lo devuelve
        memori[(tuple(posLadron), tuple(veloPolicia))] = k
        return k

    for line in sys.stdin:
        a, u, v = map(int, line.strip().split())
        veloPolicia = [0, 0]
        thief_speed = [u, v]
        posLadron = [a, 0]
        print(dp(posLadron, veloPolicia,{}))

main()