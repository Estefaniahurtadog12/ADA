def prim(grafo,s,n):
    queue = []
    visited = [False for i in range(n)]
    for i in range(n):
        c[i] = float("inf")
        p[i] = -1

    total = 0
    c[s] = 0
    heappush(queue, (0, s))
    while len(queue) > 0:
        peso, u = heappop(queue)
        visited[u] = True
        if peso == c[u]:
            total += peso
            for (v,pesoAux) in grafo[u]:
                if not visited[v] and pesoAux < c[v]:
                    p[v] = u
                    c[v] = pesoAux
                    heappush(queue, (c[v], v))