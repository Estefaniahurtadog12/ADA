test_cases = int(input())

for case in range(test_cases):
    n, *shoes = map(int, input().split())
    ara = [0]

    check = [[0, 0] for _ in range(2*n+1)]

    for j in range(1, 2*n+1):
        p = shoes[j-1]
        ara.append(p)
        if not check[p][0]:
            check[p][0] = j
        else:
            check[p][1] = j

    ans = 0
    for j in range(1, 2*n, 2):
        p = ara[j]
        q = ara[j+1]
        if ara[j] == ara[j+1]:
            continue

        ara[check[p][1]] = q
        ara[j+1] = p

        temp1 = check[q][1]
        temp2 = check[p][1]
        check[q][0] = min(temp1, temp2)
        check[q][1] = max(temp1, temp2)
        ans += 1

    print(ans)
