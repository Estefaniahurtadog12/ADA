import math

def can_reach(sensor1, sensor2, ecd):
    return (sensor1[0] - sensor2[0])**2 + (sensor1[1] - sensor2[1])**2 <= ecd**2

def get_graph(sensors, ecd):
    n = len(sensors)
    graph = [[] for _ in range(n)]
    for i in range(n):
        for j in range(i + 1, n):
            if can_reach(sensors[i], sensors[j], ecd):
                graph[i].append(j)
                graph[j].append(i)
    return graph

def bfs(graph, start, target):
    n = len(graph)
    visited = [False] * n
    visited[start] = True
    queue = [(start, 0)]
    while queue:
        node, dist = queue.pop(0)
        if node == target:
            return dist
        for neighbor in graph[node]:
            if not visited[neighbor]:
                visited[neighbor] = True
                queue.append((neighbor, dist + 1))
    return math.inf

def find_min_ecd(sensors, receivers):
    n = len(sensors)
    graph = get_graph(sensors, 1)
    min_ecd = 1
    max_ecd = 141421  # diagonal of a 100000x100000 rectangle
    while min_ecd < max_ecd:
        mid_ecd = (min_ecd + max_ecd + 1) // 2
        graph_ecd = get_graph(sensors, mid_ecd)
        if sum(bfs(graph_ecd, i, j) for i in receivers for j in receivers) == bfs(graph, 0, n - 1):
            min_ecd = mid_ecd
        else:
            max_ecd = mid_ecd - 1
    return min_ecd

# Ejemplo de uso
sensors = [(1, 1), (2, 1), (8, 7)]
receivers = [0, 1]  # los dos primeros sensores tienen receptor/transmisor
min_ecd = find_min_ecd(sensors, receivers)
print(math.ceil(min_ecd))  # imprime 4
