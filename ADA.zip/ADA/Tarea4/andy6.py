def andy(casos, datos):
    # recorre los casos
    for i in range(casos):
        # zapatos para el caso actual
        zapatos = datos[i]
        posZapato = dict()
        n = len(zapatos)

        for k in range(n):
            zapatoAct = zapatos[k]
            if zapatoAct not in posZapato:
                posZapato[zapatoAct] = [k, 0]
            else:
                posZapato[zapatoAct][1] = k

        # encuentra las parejas de zapatos, hace los cambios necesarios
        resul = 0
        for j in range(0, n, 2):
            actual = zapatos[j]
            pareja = zapatos[j+1]
            if actual == pareja:
                continue

            posActual = posZapato[actual]
            posPareja = posZapato[pareja]

            zapatos[posActual[1]] = pareja
            zapatos[j+1] = actual

            posActual[1], posPareja[1] = posPareja[1], posActual[1]
            if posActual[0] < posPareja[0]:
                posPareja[0] = posActual[0]
            resul += 1

        # resultado para el caso actual
        print(resul)

def lectu():
    casos = int(input())
    datos = []
    # Lee datos de entrada
    for _ in range(casos):
        n, *rack = map(int, input().split())
        datos.append(rack)
    andy(casos,datos)

lectu()
