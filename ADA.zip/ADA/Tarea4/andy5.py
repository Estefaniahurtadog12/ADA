def andy(casos, datos):
    # recorre los casos
    i = 0
    while i < casos:
        # zapatos para el caso actual
        zapatos = datos[i]
        posZapato = dict()
        n = len(zapatos)

        for k in range(n):
            zapatoAct = zapatos[k]
            if not zapatoAct in posZapato:
                posZapato[zapatoAct] = [k, 0]
            else:
                posZapato[zapatoAct][1] = k
        # encuentra las parejas de zapatos, hace los cambios necesarios
        resul = 0
        j = 0
        while j < n:
            actual = zapatos[j]
            pareja = zapatos[j+1]
            if actual == pareja:
                j += 2
                continue

            zapatos[posZapato[actual][1]] = pareja
            zapatos[j+1] = actual

            temp1 = posZapato[pareja][1]
            temp2 = posZapato[actual][1]
            posZapato[pareja][0] = min(temp1, temp2)
            posZapato[pareja][1] = max(temp1, temp2)

            resul += 1
            j += 2

        # resultado para el caso actual
        print(resul)
        i += 1

def lectu():
    casos = int(input())
    datos = []
    # Lee datos de entrada
    for _ in range(casos):
        n, *posi = map(int, input().split())
        datos.append(posi)
    andy(casos,datos)

lectu()