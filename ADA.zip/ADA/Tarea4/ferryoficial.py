#ferry 2 aceptado por uva
import sys
import math
def ferry(n, m, t, listLlegada, memori={}):
    t *= 2
    total = 0
    seguiTiempo = 0
    for i in range(m):
        listLlegada[i] = int(sys.stdin.readline())

    comple = (n, m, t, tuple(listLlegada))
    if comple in memori:
        return memori[comple]

    i = (m + n - 1) % n
    while i < m:
        seguiTiempo = max(total, listLlegada[i])
        total = seguiTiempo + t
        i += n

    result = (total - t//2, (m + n - 1)//n)
    memori[comple] = result
    return result


def main():
    listLlegada = [0] * 9999 #lista llena de ceros, maxima capacidad.
    c = int(sys.stdin.readline())

    i = 0
    while i < c:
        n, t, m = map(int, sys.stdin.readline().split())
        result = ferry(n, m, t, listLlegada,{})
        print(result[0], result[1])
        i += 1
main()
