def camion(cajas, capaCamion):
    camiones = 0
    capaActualCamion = 0
    cajas.sort(reverse=True)  
    
    i = 0
    while i < len(cajas):
        capaActualCamion += cajas[i]
        if capaActualCamion > capaCamion:
           
            camiones += 1
            capaActualCamion = cajas[i]
        i += 1
    if capaActualCamion > 0:
        camiones += 1
    return camiones

cajas = [10, 5, 2, 7, 3]
capaCamion = 10
minCamion = camion(cajas, capaCamion)
print("Número mínimo de camiones necesarios:", minCamion)
