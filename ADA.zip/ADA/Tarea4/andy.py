def andy():
    #cantidad casos 
    casos = int(input())
    #Se itera a través de cada uno de los casos, en cada caso lee una lista de enteros que representan los zapatos
    for case in range(casos):
        n, *zapatos = map(int, input().split())
        #lista donde se almacena los zapatos ingresados
        zapatosOrden = [0]
        posZapato = {}
        for posZapatoAct in zapatos:
            posZapato[posZapatoAct] = [0, 0]


        j = 1
        while j < (2*n+1):
            posZapatoAct = zapatos[j-1]
            zapatosOrden.append(posZapatoAct)
            if not posZapato[posZapatoAct][0]:
                posZapato[posZapatoAct][0] = j
            else:
                posZapato[posZapatoAct][1] = j
            j += 1

        resul = 0
        j = 1
        while j < 2*n:
            posZapatoAct = zapatosOrden[j]
            pareja = zapatosOrden[j+1]
            if zapatosOrden[j] == zapatosOrden[j+1]:
                j += 2
                continue

            zapatosOrden[posZapato[posZapatoAct][1]] = pareja
            zapatosOrden[j+1] = posZapatoAct
#temp1 se utiliza para almacenar la posición del segundo zapato del par pares en la lista zapatosOrden antes de que se realice el intercambio,
            temp1 = posZapato[pareja][1]
            temp2 = posZapato[posZapatoAct][1]
#temp2 se utiliza para almacenar la posición del segundo zapato del par posZapatoAct en la lista zapatosOrden antes de que se realice el intercambio
            posZapato[pareja][0] = min(temp1, temp2)
            posZapato[pareja][1] = max(temp1, temp2)
            resul += 1
            j += 2

        print(resul)
andy()
