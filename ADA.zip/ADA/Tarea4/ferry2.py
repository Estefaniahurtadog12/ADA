s = [0]*1440 # creo una lista la cual lleno de cero, 1440 es el numero maximo que puede haber 
c = int(input())
for _ in range(c):
    n, t, m = map(int, input().split())
    t *= 2
    tot, act = 0, 0
    for i in range(m):
        s[i] = int(input())
    for i in range((m + n - 1) % n, m, n):
        act = max(tot, s[i])
        tot = act + t
    print(tot - t//2, (m + n - 1)//n)
