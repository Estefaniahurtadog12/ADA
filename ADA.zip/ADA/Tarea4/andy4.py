import sys

def andy(casos, datos):
    for i in range(casos):
        zapatos = datos[i]
        n = len(zapatos) // 2

        # crea un diccionario que mapea cada zapato a su índice en la lista
        posZapato = {}
        
        j = 0
        while j < 2*n:
            posZapato[zapatos[j]] = j
            j += 1

        # encuentra las parejas de zapatos y hace los cambios necesarios
        resul = 0
        j = 0
        while j < 2*n:
            posZapatoAct = j
            pareja = posZapatoAct + 1
            if zapatos[posZapatoAct] == zapatos[pareja]:
                j += 2
                continue
            zapatos[posZapato[zapatos[pareja]]] = zapatos[posZapatoAct]
            zapatos[pareja] = zapatos[pareja]
            posZapato[zapatos[posZapatoAct]], posZapato[zapatos[pareja]] = posZapato[zapatos[pareja]], posZapato[zapatos[posZapatoAct]]
            resul += 1
            j += 2
        print(resul)

def lectu():
    casos = int(sys.stdin.readline().strip())
    datos = []
    for i in range(casos):
        line = sys.stdin.readline().strip()
        n, *zapatos = map(int, line.split())
        datos.append(zapatos)
    andy(casos, datos)

lectu()
