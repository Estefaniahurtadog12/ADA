
#punto 11335 OFICIAL

import sys

def main():
      # memori para almacenar los resultados previamente calculados

    def robocops(posLadron, veloPolicia,memori = {}):
        
        if (posLadron[0] < 0) and (posLadron[1] < 0) and (veloPolicia[0] < 0) and (veloPolicia[1] < 0):
            return float('inf')  # caso base, devuelve infinito para evitar salirse de los límites


        # Si ya se ha calculado, retorna lo que esta en memoria 
        if (tuple(posLadron), tuple(veloPolicia)) in memori:
            return memori[(tuple(posLadron), tuple(veloPolicia))]

        posiPolicia = [0, 0]
        k = 0

        # calcula cantidad de iteraciones necesarias para que el policía alcance al ladrón
        while max(posiPolicia[0], posLadron[0]) != posiPolicia[0] or max(posiPolicia[1], posLadron[1]) != posiPolicia[1]:
            posLadron[0] += veloLadron[0]
            posLadron[1] += veloLadron[1]
            veloPolicia[0] += 1
            veloPolicia[1] += 1
            posiPolicia[0] += veloPolicia[0]
            posiPolicia[1] += veloPolicia[1]
            k += 1
        memori[(tuple(posLadron), tuple(veloPolicia))] = k
        return k

    #lectura de entrada   
    for entrada in sys.stdin:
        a, u, v = map(int, entrada.strip().split())
        veloPolicia = [0, 0]
        veloLadron = [u, v]
        posLadron = [a, 0]
        print(robocops(posLadron, veloPolicia,{}))

main()
