#TIME LIMIT MAS DE 3.00
def andy(casos, datos, posZapato={}):
    # recorre los casos
    i = 0
    while i < casos:
        # zapatos para el caso actual
        zapatos = datos[i]
        # mitad del número de zapatos para el caso actual
        n = len(zapatos) // 2
        zapatosOrden = [0]
        for posZapatoAct in zapatos:
            posZapato[posZapatoAct] = [0, 0]
        # posición de cada zapato en la lista
        j = 1
        while j < (2*n+1):
            posZapatoAct = zapatos[j-1]
            zapatosOrden.append(posZapatoAct)
            if not posZapato[posZapatoAct][0]:
                posZapato[posZapatoAct][0] = j
            else:
                posZapato[posZapatoAct][1] = j
            j += 1
        # encuentra las parejas de zapatos, hace los cambios necesarios
        resul = 0
        j = 1
        while j < 2*n:
            posZapatoAct = zapatosOrden[j]
            pareja = zapatosOrden[j+1]
            if zapatosOrden[j] == zapatosOrden[j+1]:
                j += 2
                continue
            zapatosOrden[posZapato[posZapatoAct][1]] = pareja
            zapatosOrden[j+1] = posZapatoAct
            temp1 = posZapato[pareja][1]
            temp2 = posZapato[posZapatoAct][1]
            posZapato[pareja][0] = min(temp1, temp2)
            posZapato[pareja][1] = max(temp1, temp2)
            resul += 1
            j += 2
        # resultado para el caso actual
        print(resul)
        i += 1

def lectu():
    casos = int(input())
    datos = []
    # Lee datos de entrada
    for i in range(casos):
        n, *zapatos = map(int, input().split())
        datos.append(zapatos)
    andy(casos, datos, {})
lectu()
