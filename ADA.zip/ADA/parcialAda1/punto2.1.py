from sys import stdin

def solve(population, ballots, low, hi):
    while low <= hi:
        mid = low + ((hi-low)>>1)
        used = 0
        for curr_population in population:
            used += (curr_population + mid - 1)//mid

        if used <= ballots: hi = mid - 1
        else: low = mid + 1
    return low

if __name__ == "__main__":
    read = stdin.readline
    line = read().strip()

    while line != "-1 -1":
        num, ballots = map(int, line.split())
        population = [0]*num
        for i in range(num):
            population[i] = int(read().strip())

        ans = solve(population, ballots, 1, max(population))
        print(ans)

        line = read().strip() # ignore blank line
        line = read().strip()