while True:
    n, m = map(int, input().split())
    if n == 0:
        break
    
    A = [0]*100
    for i in range(n):
        a, b = map(int, input().split('.'))
        A[i] = a*100 + b
        
    if A[m-1] > 5000:
        print("100.00")
        continue
    
    dp = [0]*10001
    up = 10000-A[m-1]
    dp[0] = 1
    
    for i in range(n):
        if i == m-1:
            continue
        for j in range(up-A[i], -1, -1):
            if dp[j]:
                dp[j+A[i]] = 1
                
    up = 5001-A[m-1]
    while not dp[up]:
        up += 1
        
    print("{:.2f}".format(float(A[m-1]*100/(up+A[m-1]))))
