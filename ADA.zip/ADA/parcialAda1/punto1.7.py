import sys

def solucion(pos, sumando, sublist, mem = {}):
    inf = float('inf')
    if pos == len(sublist):
        if sumando > 5000:
            return 0
        return inf

    if (pos, sumando) in mem:
        return mem[(pos, sumando)]

    resul = inf
    if pos != posAc - 1:
        resul = solucion(pos + 1, sumando, sublist, mem)

    resul = min(resul, solucion(pos + 1, sumando + sublist[pos], sublist, mem) + sublist[pos])

    mem[(pos, sumando)] = resul

    return resul


for line in sys.stdin:
    mem = {}
    numAccionista, posAc = map(int, line.split())
    if numAccionista == 0 and posAc == 0:
        break
    sublist = [0] * numAccionista
    for i in range(numAccionista):
        entero, deci = map(int, sys.stdin.readline().strip().split('.'))
        sublist[i] = entero * 100 + deci
    respu = 0

    if sublist[posAc - 1] > 5000:
        respu = 100.00
    else:
        resul = solucion(0, 0,sublist,mem)
        respu = (1.0 * sublist[posAc - 1] * 100.0) / resul
    print('{:.2f}'.format(respu))