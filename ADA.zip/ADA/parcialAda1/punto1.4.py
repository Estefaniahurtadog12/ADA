import sys
global memo
def solucion(pos, sumando):
    if pos == len(memo):
        return sumando
    inf = float('inf')
    if pos == numAccionista:
        if sumando > 5000:
            return 0
        return inf
    resultado = memo[pos][sumando]
    if resultado != -1:
        return resultado
    resultado = inf
    if pos != posAc - 1:
        resultado = min(resultado, solucion(pos + 1, sumando))
    resultado = min(resultado, solucion(pos + 1, sumando + sublist[pos]) + sublist[pos])
    memo[pos][sumando] = resultado
    return resultado

numAccionista, posAc = map(int, sys.stdin.readline().strip().split())
memo = [[-1 for _ in range(10000)] for _ in range(1000)]
while numAccionista != 0 or posAc != 0:
    sublist = [0] * numAccionista
    for i in range(numAccionista):
        entero, deci = map(int, sys.stdin.readline().strip().split('.'))
        sublist[i] = entero * 100 + deci
    total = 0
    if sublist[posAc - 1] > 5000:
        total = 100.00
    
    else:
        resultado = solucion(0, 0)
        
        total = (1.0 * sublist[posAc - 1] * 100.0) / resultado
    print('%.2f' % total)
    numAccionista, posAc = map(int, sys.stdin.readline().strip().split())
    memo = [[-1 for _ in range(10000)] for _ in range(10)]
