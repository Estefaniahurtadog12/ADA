import sys

numAccionista = 0
posAc = 0
sublist = [0] * 150
mem = [[-1 for _ in range(10000)] for _ in range(100)]

def solucion(pos, sumando):
    global numAccionista, posAc, sublist, mem
    inf = float('inf')
    if pos == numAccionista:
        if sumando > 5000:
            return 0
        return inf
    resul = mem[pos][sumando] #ya calculado 
    if resul != -1:
        return resul
    resul = inf
    if pos != posAc - 1:
        resul = min(resul, solucion(pos + 1, sumando))
    resul = min(resul, solucion(pos + 1, sumando + sublist [pos]) + sublist [pos])
    mem[pos][sumando] = resul
    return resul

for line in sys.stdin:
    mem = [[-1 for _ in range(10000)] for _ in range(100)]
    numAccionista, posAc = map(int, line.split())
    if numAccionista == 0 and posAc == 0:
        break
    for i in range(numAccionista):
        entero, deci = map(int, input().split('.'))
        sublist[i] = entero * 100 + deci
    respu = 0
    if sublist[posAc - 1] > 5000:
        respu = 100.00
    else:
        resul = solucion(0, 0)
        respu = (1.0 * sublist[posAc - 1] * 100.0) / resul
    print('%.2f' % respu)
