import sys 
from sys import stdin

def solu(poblaElecto, votosReque, minDistri, maxDistri):
    for media in range(minDistri, maxDistri+1):
        urnaElecto = 0
        i = 0
        while i < len(poblaElecto):
            poblaCiu = poblaElecto[i]
            urnaElecto += (poblaCiu + media - 1)//media
            i += 1
        if urnaElecto <= votosReque:
            return media
    return -1

def main():
    linea = stdin.readline
    for entrada in stdin:
        entrada = entrada.strip()

        if entrada == "-1 -1":
            break

        if entrada:
            num, votosReque = map(int, entrada.split())
            poblaElecto = [0]*num

            i = 0
            while i < num:
                poblaElecto[i] = int(linea().strip())
                i += 1
            ans = solu(poblaElecto, votosReque, 1, max(poblaElecto))
            print(ans)

main()
