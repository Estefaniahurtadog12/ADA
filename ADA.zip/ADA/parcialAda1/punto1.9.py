from typing import List, Tuple
from collections import defaultdict

n, m = 0, 0
arr = [0.0] * 101
dp = defaultdict(float)

def solve(ind: int, perc: float) -> float:
    if perc > 50.0:
        return arr[m] / perc
    if ind == n:
        return -1e9
    if (ind, perc) in dp:
        return dp[(ind, perc)]
    res = solve(ind + 1, perc)
    if ind != m:
        res = max(res, solve(ind + 1, perc + arr[ind]))
    dp[(ind, perc)] = res
    return res

if __name__ == "__main__":
    # freopen("a.in", "r", stdin)
    while True:
        n, m = map(int, map(round, map(float, input().split())))


        if n == 0 and m == 0:
            break
        m -= 1
        arr[:n] = list(map(float, input().split()))
        dp.clear()
        print("{:.2f}".format(solve(0, arr[m]) * 100))
