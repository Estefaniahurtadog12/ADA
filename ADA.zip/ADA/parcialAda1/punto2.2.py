from sys import stdin

def solu(population, ballots, mini, maxDistri):
    while mini <= maxDistri:
        media = mini + ((maxDistri-mini)>>1)
        urnaElecto = 0
        for poblaCiu in population:
            urnaElecto += (poblaCiu + media - 1)//media

        if urnaElecto <= ballots:
            maxDistri = media - 1
        else:
            mini = media + 1
    return mini

def main():
    linea = stdin.readline
    for entrada in stdin:
        entrada = entrada.strip()
        if entrada == "-1 -1":
            break
        if entrada:
            num, votosReque = map(int, entrada.split())
            poblaElecto = [0]*num
            i = 0
            while i < num:
                poblaElecto[i] = int(linea().strip())
                i += 1
            respu = solu(poblaElecto, votosReque, 1, max(poblaElecto))
            print(respu)
main()
