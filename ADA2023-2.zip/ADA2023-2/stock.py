from sys import stdin

def lectura():
    testcase = int(stdin.readline())
    testcases = []

    i = 0
    while i < testcase:
        n = int(stdin.readline())
        orders = []
        j = 0
        while j < n:
            orders.append(stdin.readline().strip())
            j += 1
        testcases.append((n, orders))
        i += 1   
    return testcases


def acciones(n, orders):
    compra = []  # lista ordenada
    venta = []  # lista ordenada
    stock = -1
    results = []

    i = 0
    while i < len(orders):
        order = orders[i]
        order_list = order.split()
        cmd, item, price = order_list[0], int(order_list[1]), int(order_list[4])
        item, price = int(item), int(price)

        if cmd == 'buy':
            compra.append((price, item))
            compra.sort(reverse=True)
        elif cmd == 'sell':
            venta.append((price, item))
            venta.sort()

        while compra and venta and compra[0][0] >= venta[0][0]:
            p = compra.pop(0)
            q = venta.pop(0)
            change = min(p[1], q[1])
            stock = q[0]
            p = (p[0], p[1] - change)
            q = (q[0], q[1] - change)
            if p[1] or q[1]:
                if p[1]:
                    compra.append(p)
                    compra.sort(reverse=True)
                elif q[1]:
                    venta.append(q)
                    venta.sort()
        results.append((venta[0][0] if venta else '-', compra[0][0] if compra else '-', stock if stock != -1 else '-'))
        i += 1
    return results



def main():
    testcases = lectura()
    for n, orders in testcases:
        results = acciones(n, orders)
        for result in results:
            print(" ".join(map(str, result)))

main()
