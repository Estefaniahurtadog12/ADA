MAX = 100000
tmp = [ None for _ in range(MAX) ]

def mergesort(A, low, hi):
  if low+2<=hi:
    mid = low+((hi-low)>>1)
    mergesort(A, low, mid)
    mergesort(A, mid, hi)
    merge(A, low, mid, hi)

def merge(A, low, mid, hi):
  global tmp
  for n in range(low, hi): tmp[n] = A[n]
  n,l,r = low,low,mid
  while n!=hi:
    if l==mid: A[n],r = tmp[r],r+1
    elif r==hi: A[n],l = tmp[l],l+1
    else:
      if tmp[l]<=tmp[r]: A[n],l = tmp[l],l+1
      else: A[n],r = tmp[r],r+1
    n += 1


    ---------------
from sys import stdin

MAX = 100000
tmp = [ None for _ in range(MAX) ]
#contador de inversiones,creado como lo sugerido en el problema
inversions = 0  

def mergesort(A, low, hi):
    if low + 1 < hi:
        #mid 
        mid = low + ((hi - low)//2 )  
        #ordena mitad lista
        mergesort(A, low, mid) 
        #ordena segunda mitad lista 
        mergesort(A, mid, hi)
        #combina  
        merge(A, low, mid, hi)  


def merge(A, low, mid, hi):
    #combinar dos listas ordenadas A[low:mid] y A[mid:hi]
    global tmp, inversions
    n = low
    while n < hi:
        #copiar a la lista tmp
        tmp[n] = A[n]
        n += 1
    n, l, r = low, low, mid

    while n < hi:
        if l == mid or (r != hi and tmp[r] < tmp[l]):
            #copiar elemento de la segunda mitad en A
            A[n], r = tmp[r], r + 1 
            #aumentar contador
            inversions += mid - l  
        else:
           #copiar elemento de la primera mitad en A
            A[n], l = tmp[l], l + 1  
        n += 1

n = int(stdin.readline())
while n != 0:
    arr = []
    i = 0
    while i < n:
        arr.append(int(stdin.readline()))
        i += 1
    inversions = 0 
    mergesort(arr, 0, n)
    print(inversions) 
    n = int(stdin.readline())
