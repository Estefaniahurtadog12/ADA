from sys import stdin

def calcularDistanciamin(columnas, numPuentes, espacioPuente, memo, R, norte, sur):
    ans = float("inf")

    if numPuentes == 0:
        ans = 0
    elif columnas < numPuentes:
        ans = float("inf")
    elif (columnas, numPuentes) in memo:
        ans = memo[(columnas, numPuentes)]
    else:
        ans = calcularDistanciamin(columnas - 1, numPuentes, espacioPuente, memo, R, norte, sur)
        nuevoPuente = max(columnas - espacioPuente - 1, 0)

        if nuevoPuente < columnas:
            distancia_actual = sur[columnas - 1] - norte[columnas - 1] - 1
            ans = min(ans, calcularDistanciamin(nuevoPuente, numPuentes - 1, espacioPuente, memo, R, norte, sur) + max(distancia_actual, 1))
        
        memo[(columnas, numPuentes)] = ans
        #print(memo)

    return ans

def entrada():
    linea = stdin.readline().strip()

    while linea:
        R, C = map(int, linea.split())
        B, S = map(int, stdin.readline().split())
        mapa = [stdin.readline().strip() for _ in range(R)]
        norte = [0 for _ in range(C)]
        sur = [0 for _ in range(C)]
        costaMap = [[-1 for _ in range(C)] for _ in range(R)]
        visitados = dict()
        dfs(0, 0, 0, costaMap, R, C, visitados, mapa)
        dfs(R-1, C-1, 1, costaMap, R, C, visitados, mapa)

        for j in range(C):
            i = R-2
            while i >= 1 and not ((i, j) in visitados and costaMap[i][j] == 0):
                i -= 1
            norte[j] = i

        for j in range(C):
            i = 1
            while i <= R and not ((i, j) in visitados and costaMap[i][j] == 1):
                i += 1
            sur[j] = i

        memo = dict()
        visitados = dict()
        resultado = calcularDistanciamin(C-1, B, S, memo, R, norte, sur)
        print(resultado if resultado != float('inf') else 'inf')

        linea = stdin.readline().strip()

def dfs(x, y, tipoCosta, costaMap, r, c, visitados, mapa):
    costaMap[x][y] = tipoCosta
    direcciones = [-1, -1, 1, 1]  # arriba, izquierda, abajo, derecha

    for i in range(len(direcciones)):
        if i % 2 == 0:
            nx = x + direcciones[i]
            ny = y
        else:
            ny = y + direcciones[i]
            nx = x

        if 0 <= nx < r and 0 <= ny < c and mapa[nx][ny] == '#' and (nx, ny) not in visitados:
            visitados[(nx, ny)] = True
            dfs(nx, ny, tipoCosta, costaMap, r, c, visitados, mapa)
        

entrada()
