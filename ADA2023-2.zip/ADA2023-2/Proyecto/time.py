from sys import stdin, setrecursionlimit

def calcularDistanciamin(columnas, numPuentes, espacioPuente, memo, norte, sur, distancias):
    ans = float("inf")

    if numPuentes == 0:
        ans = 0
    elif columnas < 0:
        ans = float("inf")
    elif (columnas, numPuentes) in memo:
        ans = memo[(columnas, numPuentes)]
    else:
        ans = calcularDistanciamin(columnas - 1, numPuentes, espacioPuente, memo, norte, sur, distancias)
        nuevaColumna = columnas - espacioPuente

        distanciaActu = sur[columnas] - norte[columnas] - 1

        if distanciaActu > 0:
            if distancias[nuevaColumna][numPuentes - 1] == float('inf'):
                distancias[nuevaColumna][numPuentes - 1] = calcularDistanciamin(nuevaColumna, numPuentes - 1, espacioPuente, memo, norte, sur, distancias)
            distanciaAqui = distancias[nuevaColumna][numPuentes - 1] + distanciaActu
            ans = min(ans, distanciaAqui)

        memo[(columnas, numPuentes)] = ans

    return ans

def dfs(x, y, tipoCosta, costaMap, r, c, visitados, mapa):
    costaMap[x][y] = tipoCosta
    direcciones = [-1, 0, 1, 0, -1]  # arriba, derecha, abajo, izquierda

    for i in range(len(direcciones)-1):
        nx = x + direcciones[i]
        ny = y + direcciones[i+1]

        if 0 <= nx < r and 0 <= ny < c and mapa[nx][ny] == '#' and (nx, ny) not in visitados:
            visitados[(nx, ny)] = True
            dfs(nx, ny, tipoCosta, costaMap, r, c, visitados, mapa)


def entrada():
    setrecursionlimit(1000000)
    linea = stdin.readline().strip()

    while linea:
        R, C = map(int, linea.split())
        B, S = map(int, stdin.readline().split())
        mapa = [stdin.readline().strip() for _ in range(R)]
        norte = [0 for _ in range(C)]
        sur = [0 for _ in range(C)]
        costaMap = [['.' for _ in range(C)] for _ in range(R)]
        visitados = dict()

        # Llamada para la costa norte
        tipoCosta = 0
        dfs(0, 0, tipoCosta, costaMap, R, C, visitados, mapa)

        # Llamada para la costa sur
        tipoCosta = 1
        dfs(R-1, C-1, tipoCosta, costaMap, R, C, visitados, mapa)

        distancias = [[float('inf')] * (B + 1) for _ in range(C)]  # Matriz para almacenar distancias previamente calculadas

        for j in range(C):
            i = R-2
            while i >= 1 and not ((i, j) in visitados and costaMap[i][j] == 0):
                i -= 1
            norte[j] = i

        for j in range(C):
            i = 1
            while i <= R and not ((i, j) in visitados and costaMap[i][j] == 1):
                i += 1
            sur[j] = i

        memo = dict()
        resultado = calcularDistanciamin(C-1, B, S+1, memo, norte, sur, distancias)
        print(resultado if resultado != float('inf') else 'inf')

        linea = stdin.readline().strip()

entrada()
