import time
from sys import stdin

def calcMinDist(C, B, S, distances):
    tab = [[float("inf") for _ in range(C)] for _ in range(B)]

    for col in range(C):
        tab[B-1][col] = distances[col]

    for row in range(B-2, -1, -1):
        for col in range(C-1, -1, -1):
            if col - S >= 0:
                tab[row][col] = min(tab[row][col], min(tab[row+1][:(col - S) + 1]) + distances[col])

    return min(tab[0])

def fillCoast(x, y, R, C, mapGrid, limCoasts, mark):
    directions = [-1, 0, 1, 0, -1] # arriba, derecha, abajo, izquierda
    queue = [(x, y)]

    while queue:
        x, y = queue.pop()
        mapGrid[x][y] = mark
        limCoasts[y] = max(limCoasts[y], x+1)

        for i in range(len(directions)-1):
            nx = x + directions[i]
            ny = y + directions[i+1]
            if 0 <= nx < R and 0 <= ny < C and mapGrid[nx][ny] == '#':
                queue.append((nx,ny))

if __name__ == "__main__":
    start_time = time.time()

    linea = stdin.readline().strip()
    while linea:
        R, C = map(int, linea.split())
        B, S = map(int, stdin.readline().split())
        mapGrid = [list(stdin.readline().strip()) for _ in range(R)]
        distances = [0 for _ in range(C)]
        limCoasts = [float("-inf") for _ in range(C)]

        # Mapear costa norte con '$'
        fillCoast(0, 0, R, C, mapGrid, limCoasts, '$')

        # Calcular distancias entre costas
        for col in range(C):
            iniCoast = int(limCoasts[col])
            flag = False
            while iniCoast < R and not flag:
                if mapGrid[iniCoast][col] == '#':
                    flag = True
                    distances[col] = iniCoast - int(limCoasts[col])
                iniCoast += 1

        print(calcMinDist(C, B, S+1, distances))

        linea = stdin.readline().strip()

    end_time = time.time()

    print(f"El tiempo de ejecución fue de {end_time - start_time} segundos.")
