from sys import stdin

def tabulation(C, B, S, distances):
    tab = [[float("inf") for _ in range(B)] for _ in range(C)]

    for col in range(C):
        tab[col][B-1] = distances[col]

    for numBridge in range(B-2, -1, -1):
        for col in range(C-1, -1, -1):
            for k in range(col-S, -1, -1):
                tab[col][numBridge] = min(tab[col][numBridge], tab[k][numBridge+1] + distances[col])

    return min([cols[0] for cols in tab])

def fillCoast(x, y, R, C, mapGrid, limCostas, mark):
    directions = [-1, 0, 1, 0, -1] # arriba, derecha, abajo, izquierda
    queue = [(x, y)]
    while queue:
        x, y = queue.pop()
        mapGrid[x][y] = mark
        limCostas[y] = max(limCostas[y], x+1)

        for i in range(len(directions)-1):
            nx = x + directions[i]
            ny = y + directions[i+1]
            if 0 <= nx < R and 0 <= ny < C and mapGrid[nx][ny] == '#':
                queue.append((nx,ny))

if __name__ == "__main__":

    linea = stdin.readline().strip()
    while linea:
        R, C = map(int, linea.split())
        B, S = map(int, stdin.readline().split())
        mapGrid = [list(stdin.readline().strip()) for _ in range(R)]
        distances = [0 for _ in range(C)]
        limCostas = [float("-inf") for _ in range(C)]

        # Mapear costa norte con '$'
        fillCoast(0, 0, R, C, mapGrid, limCostas, '$')

        # Calcular distancias entre costas
        for col in range(C):
            limCosta = int(limCostas[col])
            flag = False
            while limCosta < R and not flag:
                if mapGrid[limCosta][col] == '#':
                    flag = True
                    distances[col] = limCosta - int(limCostas[col])
                limCosta += 1

        print(tabulation(C, B, S+1, distances))

        linea = stdin.readline().strip()

