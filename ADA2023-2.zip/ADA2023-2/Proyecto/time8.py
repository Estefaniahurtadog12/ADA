#Stefania Hurtado Gonzalez 
#Proyecto Ada -> ENTREGA 2
#Codigo: 8961789
#Código de honor
'''
Código de honor:
Como miembro de la comunidad académica de la Pontificia Universidad Javeriana Cali me comprometo a 
seguir los más altos estándares de integridad académica. Integridad académica se refiere a ser honesto, 
dar crédito a quien lo merece y respetar el trabajo de los demás. Por eso es importante evitar plagiar, 
engañar, 'hacer trampa', etc. En particular, el acto de entregar un programa de computador ajeno como 
propio constituye un acto de plagio; cambiar el nombre de las variables, agregar o eliminar comentarios
y reorganizar comandos no cambia el hecho de que se está copiando el programa de alguien más.
#la frase de compromiso del código de honor del curso.'''

from sys import stdin, setrecursionlimit

def calcDistMin(col, numBridges, space, memo, distances):
    ans = float("inf")#respuesta inicializa en inf

    if numBridges == 0:#si ya no hay mas puentes la respuesta es 0
        ans = 0
    elif col < 0:#si no cumple con las dimensiones de la matriz con la que se trabaja
        ans = float("inf")
    elif (col, numBridges) in memo:#si ya ha sido calculado
        ans = memo[(col, numBridges)]
    else:
        distNo = calcDistMin(col - 1, numBridges, space, memo, distances)# cuando se decide no construir el puente y pasar a la siguiente columna aun no visitada
        distChoose = calcDistMin(col - space, numBridges - 1, space, memo, distances) + distances[col]#cuando se decide colocar el puente teniendo en cuenta el espacio minimo y las distancias anteriroes calculadas
        ans = min(distNo, distChoose)# se saca el minimo de estas
        memo[(col, numBridges)] = ans

    return ans

def dfs(x, y, R, C, mapGrid, limCostas, mark):
    mapGrid[x][y] = mark # marcar la posición actual con el símbolo de la costa
    limCostas[y] = max(limCostas[y], x+1)# actualizar el limite de la costa para la columna actual
    directions = [-1, 0, 1, 0, -1] # arriba, derecha, abajo, izquierda

    #(-1,0)(0,1)(1,0),(0,-1)

    #explora las direcciones permitidas
    for i in range(len(directions)-1):
        nx = x + directions[i]
        ny = y + directions[i+1]

        #si las nuevas coordenadas estan dentro de los limites y representan una parte de la costa
        #llamar a la funcion dfs
        if 0 <= nx < R and 0 <= ny < C and mapGrid[nx][ny] == '#':
            dfs(nx, ny, R, C, mapGrid, limCostas, mark)

if __name__ == "__main__":
    setrecursionlimit(1000000)#limite de recursión
    linea = stdin.readline().strip()#leer una linea de la entrada 

    while linea:#si la linea no esta vacia
        R, C = map(int, linea.split())#divide la linea en dos partes
        B, S = map(int, stdin.readline().split())#lectura de la siguiente linea y hace lo mismo
        mapGrid = [list(stdin.readline().strip()) for _ in range(R)]#mapa
        distances = [0 for _ in range(C)]#distancias que hay
        limCostas = [float("-inf") for _ in range(C)]#putno mas alejado de la costa

        # Mapear costa norte con '$'
        dfs(0, 0, R, C, mapGrid, limCostas, '$')

        # Calcular distancias entre costas
        for col in range(C):
            limCosta = int(limCostas[col])#limite inferior de la costa para la columna actual
            flag = False #indicará si se encontró la costa mas alejada

            ##recorre hacia arriba desde el limite inferior de la costa
            while limCosta < R and not flag:
                #toca verificra si la celda actual es parte de la costa sur ('#')
                if mapGrid[limCosta][col] == '#':
                    flag = True # se encontró la costa mas alejada, flag  en True
                    distances[col] = limCosta - int(limCostas[col])
                limCosta += 1#siguiente celda en la misma columna

        memo = dict()
        print(calcDistMin(C-1, B, S+1, memo, distances))#distancia minima

        linea = stdin.readline().strip()

