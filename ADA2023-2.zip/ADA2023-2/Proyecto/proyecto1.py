#Stefania Hurtado Gonzalez 
#Proyecto Ada -> ENTREGA 1 
#Codigo: 8961789
#Código de honor
'''
Código de honor:
Como miembro de la comunidad académica de la Pontificia Universidad Javeriana Cali me comprometo a 
seguir los más altos estándares de integridad académica. Integridad académica se refiere a ser honesto, 
dar crédito a quien lo merece y respetar el trabajo de los demás. Por eso es importante evitar plagiar, 
engañar, 'hacer trampa', etc. En particular, el acto de entregar un programa de computador ajeno como 
propio constituye un acto de plagio; cambiar el nombre de las variables, agregar o eliminar comentarios
y reorganizar comandos no cambia el hecho de que se está copiando el programa de alguien más.
#la frase de compromiso del código de honor del curso.'''


from sys import stdin

def entrada():
    linea =  stdin.readline()  #leer una linea de la entrada 
    while linea:  #si la linea no esta vacia
        R, C = map(int,linea.split())  #divide la linea en dos partes 
        B, S = map(int,stdin.readline().split())  #lectura de la siguiente linea y hace lo mismo
        mapa = [list(stdin.readline().strip()) for _ in range(R)]  #lectura de las siguientes R lineas y las guarda
        norte = [0 for _ in range(C)]  # inicializa una lista norte  de ceros de tamaño C
        sur = [0 for _ in range(C)]  # inicializa una lista sur  de ceros de tamaño C
        costaMap = [[-1 for _ in range (C)] for _ in range(R)]  #matriz de -1 de tamaño RxC
        visitados = dict()  # diccionario vacio para guardar los visitados
        dfs(0,0,0, costaMap, R, C, visitados, mapa)  # llamado función dfs para marcar lo perteneciente a la costa norte
        dfs(R-1,C-1,1, costaMap, R, C, visitados, mapa)  #llamado función dfs para marcar lo perteneciente a la costa norte

        #fila mas al sur de la costa norte en cada columna
        for j in range(C):
                i = R-2
                while i >= 1 and not ((i,j) in visitados and costaMap[i][j] == 0): #0 ->norte 1-> sur
                        i -= 1
                norte[j] = i
        #fila más al norte de la costa sur en cada columna
        for j in range(C):
                i = 1
                while i <= R and not ( (i,j) in visitados and costaMap[i][j] == 1):# 1 -> sur
                        i += 1
                sur[j] = i

        memo = dict()  #diccionario vacio para la memorización
        visitados = dict()  #reinicia el diccionario de visitados
        print(calcularDistanciamin(C-1,B,S,memo,R,norte,sur))  # Llama a la función calcularDistanciamin para calcular la distancia minima y asi imprimirla
        linea = stdin.readline()  #siguiente linea para la proxima iteracion


def calcularDistanciamin(columnas, numPuentes, espacioPuente, memo, R, norte, sur):
    ans = float("inf")  #inicializar respuesta en infinito

    if numPuentes == 0:  #si no hay puentes para construir la respuesta es 0
        ans = 0
    elif columnas < numPuentes:  #si hay menos columnas que puentes para construir la respuesta seria infinito
        ans = float("inf")
    elif (columnas, numPuentes) in memo:  #si ya hemos calculado la respuesta para estas columnas y numero de puentes, esta respuesta esta en la memoria 
        ans = memo[(columnas, numPuentes)]
    else:  #si no se ha calculado, ahora si toca calcular la respuesta
        #toca considerar la opcion de no construir un puente en la columna donde nos encontremos osea en la actual
        ans = calcularDistanciamin(columnas-1, numPuentes, espacioPuente, memo, R, norte, sur)
        #toca despues considerar la opcion de construir un puente en la columna actual
        nuevoPuente = columnas - espacioPuente - 1
        ans = min(ans,
            calcularDistanciamin(nuevoPuente, numPuentes-1, espacioPuente, memo, R, norte, sur) + (sur[columnas] - norte[columnas] - 1))#se hace el llamado rescursivo pero solo quedandnos el el valor mas pequeño
        #se guarda la respuesta en la memoria
        memo[(columnas, numPuentes)] = ans

    return ans #respuesta

def dfs(x, y, tipoCosta, costaMap, r, c, visitados, mapa):
    costaMap[x][y] = tipoCosta  #marca la celda donde se encuentre, quiere decir la actual con el tipo de costa
    direcciones = [-1, -1, 1, 1]  #posibles direcciones de movimiento (arriba, izquierda, abajo, derecha)
    for i in range(len(direcciones)):  #para cada dirección va a iterar
        if i % 2 == 0:  #si mi iterador i es par, se mueve verticalmente (arriba o abajo)
            nx = x + direcciones[i]
            ny = y
        else:  # si mi iterador i es impar, se mueve horizontalmente (izquierda o derecha)
            ny = y + direcciones[i]
            nx = x
        # toca verificar varias cosas:
        #1. si la nueva celda está dentro del mapa
        #2. si es parte de la costa 
        #3. si no ha sido visitada antes
        if nx >= 0 and nx < r and ny < c and ny >= 0 and mapa[nx][ny] == '#' and not (nx, ny) in visitados:
            visitados[(nx, ny)] = True  #cambia la celda  actual como visitada
            dfs(nx, ny, tipoCosta, costaMap, r, c, visitados, mapa)  #Llama a la funcion dfs para la nueva celda

entrada()

