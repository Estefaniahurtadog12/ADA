from sys import stdin,setrecursionlimit

def calcDistMin(col, numBridges, space, memo, distances):
    ans = float("inf")

    if numBridges == 0:
        ans = 0
    elif col < 0:
        ans = float("inf")
    elif (col, numBridges) in memo:
        ans = memo[(col, numBridges)]
    else:
        distNo = calcDistMin(col - 1, numBridges, space, memo, distances)
        distChoose = calcDistMin(col - space, numBridges - 1, space, memo, distances) + distances[col]
        ans = min(distNo, distChoose)
        memo[(col, numBridges)] = ans

    return ans

def fillCoast(x, y, R, C, mapGrid, limCostas, mark):
    directions = [-1, 0, 1, 0, -1] # arriba, derecha, abajo, izquierda
    queue = [(x, y)]
    while queue:
        x, y = queue.pop()
        mapGrid[x][y] = mark
        limCostas[y] = max(limCostas[y], x+1)

        for i in range(len(directions)-1):
            nx = x + directions[i]
            ny = y + directions[i+1]
            if 0 <= nx < R and 0 <= ny < C and mapGrid[nx][ny] == '#':
                queue.append((nx,ny))

if __name__ == "__main__":
    setrecursionlimit(1000000)
    linea = stdin.readline().strip()
    while linea:
        R, C = map(int, linea.split())
        B, S = map(int, stdin.readline().split())
        mapGrid = [list(stdin.readline().strip()) for _ in range(R)]
        distances = [0 for _ in range(C)]
        limCostas = [float("-inf") for _ in range(C)]

        # Mapear costa norte con '$'
        fillCoast(0, 0, R, C, mapGrid, limCostas, '$')

        # Calcular distancias entre costas
        for col in range(C):
            limCosta = int(limCostas[col])
            flag = False
            while limCosta < R and not flag:
                if mapGrid[limCosta][col] == '#':
                    flag = True
                    distances[col] = limCosta - int(limCostas[col])
                limCosta += 1

        memo = dict()
        print(calcDistMin(C-1, B, S+1, memo, distances))

        linea = stdin.readline().strip()