from sys import stdin

def entrada():
    linea =  stdin.readline()
    while linea:
        R, C = map(int,linea.split())
        B, S = map(int,stdin.readline().split())
        mapa = [list(stdin.readline().strip()) for _ in range(R)]
        norte = [0 for _ in range(C)]
        sur = [0 for _ in range(C)]
        costaMap = [[-1 for _ in range (C)] for _ in range(R)]
        visitados = dict()
        dfs(0,0,0, costaMap, R, C, visitados, mapa)
        dfs(R-1,C-1,1, costaMap, R, C, visitados, mapa)

        for j in range(C):
                i = R-2
                while i >= 1 and not ((i,j) in visitados and costaMap[i][j] == 0): #0 ->norte 1-> sur
                        i -= 1
                norte[j] = i
        for j in range(C):
                i = 1
                while i <= R and not ( (i,j) in visitados and costaMap[i][j] == 1):
                        i += 1
                sur[j] = i

        memo = dict()
        visitados = dict()
        print(calcularDistanciamin(C-1,B,S,memo,R,norte,sur))
        linea = stdin.readline()
        

def calcularDistanciamin(columnas, numPuentes, espacioPuente, memo, R, norte, sur):
    ans = float("inf")

    if numPuentes == 0:
        ans = 0
    elif columnas < numPuentes:
        ans = float("inf")
    elif (columnas, numPuentes) in memo:
        ans = memo[(columnas, numPuentes)]
    else:
        ans = calcularDistanciamin(columnas - 1, numPuentes, espacioPuente, memo, R, norte, sur)
        nuevoPuente = max(columnas - espacioPuente - 1, 0)  # Asegurar que nuevoPuente no sea negativo
        ans = min(ans, calcularDistanciamin(nuevoPuente, numPuentes - 1, espacioPuente, memo, R, norte, sur) + (sur[columnas - 1] - norte[columnas - 1] - 1))
        memo[(columnas, numPuentes)] = ans

    return ans


def dfs(x, y, tipoCosta, costaMap, r, c, visitados, mapa):
        costaMap[x][y]= tipoCosta
        direcciones = [-1,-1,1,1] #,arriba,izquierda,abajo,derecha
        for i in range(len(direcciones)):
                if i % 2 == 0:
                        nx = x + direcciones[i]
                        ny = y
                else:
                    ny = y + direcciones[i]
                    nx = x
                    ##coloca los puntos correspondientes a cada costa (adyacentes costa norte y costa sur)
                if nx >= 0 and nx < r and ny < c and ny >= 0 and mapa[nx][ny] == '#' and not (nx,ny) in visitados:
                        visitados[(nx,ny)] = True
                        dfs(nx, ny, tipoCosta, costaMap, r, c, visitados, mapa)



entrada()

