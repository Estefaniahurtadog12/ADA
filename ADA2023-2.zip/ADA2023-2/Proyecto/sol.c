/*
 * TOPIC: DP, lazy dp
 * status: Accepted
 */
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define N 0x400
#define B 0x80
#define confirmacionLimite(x,y) (1<=(x)&&(x)<=m&&1<=(y)&&(y)<=n)
#define oo 0xfffffffful
enum {NORTH,SOUTH};
unsigned int min( unsigned int x, unsigned int y ) { return x<y?x:y; }

int m,n,b,space,bank[N][N],seen[N][N],yes,north[N],south[N],
	dx[] = {-1,0,1,0},
	dy[] = {0,-1,0,1};

char grid[N][N];
unsigned int memo[N][B];

void floodfill( int x, int y, int mark ) {
	int nx,ny,i;
	assert( seen[x][y] != yes );

	for ( bank[x][y] = mark, seen[x][y] = yes, i = 0; i < 4; ++i ){
    nx = x+dx[i];
    ny = y+dy[i];
		if ( confirmacionLimite(nx, ny) && grid[nx][ny] == '#' && seen[nx][ny] != yes )
			floodfill(nx,ny,mark);
  }
}

unsigned int calc_z( int fila, int numPuente ) {
	int j;

	if ( !numPuente ) return 0;
	assert( numPuente >= 1 );

	if ( fila < numPuente ) return +oo;

	assert( fila >= numPuente );

	if ( seen[fila][numPuente] == yes )
		return memo[fila][numPuente];

	seen[fila][numPuente] = yes, memo[fila][numPuente] = calc_z(fila-1,numPuente);
	j = fila-space-1;

	if ( south[fila] <= m && north[fila] >= 1 && calc_z(j,numPuente-1) < +oo )
		memo[fila][numPuente] = min(memo[fila][numPuente], calc_z(j,numPuente-1) + (-north[fila]+south[fila]-1));

	return memo[fila][numPuente];
}

int main() {
	int i,j,k;

	for(;4==scanf("%d %d %d %d",&m,&n,&b,&space);) {
		for ( i = 1; i <= m; scanf("%s",1+grid[i++]) );

		for ( ++yes, k = 0, i = 1; i <= m && !k; ++i )
			for ( j = 1; j <= n && !k; ++j )
				if ( grid[i][j] == '#' )
					floodfill(i,j,NORTH), ++k;

		for ( k = 0, i = m; i >= 1 && !k; --i )
			for ( j = n; j >= 1 && !k; --j )
				if ( grid[i][j] == '#' && seen[i][j] != yes )
					++k, floodfill(i,j,SOUTH);

		for ( i = 1; i <= m; ++i )
			for ( j = 1; j <= n; ++j )
				if ( grid[i][j] == '#' )
					assert( seen[i][j] == yes );

		for ( j = 1; j <= n; north[j++] = i )
			for ( i = m; i >= 1 && !(seen[i][j] == yes && bank[i][j] == NORTH); --i );

		for ( j = 1; j <= n; south[j++] = i )
			for ( i = 1; i <= m && !(seen[i][j] == yes && bank[i][j] == SOUTH); ++i );

		for ( j = 0; j <= n; ++j )
			for ( k = 0; k <= b; ++k )
				memo[j][k] = +oo, seen[j][k] = 0;

		printf("%u\n",calc_z(n,b));
	}
	return 0;
}

