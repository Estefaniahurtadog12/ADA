'''Juan Jose Marin 
Codigo de estudiante : 8947785'''
'''
Código de honor:
Como miembro de la comunidad académica de la Pontificia Universidad Javeriana Cali me comprometo a 
seguir los más altos estándares de integridad académica. Integridad académica se refiere a ser honesto, 
dar crédito a quien lo merece y respetar el trabajo de los demás. Por eso es importante evitar plagiar, 
engañar, 'hacer trampa', etc. En particular, el acto de entregar un programa de computador ajeno como 
propio constituye un acto de plagio; cambiar el nombre de las variables, agregar o eliminar comentarios
y reorganizar comandos no cambia el heanso de que se está copiando el programa de alguien más.
#la frase de compromiso del código de honor del curso.
'''
from sys import stdin

def phi(dp, inicio, n, s, puentes, C):
    ans = 0
    if inicio > C:
        if n != 0: ans = float('inf')
    else:
        ans = phi(dp, inicio + 1, n, s, puentes, C)
        if puentes[inicio] > 0: ans = min(ans, puentes[inicio] + phi(dp, inicio + s, n-1, s, puentes, C))
    dp[inicio][n] = ans
    return ans

def dfs(mapa, fila, columna, ans, R, C):

    if fila < 0 or columna < 0 or fila >= R or columna >= C:
        return mapa
    if mapa[fila][columna] != '#':
        return mapa
    mapa[fila][columna] = ans
    dfs(mapa, fila, columna + 1, ans, R, C) #derecha
    dfs(mapa, fila + 1, columna, ans, R, C)#abajo
    return mapa
def main():
    Y = stdin.readline()    
    while Y != '':
        numeros = list(map(int, Y.split()))
        R, C = numeros[0], numeros[1]  # rows, columna
        # B = Numero de puentes a construir 
        # S = Numero de espacios que separa cada puente
        B, S = map(int, stdin.readline().split())
        dp, puentes = [[-1] * (C+1) for _ in range(R*C)], [0] * (C+1)
        mapa = [list(input().strip()) for _ in range(R)]
        mapa =dfs(mapa, 0, 0, 'NO', R, C)
        for j in range(C):
            puenteinicial = 0

            for i in range(R):
               if mapa[i][j] == 'NO':
                    puenteinicial = i

            flag = False
            for i in range(puenteinicial+1, R):
                if flag == False:
                    if mapa[i][j] == '#': flag = True
                    else: puentes[j] += 1
                    
        print(phi(dp, 0, B, S+1, puentes, C))
        Y = stdin.readline() 

main()
