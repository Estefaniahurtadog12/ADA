# Importar los módulos necesarios
import sys
from bisect import bisect_left

# Función para calcular el costo mínimo de construir un puente
def minCost(north, south, L, C):
    # Ordenar los puntos de las islas de norte a sur
    north.sort()
    south.sort()

    # Crear una matriz de programación dinámica para almacenar los costos parciales
    n = len(north)
    m = len(south)
    dp = [[1e9] * (m + 1) for _ in range(n + 1)]

    # Caso base: si no hay puntos en una isla, el costo es cero
    dp[0][0] = 0
    for i in range(1, n + 1):
        dp[i][0] = 0
    for j in range(1, m + 1):
        dp[0][j] = 0

    # Caso recursivo: para cada par de puntos, elegir el mínimo entre construir un pilar o un segmento
    for i in range(1, n + 1):
        for j in range(1, m + 1):
            # Construir un pilar en el punto del norte y usar el segmento anterior del sur
            dp[i][j] = min(dp[i][j], dp[i - 1][j] + C)

            # Construir un pilar en el punto del sur y usar el segmento anterior del norte
            dp[i][j] = min(dp[i][j], dp[i][j - 1] + C)

            # Construir un segmento entre los puntos del norte y del sur
            dist = abs(north[i - 1] - south[j - 1]) # Distancia entre los puntos
            len = max(0, dist - L) # Longitud del segmento que excede L
            dp[i][j] = min(dp[i][j], dp[i - 1][j - 1] + len)

    # Retornar el costo mínimo de construir un puente entre las dos islas
    return dp[n][m]

# Función principal para leer la entrada y mostrar la salida
def main():
    # Leer la entrada desde la entrada estándar
    for line in sys.stdin:
        N, M, L, C = map(int, line.split()) # Número de puntos en la isla norte, sur, longitud máxima de un segmento y costo de un pilar
        if N == 0 and M == 0 and L == 0 and C == 0: break # Fin de la entrada

        north = list(map(int, sys.stdin.readline().split())) # Lista para almacenar los puntos de la isla norte
        south = list(map(int, sys.stdin.readline().split())) # Lista para almacenar los puntos de la isla sur

        ans = minCost(north, south, L, C) # Calcular el costo mínimo de construir un puente
        print(ans) # Mostrar el resultado

if __name__ == "__main__":
    main()
