from sys import stdin, setrecursionlimit

def calcDistMin(col, numBridges, space, memo, distances):
    if numBridges == 0:
        return 0
    if col < 0:
        return float("inf")
    if (col, numBridges) in memo:
        return memo[(col, numBridges)]

    ans = calcDistMin(col - 1, numBridges, space, memo, distances)

    if distances[col] > 0:
        distanciaAqui = calcDistMin(col - space, numBridges - 1, space, memo, distances) + distances[col]
        ans = min(ans, distanciaAqui)

    memo[(col, numBridges)] = ans
    return ans

def dfs(x, y, R, C, visited, mapGrid, flag, limCostas):
    mapGrid[x][y] = flag
    limCostas[y] = max(limCostas[y], x+1)
    directions = [-1, 0, 1, 0, -1]  # arriba, derecha, abajo, izquierda

    for i in range(len(directions)-1):
        nx = x + directions[i]
        ny = y + directions[i+1]

        if 0 <= nx < R and 0 <= ny < C and mapGrid[nx][ny] == '#' and (nx, ny) not in visited:
            visited.add((nx, ny))
            dfs(nx, ny, R, C, visited, mapGrid, flag, limCostas)

def readInput():
    setrecursionlimit(1000000)
    linea = stdin.readline().strip()

    while linea:
        R, C = map(int, linea.split())
        B, S = map(int, stdin.readline().split())
        mapGrid = [list(stdin.readline().strip()) for _ in range(R)]
        distances = [0]*C
        limCostas = [float("-inf")]*C

        # Mapear costa norte con 'V'
        dfs(0, 0, R, C, set(), mapGrid, "V", limCostas)

        # Calcular distancias entre costas
        for col in range(C):
            limCosta = int(limCostas[col])

            flag = False
            while limCosta < R and not flag:
                if mapGrid[limCosta][col] == '#': flag = True
                else: distances[col] += 1
                limCosta += 1
        
        # Calcular distancias entre costas
        for col in range(C):
            limCosta = int(limCostas[col])  # Realiza la conversión aquí

            flag = False
            while limCosta < R and not flag:
                if mapGrid[limCosta][col] == '#': flag = True
                else: distances[col] += 1
                limCosta += 1  # Usa la variable ya convertida



        memo = dict()
        resultado = calcDistMin(C-1, B, S+1, memo, distances)
        print(resultado if resultado != float('inf') else 'inf')

        linea = stdin.readline().strip()

readInput()
