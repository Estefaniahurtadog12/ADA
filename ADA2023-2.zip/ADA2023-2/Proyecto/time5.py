from sys import stdin, setrecursionlimit

def calcDistMin(columnas, numPuentes, espacioPuente, memo, distances):
    ans = float("inf")

    if numPuentes == 0:
        ans = 0
    elif columnas < 0:
        ans = float("inf")
    elif (columnas, numPuentes) in memo:
        ans = memo[(columnas, numPuentes)]
    else:
        ans = calcDistMin(columnas - 1, numPuentes, espacioPuente, memo, distances)
        nuevaColumna = columnas - espacioPuente

        if distances[columnas] > 0:
            distanciaAqui = calcDistMin(nuevaColumna, numPuentes - 1, espacioPuente, memo, distances) + distances[columnas]
            ans = min(ans, distanciaAqui)

        memo[(columnas, numPuentes)] = ans

    return ans

def dfs(x, y, R, C, visited, mapGrid, flag):
    mapGrid[x][y] = flag
    direcciones = [-1, 0, 1, 0, -1]  # arriba, derecha, abajo, izquierda

    for i in range(len(direcciones)-1):
        nx = x + direcciones[i]
        ny = y + direcciones[i+1]

        if 0 <= nx < R and 0 <= ny < C and mapGrid[nx][ny] == '#' and (nx, ny) not in visited:
            visited[(nx, ny)] = True
            dfs(nx, ny, R, C, visited, mapGrid, flag)

def readInput():
    setrecursionlimit(1000000)
    linea = stdin.readline().strip()

    while linea:
        R, C = map(int, linea.split())
        B, S = map(int, stdin.readline().split())
        mapGrid = [list(stdin.readline().strip()) for _ in range(R)]
        distances = [0 for _ in range(C)]

        # Mapear costa norte con 'V'
        dfs(0, 0, R, C, {}, mapGrid, "V")

        for col in range(C):
            limCosta = 0
            for row in range(R):
                if mapGrid[row][col] == 'V':
                    limCosta = row + 1

            flag = False
            while limCosta < R and not flag:
                if mapGrid[limCosta][col] == '#': flag = True
                else: distances[col] += 1
                limCosta += 1

        memo = dict()
        resultado = calcDistMin(C-1, B, S+1, memo, distances)
        print(resultado if resultado != float('inf') else 'inf')

        linea = stdin.readline().strip()

readInput()
