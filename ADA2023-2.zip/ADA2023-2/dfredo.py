from sys import stdin

EPSILON = 1e-6


def time(r, speed, t):
    # velocidad = distancia/tiempo =>  distancia/1/(distancia/tiempo) => se aplica ley de la oreja y eso da tiempo
    # t-r = distancia de ciclismo
    running_time = r / speed[0]
    cycling_time = (t - r) / speed[1]
    total_time = running_time + cycling_time
    return total_time


    # Se compara respecto a las velocidad del tramposo los tiempos de el
    # y del competidor mas rapido de los otros concursantes
    cheater_time = time(r, speeds[-1], t)
    other_times = [time(r, speed, t) for speed in speeds[:-1]]
    # si es positivo, significa que el tramposo tiene un mejor tiempo
    # que el mejor tiempo de todos los concursantes
    return min(other_times) - cheater_time

def objective(t, r, speeds):
    # Se compara respecto a las velocidad del tramposo los tiempos de el
    # y del competidor mas rapido de los otros concursantes
    cheater_time = time(r, speeds[-1], t)
    best_other_time = time(r, speeds[0], t)
    for speed in speeds[1:-1]:
        other_time = time(r, speed, t)
        if other_time < best_other_time:
            best_other_time = other_time
    # si es positivo, significa que el tramposo tiene un mejor tiempo
    # que el mejor tiempo de todos los concursantes
    return best_other_time - cheater_time




def solve(t, speeds, left=0, right=None):
    if right is None:
        right = t
    best_r, best_advantage = 0, -1

    # se recorre respecto a 'r', que seria la distancia que tendria que tener
    # el recorrido corriendo
    while right - left > EPSILON:
        mid = (left + right) / 2
        advantage = objective(t, mid, speeds)
        # lo guardamos si es mas ventajoso para el que esta haciendo trampa
        # si es mas ventajoso que el que hemos guardado, pues se reemplazan
        best_r = mid
        best_advantage = advantage

        # si nos sale mas ventajoso correr mas (al mid se le agrega un poquito para ver si da mejores tiempos)
        # de ser asi significa que las otras soluciones con menor recorrido corriendo no nos importa
        # por eso el puntero 'left' se actualiza, de no ser asi significa que sale mas ventajoso un recorrido
        # con menos correr y mas ciclismo, por lo que se acutaliza el puntero 'right' ya que caminos al mas largos
        # al correr no nos beneficia
        if objective(t, mid + EPSILON, speeds) > objective(t, mid, speeds):
            left = mid
        else:
            right = mid

    
    # Si hay una distancia que de ventaja al tamposo entonces la mostramos, de lo contrario el man
    # es un pendejo que no puede ganar una carrera arreglada equide
    best_advantage = max(best_advantage, objective(t, t, speeds), objective(t, 0, speeds))
    if best_advantage >= 0:
        k = t - best_r
        return f"The cheater can win by {best_advantage*3600:.0f} seconds with r = {best_r:.2f}km and k = {k:.2f}km."
    else:
        return "The cheater cannot win."


def lectura ():
    line = stdin.readline()
    while line:
        t,n,speeds = int(line),int(stdin.readline()),list()
        while len(speeds) < n:
            x = stdin.readline().split()
            speeds.append((float(x[0]), float(x[1])))
        print(solve(t,speeds))
        line = stdin.readline()
        line=stdin.readline()

lectura()
