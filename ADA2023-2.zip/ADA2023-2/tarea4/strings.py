# Importar la biblioteca de números grandes
import math

# Definir una función para encontrar la permutación
def find_permutation(s, n, fac=None, ans=None):
    # Inicializar el factor y la lista de respuesta
    if fac is None:
        fac = math.factorial(len(s))
        ans = [s[0]]
    else:
        # Calcular la posición y el índice actualizados
        i = len(ans)
        pos = (n * (i + 1) + fac - 1) // fac
        ans.insert(pos - 1, s[i])
        fac //= (i + 1)
        n -= fac * (pos - 1)

    # Si aún quedan caracteres por procesar, hacer una llamada recursiva
    if len(ans) < len(s):
        return find_permutation(s, n, fac, ans)
    else:
        # Devolver la respuesta como una cadena
        return "".join(ans)

# Leer el número de casos de prueba
tc = int(input())
# Iterar sobre los casos de prueba
for _ in range(tc):
    # Leer la cadena y el número
    s = input()
    n = int(input())
    # Encontrar y mostrar la permutación
    print(find_permutation(s, n))
