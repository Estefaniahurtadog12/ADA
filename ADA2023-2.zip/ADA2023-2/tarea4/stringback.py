#ofi permutacion
#stefania hurtado
from sys import stdin
import math

#I-esima permutacio cadena
#todas posibles permutaciones se prueban 
def permu(cadOrginial, numPermu, f=1, respu=[]):
    #posicion donde toca insertar el prox caracter en la cadena
    i = len(respu)
    posTrueCaracter = ( numPermu* (i + 1) + f - 1) // f

    #inicializa f y respu
    if f == 1 and not respu:
        f = math.factorial(len(cadOrginial))
        respu = [cadOrginial[0]]
    else:
        respu.insert(posTrueCaracter - 1, cadOrginial[i])  #pone el caracter en la posi calculada
        f //= (i + 1)  #actualiza el valor de f
        numPermu -= f * (posTrueCaracter - 1)  #actualiza n en funcion de la posi

    #si faltan caracteres por meter hace llamado recursivo
    if len(respu) < len(cadOrginial):
        respu = permu(cadOrginial, numPermu, f, respu)

    #cadena ofi
    return "".join(respu)

    #se considera como fallo alcanza numero de intentos y su respuesta en None 

def otraVez(func, porSi1=None, porSi2=None):
    intentos = 1 #intentos permitidos
    for _ in range(intentos):
        result = func(porSi1, porSi2)
        if result is not None:
            return result
    return None

def main():
    tc = int(stdin.readline())#casos de prueba

    for _ in range(tc):#cada caso de prueba
        #cadena y el num permutacion
        cadOrginial = stdin.readline().strip()
        numPermu = int(stdin.readline())
        #se encontro mijito
        print(otraVez(permu, cadOrginial, numPermu))
main()
