def compare(str1, str2):
    if str1[0] < str2[0] or (str1[0]==str2[0] and str1+str2 < str2+str1):
        return True

'''def main():
    n = int(input())
    while n != 0:
        num = [x for x in input().split()]
        for i in range(0,len(num)-1):
            for j in range(i+1,len(num)):
                if compare(num[i],num[j]):
                    num[i], num[j] = num[j], num[i]
        print(*num, sep ='')
        n= int(input())
main()'''

def main():
    n = int(input())
    while n != 0:
        num = [x for x in input().split()]
        for i in range(0,len(num)-1):
            for j in range(i+1,len(num)):
                if compare(num[i],num[j]):
                    num[i], num[j] = num[j], num[i]
        for element in num:
            print(element, end='')
        print()  # para agregar una nueva línea al final
        n= int(input())
main()
