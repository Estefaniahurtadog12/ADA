from sys import stdin

bandera = True

#comparar numeros como cadenas
def compare(str1, str2):
    if str1 + str2 < str2 + str1:
        return bandera

def main():
    #numero de conjuntos
    n = int(stdin.readline())
    #procesar cada conjunto 
    while n != 0:
        num = [x for x in stdin.readline().split()] #convierte las cadenas a números si es necesario
        for i in range(0,len(num)-1):
            # Ordena los num en el conjunto de manera que se logre maximizar el num de la repsuesta
            for j in range(i+1,len(num)):
                if compare(num[i],num[j]):
                    num[i], num[j] = num[j], num[i]
        i = 0
        while i < len(num):
            print(num[i], end='')
            i += 1
        print()  # para agregar una nueva línea al final
        n= int(stdin.readline())
main()
