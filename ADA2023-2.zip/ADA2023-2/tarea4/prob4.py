def contrArbol(inicio, fin, f, padreColor, profundidad):
    if inicio > fin:
        return None, 0

    costMin = float('inf')
    optimo = None
    for raiz in range(inicio, fin + 1):
        subIzqui, costIzquierdo = contrArbol(inicio, raiz - 1, f, "rojo", profundidad)
        subDere, costIDere = contrArbol(raiz + 1, fin, f, "rojo", profundidad)
        
        raiz = {"clave": raiz, "color": padreColor, "izquierdo": subIzqui, "derecho": subDere}
        
        cosActu = costIzquierdo + costIDere + (0 if raiz["clave"] is None else f[raiz["clave"]]) + profNegro(raiz, padreColor, profundidad)
        
        if cosActu < costMin:
            costMin = cosActu
            optimo = raiz
    return optimo, costMin

def costoCal(arbol, f):
    if arbol is None:
        return 0
    costIzquierdo = costoCal(arbol["izquierdo"], f)
    costIDere = costoCal(arbol["derecho"], f)
    return costIzquierdo + costIDere + (0 if arbol["clave"] is None else f[arbol["clave"]])

def profNegro(arbol, padreColor, profundidad):
    if padreColor == "negro" and arbol["color"] == "rojo":
        profundidad += 1
    return profundidad

def arOrden(arbol):
    if arbol is not None:
        arOrden(arbol["izquierdo"])
        if arbol["clave"] is not None:
            print(arbol["clave"], arbol["color"])
        arOrden(arbol["derecho"])

n = 5  
f = [10, 20, 30, 5, 8]  
raiz, costMin = contrArbol(0, n - 1, f, "negro", 0)

arOrden(raiz)

print("Costo mino:", costMin)
