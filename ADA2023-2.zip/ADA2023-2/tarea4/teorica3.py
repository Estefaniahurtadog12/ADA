def crearNodo(clave, frecuencia):
    return {'clave': clave, 'frecuencia': frecuencia, 'altura': 1, 'izquierda': None, 'derecha': None}

def obtenerAltura(nodo):
    if nodo is None:
        return 0
    return nodo['altura']

def obtenerEquilibrio(nodo):
    if nodo is None:
        return 0
    return obtenerAltura(nodo['izquierda']) - obtenerAltura(nodo['derecha'])

def rotarDerecha(y):
    x = y['izquierda']
    T2 = x['derecha']
    #rotación
    x['derecha'] = y
    y['izquierda'] = T2
    #alturas
    y['altura'] = 1 + max(obtenerAltura(y['izquierda']), obtenerAltura(y['derecha']))
    x['altura'] = 1 + max(obtenerAltura(x['izquierda']), obtenerAltura(x['derecha']))
    #nueva raíz
    return x

def rotarIzquierda(x):
    y = x['derecha']
    T2 = y['izquierda']
    #rotación
    y['izquierda'] = x
    x['derecha'] = T2
    #alturas
    x['altura'] = 1 + max(obtenerAltura(x['izquierda']), obtenerAltura(x['derecha']))
    y['altura'] = 1 + max(obtenerAltura(y['izquierda']), obtenerAltura(y['derecha']))
    # Devolver nueva raíz
    return y

def construirAVL(claves, frecu, inicio, fin):
    if inicio > fin:
        return None

    medio = inicio + (fin - inicio) // 2
    nodo = crearNodo(claves[medio], frecu[medio])

    nodo['izquierda'] = construirAVL(claves, frecu, inicio, medio - 1)
    nodo['derecha'] = construirAVL(claves, frecu, medio + 1, fin)

    nodo['altura'] = 1 + max(obtenerAltura(nodo['izquierda']), obtenerAltura(nodo['derecha']))

    equilibrio = obtenerEquilibrio(nodo)

    if equilibrio > 1:
        if obtenerEquilibrio(nodo['izquierda']) >= 0:
            return rotarDerecha(nodo)
        elif obtenerEquilibrio(nodo['izquierda']) < 0:
            nodo['izquierda'] = rotarIzquierda(nodo['izquierda'])
            return rotarDerecha(nodo)
    elif equilibrio < -1:
        if obtenerEquilibrio(nodo['derecha']) <= 0:
            return rotarIzquierda(nodo)
        elif obtenerEquilibrio(nodo['derecha']) > 0:
            nodo['derecha'] = rotarDerecha(nodo['derecha'])
            return rotarIzquierda(nodo)

    return nodo
#claves y las frecuencias
claves = [1, 2, 3, 4, 5, 6, 7]
frecu = [5, 4, 7, 2, 1, 3, 6]
#Construir el AVL
raiz = construirAVL(claves, frecu, 0, len(claves) - 1)

#árbol en orden (izquierda, raíz, derecha)
def imprimirEnOrden(nodo):
    if nodo is not None:
        imprimirEnOrden(nodo['izquierda'])
        print(f"Clave: {nodo['clave']}, Frecuencia: {nodo['frecuencia']}")
        imprimirEnOrden(nodo['derecha'])


imprimirEnOrden(raiz)
