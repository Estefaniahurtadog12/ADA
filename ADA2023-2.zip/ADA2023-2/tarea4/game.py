#childrens game oficial 
#aceptado en judge

from sys import stdin

#comparar dos cadenas y ver cual va primero cuando se concatenan
def compare(str1, str2):
    ans = False
    #primer caracter de str1 es menor que el de str2
    if str1[0] < str2[0]:
        ans = True
        return ans
    #primeros caracteres son iguales, pero str1+str2 es menor que str2+str1
    if str1[0] == str2[0]:
        if str1 + str2 < str2 + str1:
            ans = True
            return ans
    # si no se cumple ninguna ans = False


def main():
    n = int(stdin.readline())
    while n != 0:
        line = stdin.readline()  #lee entrada
        elementos = line.split()  #linea separada por espacios
        num = [] 
        for x in elementos:
            num.append(x)  #agrega cada elemento a la lista num

        #iteramos a través de los elementos de la lista num
        for i in range(0, len(num) - 1):
            #iteramos a través de los elementos que están despues del elemento en la posicion i
            for j in range(i + 1, len(num)):
                if compare(num[i], num[j]):
                #comparamos num[i] y num[j] para determinar si deben intercambiarse en la lista ordenada
                #si compare devuelve True, significa que num[i] debe estar antes de num[j] y 
                #por lo tanto, intercambiamos los elementos num[i] y num[j] para poder organizar nuevamente la lista
                    num[i], num[j] = num[j], num[i]
                    #num ya esta reordenada de manera que al concatenar todos los elementos se forme el numero ms grande posible
        #lista ordenada como un solo num
        for elemento in num:
            print(elemento, end='')
        print()
        n = int(stdin.readline())

main()
