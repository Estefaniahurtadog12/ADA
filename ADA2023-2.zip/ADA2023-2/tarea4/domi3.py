#Stefania Hurtado 
#oficial domino
from sys import stdin
def main():
    #num de espacios a llenar
    espacios = int(stdin.readline())
    #si espacios es 0 seguimos leyendo los casos de prueba
    while espacios != 0:
        #contiene fichas disponibles para llenar los espacios
        dispoEspacio = int(stdin.readline())
        #fichas llenar
        llenar = []
        primera, fichaUlti = [list(map(int, input().split())) for _ in range(2)]
        #las fichas disponibles para llenar los espacios
        i = 0
        while i < dispoEspacio:
            cadena = stdin.readline()
            numeros = [int(x) for x in cadena.split()]
            # llenar la lista con los números
            llenar.append(numeros)
            i += 1

        ans = domino(espacios, fichaUlti, llenar, primera, 1,[])
        print(ans)
        espacios = int(stdin.readline())

def domino(espacios, fichaUlti, llenar, ficha, i, visitados):
    # Recorremos fichas llenar
    idxLlenar = 0
    while idxLlenar < len(llenar):
        #ficha actual
        fichaActu = llenar[idxLlenar]
        #ficha no sea None (esto puede pasa si eliminamos una ficha de la lista)
        if fichaActu is not None:
            #ficha actual sea si sirve para colocarla en el espacio actual
            #comparar el numero de puntos de la ficha actual con el de la ultima ficha puesta
            #verificar que la ficha actual no haya sido usada, no puede estar ne visitados
            valido = (fichaActu[0] == ficha[1] or fichaActu[1] == ficha[1]) and idxLlenar not in visitados
            #ficha la colocamos en el espacio actu
            if valido:
                #guardamos la ficha actual
                fichaActu2 = fichaActu
                #invertimos el orden de la ficha actual
                if fichaActu[0] != ficha[1]:
                    fichaActu2 = (fichaActu[1], fichaActu[0])
                #ficha actual a la lista de visitados
                visitados.append(idxLlenar)
                #llamado recursivo
                ans = domino(espacios, fichaUlti, llenar, fichaActu2, i+1, visitados)
                #encontramos una solución al problema y retornamos 'YES'
                if ans == 'YES':
                    return ans
                #no encontramos una solución al problema con esta ficha y debemos probar otra opcion
                #toca eliminamosrel idx de la ficha actual de visitados y continuamos con el ciclo 
                visitados.remove(idxLlenar)
        idxLlenar += 1
    #probamos todas las opciones llenar y ninguna nos dio una solución al problema
    #se ha encontraod una solución etornamos 'YES'
    if i == espacios+1:
        if ficha[1] == fichaUlti[0]:
            return 'YES'

    #no hemos encontrado una solución al problema y retornamos 'NO'
    return 'NO'


main()

