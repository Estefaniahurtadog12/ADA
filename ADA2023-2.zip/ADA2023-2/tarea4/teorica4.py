class Nodo:
    def __init__(self, clave, frecuencia, color='rojo'):
        self.clave = clave
        self.frecuencia = frecuencia
        self.color = color
        self.izquierdo = None
        self.derecho = None

def generar_arboles(nodos):
    if not nodos:
        return [None]
    arboles = []
    for i, nodo in enumerate(nodos):
        for izquierdo in generar_arboles(nodos[:i]):
            for derecho in generar_arboles(nodos[i+1:]):
                arbol = Nodo(nodo.clave, nodo.frecuencia)
                arbol.izquierdo = izquierdo
                arbol.derecho = derecho
                arboles.append(arbol)
    return arboles

def verificar_propiedades(nodo):
    if nodo is None:
        return True, 0

    izq_valido, izq_negros = verificar_propiedades(nodo.izquierdo)
    der_valido, der_negros = verificar_propiedades(nodo.derecho)

    if not izq_valido or not der_valido:
        return False, 0

    if izq_negros != der_negros:
        return False, 0

    if nodo.color == 'rojo':
        if (nodo.izquierdo and nodo.izquierdo.color == 'rojo') or \
           (nodo.derecho and nodo.derecho.color == 'rojo'):
            return False, 0

    negros = izq_negros
    if nodo.color == 'negro':
        negros += 1

    return True, negros

def calcular_costo(nodo):
    if nodo is None:
        return 0

    costo_izq = calcular_costo(nodo.izquierdo)
    costo_der = calcular_costo(nodo.derecho)

    return costo_izq + costo_der + nodo.frecuencia
    
f = [10, 20, 30] 
nodos = [Nodo(i, f[i-1], color='negro' if i==1 else 'rojo') for i in range(1, 4)]

arboles = generar_arboles(nodos)

arboles = [arbol for arbol in arboles if verificar_propiedades(arbol)[0]]

min_costo = float('inf')
mejor_arbol = None
for arbol in arboles:
    costo = calcular_costo(arbol)
    if costo < min_costo:
        min_costo = costo
        mejor_arbol = arbol

print(mejor_arbol)
