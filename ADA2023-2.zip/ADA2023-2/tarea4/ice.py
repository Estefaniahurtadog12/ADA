def dfs2(x, y, visited, visited2, n, m):
    if x < 0 or y < 0 or x >= n or y >= m:
        return 0
    if visited[x][y] or visited2[x][y]:
        return 0
    visited2[x][y] = True
    sum_val = 1
    dirs = [(1, 0), (0, 1), (-1, 0), (0, -1)]
    for dir in dirs:
        nextX = dir[0] + x
        nextY = dir[1] + y
        sum_val += dfs2(nextX, nextY, visited, visited2, n, m)
    return sum_val

def dfs(x, y, steps, checkpoints, t, visited, visited2, n, m, total):
    if x < 0 or y < 0 or x >= n or y >= m:
        return 0
    if visited[x][y]:
        return 0
    if steps == checkpoints[3]:
        return 1
    elif steps == checkpoints[2]:
        if (x, y) != t[2]:
            return 0
    elif steps == checkpoints[1]:
        if (x, y) != t[1]:
            return 0
    elif steps == checkpoints[0]:
        if (x, y) != t[0]:
            return 0
    else:
        for i in range(4):
            if (x, y) == t[i]:
                return 0
            dist = abs(x - t[i][0]) + abs(y - t[i][1])
            turnLeft = checkpoints[i] - steps
            if 0 < turnLeft < dist:
                return 0
    visited2 = [[False for _ in range(m)] for _ in range(n)]
    visited2[x][y] = True
    cnt = dfs2(0, 1, visited, visited2, n, m)
    if cnt != total - steps:
        return 0
    visited[x][y] = True
    path = 0
    dirs = [(1, 0), (0, 1), (-1, 0), (0, -1)]
    for dir in dirs:
        nextX = dir[0] + x
        nextY = dir[1] + y
        path += dfs(nextX, nextY, steps + 1, checkpoints, t, visited, visited2, n, m, total)
    visited[x][y] = False
    return path

def main():
    tc = 1
    n, m = map(int, input().split())
    while n + m != 0:
        t = [(0, 0) for _ in range(3)]
        t_values = list(map(int, input().split()))
        for i in range(3):
            t[i] = (t_values[i * 2], t_values[i * 2 + 1])
        t.append((0, 1))
        visited = [[False for _ in range(m)] for _ in range(n)]
        total = n * m
        checkpoints = [total // 4, total // 2, 3 * total // 4, n * m]
        result = dfs(0, 0, 1, checkpoints, t, visited, visited, n, m, total)
        print(f"Case {tc}: {result}")
        tc += 1
        n, m = map(int, input().split())


if __name__ == "__main__":
    main()
