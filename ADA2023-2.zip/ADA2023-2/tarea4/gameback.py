from sys import stdin

def compare(str1, str2):
    if str1 + str2 < str2 + str1:
        return True
    return False

def backtrack(num, start, end):
    if start == end:
        print(''.join(num))
    else:
        for i in range(start, end+1):
            num[start], num[i] = num[i], num[start]
            if compare(num[start], num[start+1]):
                backtrack(num, start+1, end)
            num[start], num[i] = num[i], num[start]

def main():
    n = int(stdin.readline())
    while n != 0:
        line = stdin.readline()
        elementos = line.split()
        num = []
        for x in elementos:
            num.append(x)
        backtrack(num, 0, len(num)-1)
        n = int(stdin.readline())

main()
