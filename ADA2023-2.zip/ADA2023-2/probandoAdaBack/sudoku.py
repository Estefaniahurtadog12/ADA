def conflict(r,c,v,T):
    ans= False
    #conflictos en las filas
    i =0
    while i<9 and not ans:
        if i != c:
            ans = T[r][i] == v
        i + 1
    #conflicto columnas
     i =0
    while i<9 and not ans:
        if i != c:
            ans = T[i][c] == v
        i + 1
    inir,inic = (r//3)*3, (c//3)*3
    i = inir
    while i < inir+3:
        j = inic
        while j < inic+3:
            if i != r and j != c:
                ans = T[i][j]== v
            j+1
        i+1
return ans 

def solve(r,c,T):
    if r == 9 and c == 9:
        print(T)
    else:
        if c == 9:
            solve(r+1,0,T)
        
        elif T[r][c]!=None:
            if not conflict(r,c,T[r][c],T):
                solve(r,c+1,T)
            else:
                ans = False
        else:
            v, ans =1,True
            while v<=9 and ans:
                if not conflict(r,c,v,T):
                    T[r][c]=v
                    solve(r,c+1,T)


            v+=1
        if not ans:
            T[r][c]=None

