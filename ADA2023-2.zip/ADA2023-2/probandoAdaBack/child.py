
from sys import stdin
contSolu = 0


def solve(i,sol,S,A):
    global contSolu
    if i ==len(S):
        print(''.join(sol))
        contSolu +=1
    elif contSolu < 100:
        if S[i]== '0': #omitimos el cero, pero debemos tomar la posibilidad de no omitirlo 
            solve(i+1, sol, S, A)
        j=0
        while j<len(A):
            c,code = A[j]
            if i + len(code) <= len(S) and code==S[i:i + len(code)]:
                sol.append(c)
                solve(i+len(code), sol, S, A)
                sol.pop()
            j+1

def main():
    case = 1
    N = int(stdin.readline())
    while N != 0:
        A= []
        for _ in range(N):
            c,code = stdin.readline().split()
            A.append((c,code))
        S= stdin.readline().strip()
        A.sort()
        contSolu=0
        solve(0,[],S,A)
        print()
        case +=1
        N=int(stdin.readline())
main()