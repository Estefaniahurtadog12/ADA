import sys
from math import fabs

EPS = 1e-7

def dcmp(x, y):
    return 0 if fabs(x - y) <= EPS else -1 if x < y else 1

def f(r):
    minOthers = 0

    for i in range(n):
        time = r / running[i] + (t - r) / cycling[i]

        if i != n - 1:
            if i == 0 or dcmp(minOthers, time) > 0:
                minOthers = time
        else:
            return minOthers - time
    return -1

def ternary():
    leftR, rightR = 0, t

    while rightR - leftR > EPS:
        g = leftR + (rightR - leftR) / 3
        h = leftR + 2 * (rightR - leftR) / 3

        if f(g) > f(h):
            rightR = h
        else:
            leftR = g

    return (leftR + rightR) / 2

while True:
    line = sys.stdin.readline()
    if not line:
        break

    t, n = map(int, line.strip().split())
    running = []
    cycling = []

    for _ in range(n):
        r, k = map(float, sys.stdin.readline().strip().split())
        running.append(r)
        cycling.append(k)

    ans = ternary()
    time = f(ans) * 3600

    if dcmp(time, 0) > 0:
        print("The cheater can win by {} seconds with r = {:.2f}km and k = {:.2f}km.".format(int(time), ans, t - ans))
    else:
        print("The cheater cannot win.")
