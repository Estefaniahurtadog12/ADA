from sys import stdin

def letraIndice(letra):
    return ord(letra) - ord('a')

def solve(s, k):
    n = len(s)
    cont = [[0] * 27 for _ in range(n // k + 1)]
    letDifere = 0
    for i in range(n // k):
        for j in range(k):
            if cont[i][letraIndice(s[i * k + j])] == 0:
                letDifere += 1
            cont[i][letraIndice(s[i * k + j])] += 1
    
    memo = [[-1] * 27 for _ in range(n // k + 1)]
    
    def dp(idxSubcadena, ultimaLetra):
        if idxSubcadena == n // k:
            return letDifere
        if memo[idxSubcadena][ultimaLetra] != -1:
            return memo[idxSubcadena][ultimaLetra]
        
        ans = float("inf")
        for i in range(k):
            if letraIndice(s[idxSubcadena * k + i]) != ultimaLetra or cont[idxSubcadena][ultimaLetra] == k:
                res = dp(idxSubcadena + 1, letraIndice(s[idxSubcadena * k + i]))
                if cont[idxSubcadena + 1][letraIndice(s[idxSubcadena * k + i])] != 0:
                    res -= 1
                ans = min(ans, res)
        
        memo[idxSubcadena][ultimaLetra] = ans
        return ans
    
    return dp(0, 26)

def main():
    read = stdin.readline
    cases = int(read().strip())
    
    for _ in range(cases):
        line = read().strip().split()
        s, k = line[1], int(line[0])
        result = solve(s, k)
        print(result)

main()
