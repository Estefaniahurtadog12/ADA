from sys import stdin

## arboles 1 , tierra 0
def solve(filaLists, colm, tierrra):
    # matriz matriz
    matriz = []
    for i in range(filaLists):
        filaList = []
        for j in range(colm):
            filaList.append(0)  #todas las celdas de la matriz en 0
        matriz.append(filaList)

    for j in range(colm):
        cont = 0  #contar las celdas sin arboles en una columna
        for i in range(filaLists):
            if tierrra[i][j] == 0:
                cont += 1  # incrementa si tierrra[i][j] es igual a 0 (sin arbol)
            else:
                cont = 0  #si tierrra[i][j] no es igual a 0 (hay un árbol)
            matriz[i][j] = cont  #valor de la matriz

    #area del rectangulo mas grande que no contiene arboles
    areaMax = -float("inf") 

    i = 0
    while i < filaLists:
        alturas = matriz[i]
        stack = []  # pila
        stack.append(-1)  # agrega el valor -1 a la pila como valor inicial

        for j in range(colm):
            while not(stack[-1] == -1 or alturas[stack[-1]] < alturas[j]):
                h = alturas[stack.pop()]  # desapila y obtiene la altura
                w = j - stack[-1] - 1  # calcula el ancho del rectángulo
                if h * w > areaMax:
                    areaMax = h * w  # actualiza areaMax si el área actual es mayor
            stack.append(j)

        while len(stack) > 1:
            h = alturas[stack[-1]]  #la altura de la pila
            stack.pop()  # Desapila
            w = colm - stack[-1] - 1  # ancho del rectangulo
            if h * w > areaMax:
                areaMax = h * w  # actualiza areaMax si el area actual es mayor
        i += 1

    return areaMax


def main():
    read = stdin.readline
    filaLists, colm = map(int, read().strip().split())  #num filaLists y columnas

    while filaLists != 0 or colm != 0:
        tierrra = []
        for _ in range(filaLists):
            filaList = list(map(int, read().strip().split()))  #filaList de la matriz
            tierrra.append(filaList)

        print(solve(filaLists, colm, tierrra)) 
        filaLists, colm = map(int, read().strip().split())  

main() 
