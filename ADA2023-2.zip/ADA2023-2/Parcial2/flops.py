from sys import stdin

# se decide poner a fuera, debido a que cada que se hacia la recursion, esta se tenia que calcular la misma cantidad de veces que al recursion, esto lo hacia ineficiente, por eso el anterior daba time limit
def letraIndice(letra):
    return ord(letra) - ord('a')

def solve(idxSubcadena, ultimaLetra, cont, letDifere, cadena, k, memo):
    #ultimaLetra: La ultima letra utilizada en la subcadena anterior
    # cont:matriz que registra cuantas veces aparece cada una letra en la subcadena
    # letDifere: letras diferentes en la subcadena
    # cadena: cadena completa
    # k:longitud de cada subcadena
    # memo: meoria
    ans = float("inf")  

    #tamano de cada subcadena que se parte en k 
    if idxSubcadena == len(cadena) // k:
        ans = letDifere
    elif (idxSubcadena, ultimaLetra) in memo:
        ans = memo[(idxSubcadena, ultimaLetra)]
    else:
        for i in range(k):
            #recorremos todas las letras de la subcadena en la que estamos
            #si no es la misma letra de la sub cadena pasada, se mira la letra en la que estamos como posible letra que acaba la anterior sub cadena
            #ord 'a' -> codigo ascci en valor numero de cada letra para saber de que letra me estan hablando
            if letraIndice(cadena[idxSubcadena * k + i]) != ultimaLetra or cont[idxSubcadena][ultimaLetra] == k:
                res = solve(idxSubcadena + 1, letraIndice(cadena[idxSubcadena * k + i]), cont, letDifere, cadena, k, memo)
                
                #si la siguiente subcadena tiene la letra actual, resta 1 a 'res'
                if cont[idxSubcadena + 1][letraIndice(cadena[idxSubcadena * k + i])] != 0:
                    res -= 1

                #vamos a actualiza 'ans' tomando el minimo entre el valor actual y 'res'
                ans = min(ans, res)

        #la repsuesta la guardamos en la memoria para que volver a calcularla
        memo[(idxSubcadena, ultimaLetra)] = ans

    return ans

def main():
    read = stdin.readline 
    cases = int(read().strip())  #casos de prueba

    for _ in range(cases):
        line = read().strip().split()  #leo y parto la linea
        s, k = line[1], int(line[0]) #s--> cadena k -->longitudsubcadena #pos1 = s y pos0 = k

        cont = [[0 for _ in range(27)] for _ in range(1001)]  

        letDifere = 0 

        #cantidad de letras diferentes y y llenamos la matriz de las letras
        for i in range(len(s) // k):
            for j in range(k):
                if cont[i][letraIndice(s[i * k + j])] == 0:
                    letDifere += 1
                cont[i][letraIndice(s[i * k + j])] += 1

        print(solve(0, 26, cont, letDifere, s, k, {}))

main()
