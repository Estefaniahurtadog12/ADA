from collections import Counter

# Esta función toma una subcadena y devuelve el número mínimo de chunks
def min_chunks_memo(substring, memo):
  # Si ya hemos calculado el resultado para esta subcadena, lo retornamos
  if substring in memo:
    return memo[substring]
  
  # Contamos la frecuencia de cada carácter en la subcadena
  freq = Counter(substring)
  
  # Ordenamos los caracteres por su frecuencia
  sorted_chars = sorted(freq.keys(), key=lambda x: -freq[x])
  
  # Creamos una nueva subcadena con los caracteres agrupados por su frecuencia
  new_substring = "".join(char * freq[char] for char in sorted_chars)
  
  # El número de chunks es igual al número de caracteres distintos en la subcadena
  num_chunks = len(sorted_chars)
  
  # Almacenamos el resultado en el diccionario memo para reutilizarlo en el futuro
  memo[substring] = num_chunks
  
  # Retornamos el número de chunks
  return num_chunks

# Esta función toma una cadena S y un número k que divide su longitud
# Divide la cadena en bloques de k caracteres y los reordena para minimizar el número de chunks
# Utiliza memorización para almacenar los resultados de los subproblemas
def fewest_flops_memo(S, k):
  # Inicializamos el diccionario para la memorización
  memo = {}
  
  # Inicializamos el número mínimo de chunks
  min_chunks_total = 0
  
  # Recorremos la cadena de k en k caracteres
  for i in range(0, len(S), k):
    # Obtenemos el bloque actual de k caracteres
    block = S[i:i+k]
    
    # Llamamos a la función auxiliar con memorización para minimizar el número de chunks en el bloque
    num_chunks = min_chunks_memo(block, memo)
    
    # Sumamos el número de chunks del bloque al total
    min_chunks_total += num_chunks
  
  # Retornamos el número mínimo de chunks para toda la cadena
  return min_chunks_total

# Leemos el número de casos de prueba desde la entrada estándar
t = int(input())

# Para cada caso de prueba
for _ in range(t):
  # Leemos el número k y la cadena S desde la entrada estándar
  k, S = input().split()
  # Convertimos k a un entero
  k = int(k)
  # Llamamos a la función principal con memorización para resolver el problema
  min_chunks_total = fewest_flops_memo(S, k)
  
  # Escribimos el resultado en la salida estándar
  print(min_chunks_total)
