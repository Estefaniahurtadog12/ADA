from sys import stdin

def solve(m, n, land):

    # Inicializar matriz dp
    dp = []
    for i in range(m):
        row = []
        for j in range(n):
            row.append(0)
        dp.append(row)

    for j in range(n):
        for i in range(m):
            if land[i][j] == 0:
                dp[i][j] = dp[i-1][j] + 1
    

    # Calcular el área del rectángulo más grande que no contiene árboles
    max_area = -float("inf")

    '''for i in range(m):
        heights = dp[i]
        stack = [-1]'''
    i = 0
    while i < m:
        heights = dp[i]
        stack = [-1]

        for j in range(n):
            while not(stack[-1] == -1 or heights[stack[-1]] < heights[j]):
                h = heights[stack.pop()]
                w = j - stack[-1] - 1
                if h * w > max_area:
                    max_area = h * w
            stack.append(j)

        while len(stack) > 1:
            h = heights[stack[-1]]
            stack.pop()
            w = n - stack[-1] - 1
            if h * w > max_area:
                max_area = h * w
        i+=1

    return max_area

def main():
    read = stdin.readline
    m, n = map(int, read().strip().split()) # rows, cols

    while m != 0 or n != 0:
        land = []
        for _ in range(m):
            row = list(map(int, read().strip().split()))
            land.append(row)

        print(solve(m, n, land))
        m, n = map(int, read().strip().split())

main()