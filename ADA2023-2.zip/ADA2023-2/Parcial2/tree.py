from sys import stdin

def solve(depths, edges, k):
    num_caminos = 0
    visited = []

    for node, _ in depths:
        count = 0
        curr = node
        flag = False

        i = 0
        while i < len(edges) and not flag:
            aumenta = False

            if curr in edges[i] and not i in visited:
                count += 1
                edges[i].remove(curr)
                visited.append(i)

                curr = i
                aumenta = True

                if count == k:
                    num_caminos += 1
                    flag = True
                else:
                    edges[i] = []

            i = i + 1 if not aumenta else 0

    return num_caminos

def calculate_depth(node, depth, depths, edges):
    depths[node] = (node, depth)
    for child in edges[node]:
        calculate_depth(child, depth + 1, depths, edges)

def main():
    read = stdin.readline
    line = read().strip()

    while line:
        N, M, k = map(int, line.split())
        edges = [[] for _ in range(N)]
        depths = [(0, 0) for _ in range(N)]

        for _ in range(M):
            node, *childrens = map(int, read().strip().split())
            edges[node] = childrens

        calculate_depth(0, 0, depths, edges)

        depths.sort(key = lambda x: -x[1])
        ans = solve(depths, edges, k)
        print(ans)
        line = read().strip()

main()
