from sys import stdin

def lectura():
    testcase = int(stdin.readline())
    testcases = []
    i = 0
    while i < testcase:
        n = int(stdin.readline())
        orders = []
        j = 0
        while j < n:
            orders.append(stdin.readline().strip())
            j += 1
        testcases.append((n, orders))
        i += 1   
    return testcases


def acciones(n, orders):
    compra = {}  # diccionario
    venta = {}  # diccionario
    stock = -1
    results = []
    i = 0
    while i < len(orders):
        order = orders[i]
        order_list = order.split()
        cmd, item, price = order_list[0], int(order_list[1]), int(order_list[4])
        item, price = int(item), int(price)

        if cmd == 'buy':
            compra[price] = compra.get(price, 0) + item
        elif cmd == 'sell':
            venta[price] = venta.get(price, 0) + item
        i += 1

        while compra and venta and max(compra) >= min(venta):
            max_compra = max(compra)
            min_venta = min(venta)
            p_item = compra[max_compra]
            q_item = venta[min_venta]
            change = min(p_item, q_item)
            stock = min_venta
            p_item -= change
            q_item -= change
            compra.pop(max_compra, None)
            if p_item != 0:
                compra[max_compra] = p_item
            venta.pop(min_venta, None)
            if q_item != 0:
                venta[min_venta] = q_item
        
        min_venta = min(venta, default='-')
        max_compra = max(compra, default='-')
        stock_value = str(stock) if stock != -1 else '-'
        results.append((min_venta, max_compra, stock_value))
    return results




def main():
    testcases = lectura()
    i = 0
    while i < len(testcases):
        n, orders = testcases[i]
        results = acciones(n, orders)
        j = 0
        while j < len(results):
            result = results[j]
            print(" ".join(map(str, result)))
            j += 1
        i += 1
main()



