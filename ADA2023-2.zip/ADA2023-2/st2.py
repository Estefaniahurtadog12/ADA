from sys import stdin

def lectura():
    caso = int(stdin.readline())
    listaCasos = []
    i = 0
    while i < caso:
        n = int(stdin.readline())
        pruebaActual = []
        j = 0
        while j < n:
            pruebaActual.append(stdin.readline().strip())
            j += 1
        listaCasos.append((n, pruebaActual))
        i += 1
    return listaCasos

def acciones(n, pruebaActual):
    precio = 0 
    #disponibles para venta
    venta = {}
    #disponibles para compra
    compra = {}
    resultado = []
    i = 0
    
    while i < len(pruebaActual):
        order = pruebaActual[i]
        cadenaCortada = order.split()
        instruccion, cantAcciones, precioActual = cadenaCortada[0], int(cadenaCortada[1]), int(cadenaCortada[4])
        cantAcciones, precioActual = int(cantAcciones), int(precioActual)
        #ejecutar instruccion (compra y venta )
        if instruccion == 'buy':
            compra[precioActual] = compra.get(precioActual, 0) + cantAcciones
        elif instruccion == 'sell':
            venta[precioActual] = venta.get(precioActual, 0) + cantAcciones
        i += 1
        #realiza intercambios entre compra y venta
        while compra and venta and max(compra) >= min(venta):
            #intercambio acciones al precio apropiado
            PrecioCompra = max(compra)
            PrecioVenta = min(venta)
            accionesCompra = compra[PrecioCompra]
            accionesVenta = venta[PrecioVenta]
            #calcula la cantidad maxima de acciones que se pueden intercambiar
            intercambio = min(accionesCompra, accionesVenta)
            #actualiza las cantidades de acciones y precio despues del intercambio realizado
            precio = PrecioVenta
            accionesCompra -= intercambio
            accionesVenta -= intercambio
            compra.pop(PrecioCompra, None)
            if accionesCompra != 0:
                    compra[PrecioCompra] = accionesCompra
            else:
                compra.pop(PrecioCompra, None)
            if accionesVenta != 0:
                venta[PrecioVenta] = accionesVenta
            else:
                venta.pop(PrecioVenta, None) 
        #calcula precios y los agrega a la lista final
        PrecioVenta = min(venta, default='-')
        PrecioCompra = max(compra, default='-')
        precioAccion = str(precio) if precio != 0 else '-'
        resultado.append((PrecioVenta, PrecioCompra, precioAccion))
    return resultado

def main():
    listaCasos = lectura()
    i = 0
    while i < len(listaCasos):
        n, pruebaActual = listaCasos[i]
        resultado = acciones(n, pruebaActual)
        j = 0
        while j < len(resultado):
            result = resultado[j]
            print(" ".join(map(str, result)))
            j += 1
        i += 1
main()
