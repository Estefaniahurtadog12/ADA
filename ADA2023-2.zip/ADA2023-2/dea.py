EPSILON = 1e-6

def time(r, speed, t):
    return r / speed[0] + (t - r) / speed[1]

def objective(t, r, speeds):
    cheater_time = time(r, speeds[-1], t)
    other_times = [time(r, speed, t) for speed in speeds[:-1]]
    return min(other_times) - cheater_time

def main():
    global T,A
    line = stdin.readline()
    while len(line)!=0:
        if len(line)==1: line=stdin.readline()
        T,n,A = int(line),int(stdin.readline()),list()
        while len(A)!=n:
            x = stdin.readline().split()
            A.append((float(x[0]), float(x[1])))
        
        def solve(t, speeds):
            left, right = 0, t
            best_r, best_advantage = 0, 0

            while right - left > EPSILON:
                mid = (left + right) / 2
                advantage = objective(t, mid, speeds)

                if advantage > best_advantage:
                    best_r = mid
                    best_advantage = advantage

                if objective(t, mid + EPSILON, speeds) > objective(t, mid, speeds):
                    left = mid
                else:
                    right = mid
            
            if best_advantage > 0:
                k = t - best_r
                return f"The cheater can win by {best_advantage*3600:.0f} seconds with r = {best_r:.2f}km and k = {k:.2f}km."
            else:
                return "The cheater cannot win."

        ans = solve(T,A)
        print(ans)
        line = stdin.readline()
