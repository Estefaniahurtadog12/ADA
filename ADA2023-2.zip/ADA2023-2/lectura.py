from sys import stdin 

def  main():
    line = stdin.readline()
    while len(line)=!0:
        x,y = map(int,line.split())
        print(solve(x,y))
        line = stdin.readline()

