from sys import stdin
import heapq

def leer_entrada():
    Y = int(stdin.readline())
    casos = []
    x = 0  # Inicializar x fuera del bucle
    
    while x < Y:  # Usar un bucle while en lugar de un bucle for
        v = stdin.readline()
        n = int(stdin.readline())
        orders = [tuple(map(int, stdin.readline().split())) for _ in range(n)]
        casos.append((n, orders))
        x += 1  # Incrementar x en cada iteración
    
    return casos


def main():
    
    casos = leer_entrada()
    for x, (n, orders) in enumerate(casos):
        orders = sorted(orders, key=lambda x: x[1])
        queue =[] 
        total_tons= 0
        for order in orders:
            total_tons += order[0]
            heapq.heappush(queue, -order[0])
            while total_tons > order[1]:
                n -= 1
                total_tons += heapq.heappop(queue)

        print(n)  # Imprimir el valor de n para cada caso
        if x < len(casos) - 1:
            print()  # Imprimir una línea en blanco entre casos

main()
