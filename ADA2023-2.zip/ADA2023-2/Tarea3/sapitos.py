using namespace std;
long long a[105];
char b[105];
long long c[105]
int main()
{ios_base::sync_with_stdio(false)};
cin.tie(NULL);
int t; cin>>t;
for(int j=0; j<105;j++){a[j]=0;c[j]=0;}
for(int j=0; j<n;j++){
    char s,t;cin>>s>>t;int m; cin>>m;
    b[j]=s;c[j]=m;
    if(j==0){a[j]=m;}
    else
    {
        a[j]=(m-c[j-1]);
        if(b[j-1]=='S'){
            a[j-1] += a[j];
        }
        else
        {
            if(a[j-1]>a)[j]{}
            else
            {
                a[j-1]=a[j];
            }
        }
        if(j==(n-1)){
            if(b[j]=='S'){
                a[j]+=(d-m);
            }
            else
            {
                if(a[j]>(d-m)){}
                else
                {
                    a[j]=(d-m)
                }
            }
        }
        
    }
    int maxx=0;
    for(long long z:a){
        if(z>maxx){maxx=z;}
    }
    cout<<"Case"<<i+1<<": "<<maxx<<"\n";
}
return 0;
}