#se elige siempre la denominacion mayor para realizar la menor cantidad de monedad utilzadas posibles
def monederio(cantidad, denominaciones):
    denominaciones.sort(reverse=True)
    resultado = []
    for moneda in denominaciones:
        while cantidad >= moneda:
            cantidad -= moneda
            resultado.append(moneda)
    return resultado

# Prueba del algoritmo
#denominaciones = [1, 5, 10, 25]  
denominaciones = [1, 8,10]  
cantidad = 16  #cant que necesitamos cambio
print(monederio(cantidad, denominaciones))
