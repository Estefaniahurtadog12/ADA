res = []

def greedy(n, h):
    if 2**h > n:
        for i in range(h):
            res.append(2**i)
        return True
    else:
        return False

def main():
    t = 1
    while True:
        n, h = map(int, input().split())
        if n == 0 and h == 0:
            break
        res.clear()
        print("Case " + str(t) + ":", end="")
        t += 1
        if not greedy(n, h):
            print(" Impossible.")
            continue
        for i in range(len(res)):
            print(' ' + str(res[i]), end="")
        print()

main()
