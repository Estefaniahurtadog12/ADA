from sys import stdin
import heapq

def leer_entrada():
    casosPrueba = int(stdin.readline())  #casos de prueba
    casos = []  #lista para almacenar los casos
    for contCasos in range(casosPrueba):  #itera en cada caso
        blanco = stdin.readline()  # linea vacia
        ordenes = int(stdin.readline())  #ordenes de cada caso

        tuplaOrdenes = tuple(tuple(map(int, stdin.readline().split())) for _ in range(ordenes)) #lee y almacena las ordenes en forma de tuplas (cantidad requerida, fecha limi)
        casos.append((ordenes, tuplaOrdenes))  #añadir caso a la lista de casos
    return casos  #lista casos

def main():
    casos = leer_entrada()  #casos de prueba
    contCasos = 0  #contador para los casos
    while contCasos < len(casos):  
        ordenes, tuplaOrdenes = casos[contCasos]  #num de ordenes y las ordenes del caso que s eesta trabajando
        colaPrioridad = []  #cola de prioridad par aordenes
        contAceroProcess = 0  #acero procesadas
        tuplaOrdenes = sorted(tuplaOrdenes, key=lambda contCasos: contCasos[1])# Ordena las ordenes por fecha ASC
        i = 0  # cont ordenes
        while i < len(tuplaOrdenes):
            ordenActu = tuplaOrdenes[i]  #rden actual en la que trabaja
            contAceroProcess += ordenActu[0]  # aumenta toneladas procesadas
            heapq.heappush(colaPrioridad, -ordenActu[0])  #añadde cantidad requerida a la cola de prioridad -
            basta = False#basta procesamiento de ordenes 
            while not basta:#procesa si cumpla la fecha limite
                if contAceroProcess <= ordenActu[1]:  # Si la cantidad total es menor o igual a la fecha límite
                    basta = True  #basta--alto(se paro la vaina)
                else:
                    ordenes = ordenes - 1  # menos una orden aceptadas
                    contAceroProcess = contAceroProcess + heapq.heappop(colaPrioridad)  # menos cantidad de la orden mas vieja
            i += 1  #siguiente pedido 

        print(ordenes)  #ordenes check
        if contCasos < len(casos) - 1:
            print() 
        contCasos += 1  #siguiente caso

main() 
