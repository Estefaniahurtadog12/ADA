def mone(cantidad, coins):
    if cantidad == 0:
        print("")
        return 0
    
    for i in range(len(coins), 0, -1):
        coin = coins[i-1]

        if cantidad >= coin:
            print(coin, end=" ")
            return 1 + mone(cantidad - coin, coins)
    
    print("NO SE PUEDE DEVOLVER"":")
    print("CENTAVOS RESTANTES", cantidad)
    
#PROBANDO
cantidad = 99
coins = [1, 5, 10, 25]

mone(cantidad, coins)
