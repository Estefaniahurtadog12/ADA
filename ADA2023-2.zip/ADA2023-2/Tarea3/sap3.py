from sys import stdin

def GetWorstDistance(N, positions, isSmall, hit):
    minDist = positions[0]
    for i in range(N):
        hit[i] = True
        if not isSmall[i + 1]:
            minDist = max(minDist, positions[i + 1] - positions[i])
        else:
            minDist = max(minDist, positions[i + 2] - positions[i])
            i += 1

    for i in range(N, 0, -1):
        if not hit[i - 1] or not isSmall[i - 1]:
            minDist = max(minDist, positions[i] - positions[i - 1])
        else:
            minDist = max(minDist, positions[i] - positions[i - 2])
            i -= 1
    return minDist

def main():
    T = int(stdin.readline())
    for t in range(1, T+1):
        D = list(map(int,stdin.readline().split()))
        N, D = D[0], D[1]
        
        # Inicialización de las listas dentro de la función main
        isSmall = [False]*(N+2)
        hit = [False]*(N+2)
        positions = [0]*(N+2)

        rocks = stdin.readline().split()
        for i in range(N):
            type_sep_positions = rocks[i].split('-')
            type_ = type_sep_positions[0]
            positions[i] = int(type_sep_positions[1])
            isSmall[i] = (type_ == 'S')
            
            hit[i] = False
        
        isSmall[N] = False
        positions[N] = D
        hit[N] = False
        
        print(f"Case {t}: {GetWorstDistance(N, positions, isSmall, hit)}")

main()
