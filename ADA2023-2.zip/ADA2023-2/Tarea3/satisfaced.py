import heapq

class Point:
    def __init__(self, spd, ddl):
        self.spd = spd
        self.ddl = ddl

    def __lt__(self, other):
        if self.ddl != other.ddl:
            return self.ddl < other.ddl
        else:
            return self.spd < other.spd

q = []
p = []

t = int(input())
input()  # Leer línea en blanco

while t > 0:
    t -= 1
    while len(p) > 0:
        p.pop()
    now = Point(0, 0)
    last = 0
    n = int(input())

    for i in range(n):
        sp, ne = map(int, input().split())
        heapq.heappush(q, Point(sp, ne))
    while len(q) > 0:
        now = heapq.heappop(q)
        if last + now.spd <= now.ddl:  # Cambio en la condición
            last += now.spd
            heapq.heappush(p, Point(now.spd, now.ddl))
    #print(len(p))
    print(len(p), end='\n\n')
    if t > 0:
        input()  # Leer línea en blanco si no es la última prueba
