from sys import stdin

def main():
    # Leer el número de casos de prueba
    Y = int(stdin.readline())
    
    # Iterar sobre cada caso de prueba
    for i in range(Y):
        # Leer el número de rocas y la distancia total
        N, D = map(int, stdin.readline().split())
        
        # Leer las rocas y sus distancias
        rocas, recorrido, maximo, ultima = [item.split('-') for item in stdin.readline().split()], 0, 0, 0
        
        # Iterar mientras no se haya recorrido todas las rocas
        while recorrido < N:
            # Si es la primera roca o es una roca grande
            if recorrido == 0 or rocas[recorrido][0] == 'B':
                # Si es una roca pequeña
                if rocas[recorrido][0] == 'S':
                    rocas[recorrido][0] = False
                
                # Actualizar el salto máximo y la última roca
                maximo = max(maximo, int(rocas[recorrido][1])-ultima)
                ultima = int(rocas[recorrido][1])
            else:
                # Actualizar el salto máximo y la última roca
                maximo = max(maximo, int(rocas[recorrido][1])-ultima)
                ultima = int(rocas[recorrido][1])
                
                # Marcar la roca como usada
                rocas[recorrido][0] = False
            
            # Avanzar al siguiente par de rocas si la siguiente es grande
            if recorrido+1 < N and rocas[recorrido+1][0] == 'B':
                recorrido += 1
            else: 
                recorrido += 2
        
        # Actualizar el salto máximo con la distancia a la orilla derecha
        maximo, ultima = max(maximo, D-ultima), D
        
        # Iterar sobre las rocas en orden inverso
        for recorrido in range(N-1,-1,-1):
            if rocas[recorrido][0] != False: 
                maximo = max(maximo, ultima-int(rocas[recorrido][1]))
                ultima = int(rocas[recorrido][1])
        
        # Imprimir el resultado
        print("Case {}: {}".format(i+1,maximo))

# Ejecutar el programa principal
main()
