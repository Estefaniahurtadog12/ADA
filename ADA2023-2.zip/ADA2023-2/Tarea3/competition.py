import sys 
def main():
    n, l, c = map(int, sys.stdin.readline().split())
    page = 1
    line = 1
    ch = 1
    for i in range(n):
        word = sys.stdin.readline().strip()
        len_word = len(word)
        if ch + 1 + len_word <= c:
            ch += 1 + len_word
        else:
            ch = len_word
            line += 1
            if line > l:
                line = 1
                page += 1
    print(page)  # Imprime el número de página después de agregar todas las palabras

main()