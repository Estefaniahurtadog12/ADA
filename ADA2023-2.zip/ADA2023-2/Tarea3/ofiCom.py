from sys import stdin

def lectu():
    entrada = []  #lista para almacenar los datos de entrada
    for linea in stdin:
        # Divide la línea en palabras y convierte cada parte en un entero
        divPalab = linea.split()
        N = int(divPalab[0])  # num de palabras en el cuento
        L = int(divPalab[1])  # Max de líneas por pag
        C = int(divPalab[2])  # Max de caractenumMinPagi por linea
        palabras = stdin.readline().split()  #lee la linea siguiente que contiene las palabras
        # Agrega los datos a la lista como una tupla
        entrada.append((N, L, C, palabras))
    return entrada

def main():
    lecturaEntrada = lectu()  #leee los datos de entrada
    for N, L, C, palabras in lecturaEntrada:  #itera en cada caso de prueba
        flagCabe = True  #verificar si la palabra actual cabe o no en la linea
        tamaLineaAct, contLineas = 0, 0 
        while palabras:
            #calcula la longi de la palabra actual y considera un espacio si ya hay palabras en la linea
            longPalEspacio = len(palabras[0]) + int(tamaLineaAct > 0)
            if tamaLineaAct + longPalEspacio <= C and flagCabe:
                tamaLineaAct += longPalEspacio
                palabras.pop(0)  # eliminar la palabra proces de la lista de palabras
            else:
                tamaLineaAct = 0  # reinicia tamano de la linea
                contLineas += 1  
                flagCabe = True  #reinciar flag
        contLineas += int(bool(tamaLineaAct > 0))  #incrementar el contador de líneas si hay palabras en la ultima linea
        numMinPagi = (contLineas + L - 1) // L  #calcula el numero min de paginas
        print(numMinPagi)  
main() 
