res = []

def recursion(l, r, h):
    if l == r:
        return
    if not h:
        return

    for i in range(l, r):
        if i - l <= 2**(h - 1) - 1 and (r - i - 1 <= 2**(h - 1) - 1):
            res.append(i + 1)
            recursion(l, i, h - 1)
            recursion(i + 1, r, h - 1)
            break

def main():
    t = 1
    while True:
        n, h = map(int, input().split())
        if n == 0 and h == 0:
            break
        res.clear()
        print("Case " + str(t) + ":", end="")
        t += 1
        if 2**h <= n:
            print(" Impossible.")
            continue
        recursion(0, n, h)
        for i in range(len(res)):
            print(' ' + str(res[i]), end="")
        print()

main()
