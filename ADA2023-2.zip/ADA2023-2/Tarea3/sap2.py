N = 0
isSmall = [False]*105
hit = [False]*105
positions = [0]*105

def GetWorstDistance():
    minDist = positions[0]
    global N
    for i in range(N):
        hit[i] = True
        if not isSmall[i + 1]:
            minDist = max(minDist, positions[i + 1] - positions[i])
        else:
            minDist = max(minDist, positions[i + 2] - positions[i])
            i += 1

    for i in range(N, 0, -1):
        if not hit[i - 1] or not isSmall[i - 1]:
            minDist = max(minDist, positions[i] - positions[i - 1])
        else:
            minDist = max(minDist, positions[i] - positions[i - 2])
            i -= 1
    return minDist

def main():
    T = int(input())
    
    for t in range(1, T+1):
        global N
        D = list(map(int,input().split()))
        print(D)# ARREGLO [1 ,10]
        N, D = D[0], D[1] # N=[1] D=[10]
        for i in range(N):
            type_sep_positions = input().split('-')
            print(type_sep_positions)
            type_ = type_sep_positions[0]#tipo B
            positions[i] = int(type_sep_positions[1])
            print(positions[i])
            isSmall[i] = (type_ == 'S')
            
            hit[i] = False
        
        isSmall[N] = False
        positions[N] = D
        hit[N] = False
        
        #print("Case ", t, ": ", GetWorstDistance())
        print("Case ", t":", GetWorstDistance())

if __name__ == "__main__":
    main()
