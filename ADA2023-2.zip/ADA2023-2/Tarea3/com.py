while True:
    try:
        N, L, C = map(int, input().split())
        words = input().split()
        sz = 0
        line = 0
        i = 0
        while i < N:
            if sz + len(words[i]) + (0 if sz == 0 else 1) <= C:
                sz += len(words[i]) + (0 if sz == 0 else 1)
                i += 1
            else:
                sz = 0
                line += 1
        if sz > 0:
            line += 1
        res = line // L
        if line % L != 0:
            res += 1
        print(res)
    except EOFError:
        break
