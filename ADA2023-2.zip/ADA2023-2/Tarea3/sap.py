from sys import stdin 

esPeque = []  #lista para almacenar si una piedra es pequeña o grande
aterrizo = [] #aterrizo o no 

def sapitos(numPiedras, posi):
    global esPeque, aterrizo  
    minDist = posi[0]  #minDist la primera posicion de la piedra
    i = 0 
    while i < numPiedras:  #recorre todas las piedras
        aterrizo[i] = True  #piedra actual ya aterrizo en ella (visitada)
        saltos = (2, 1)  #incremento (2 o 1)
        incrementoSaltos = saltos[not esPeque[i + 1]]  #incremento segun el tipo de la piedra (grande o pequeña)
        dist = posi[i + incrementoSaltos] - posi[i]  #distancia entre la piedra que esta  y la siguiente
        if dist > minDist:  #si la distancia es > que la dist min actual
            minDist = dist  #se va actualizar la distancia min
        i += incrementoSaltos #aumenta cont

    i = numPiedras  #cont otra vez en 0
    siga = False  # flag en falso
    while i > 0 and not siga:  
        if not (aterrizo[i - 1] and esPeque[i - 1]):  #si aun la ranita no ha aterrizado en la piedra y la piedra no es pequeña
            dist = posi[i] - posi[i - 1]  #se va a calcular la distancia entre la piedra que esta y la anterior
            if dist > minDist:  #si es mayor que la distancia min actual
                minDist = dist  #actualiza la distancia min
            i -= 1  #-1 en el cont
        else:  #si ya ha estado en la piedra y es pequeña
            dist = posi[i] - posi[i - 2]  #distancia entre la piedra en la que esta y la antepenultima
            if dist > minDist:  #distancia es mayor a la distancia mina actual
                minDist = dist  #nueva distancia min
            i -= 2  #menos el contador en 2 para saltar dos rocas
        if i <= 0:  #si el cont llega a 0 o menos
            siga = True  #flag siga true y sale ciclo

    return minDist  #distancia mínima calculada

def main():
    global esPeque, aterrizo  
    numCasos = int(stdin.readline())  #casos de prueba
    for _ in range(1, numCasos+1):  # cada  caso de prueba
        numPiedras, distanciatotal = map(int, stdin.readline().split())  #num de piedras y distotal
        piedrero = stdin.readline().split()
        posi = []  #posiciones de las piedris

        i = 0
        while i < numPiedras + 2:
            posi.append(0)  #posición en 0
            esPeque.append(False)  #esPeque= false
            aterrizo.append(False)  #aterrizo= false
            i += 1

        
        i = 0
        while piedrero:  #
            tipoYposii = piedrero.pop(0).split('-')  # divide en tipo y posic
            piedraTipo = tipoYposii[0]  #ipo piedra (B o S)
            posi[i] = int(tipoYposii[1])  #pos piedra tipo entero
            esPeque[i] = (piedraTipo == 'S')  #pone que esPeque[i] es true si la piedra es peqie
            
            aterrizo[i] = False
            i += 1  

        esPeque[numPiedras] = False  #ultima piedra como No pequeña
        posi[numPiedras] = distanciatotal  # posición de la Ultima piedra como distanciatotal
        aterrizo[numPiedras] = False 
        
        print(f"Case {_}: {sapitos(numPiedras, posi)}")  

main() 
