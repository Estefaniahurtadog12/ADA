from sys import stdin
import heapq

def main():
    Y = int(stdin.readline())
    for x in range(Y):
        v = stdin.readline()
        n = int(stdin.readline())
        orders = [tuple(map(int, stdin.readline().split())) for _ in range(n)]
        orders = sorted(orders, key=lambda x: x[1])

        queue, total_tons = [], 0
        for order in orders:
            total_tons += order[0]
            heapq.heappush(queue, -order[0])
            while total_tons > order[1]:
                n -= 1
                total_tons += heapq.heappop(queue)

        if x == Y - 1:
            print(n)
        else:
            print(n, end='\n\n')

if __name__ == "__main__":
    main()
