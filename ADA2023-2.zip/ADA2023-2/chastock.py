import heapq

class MAXHEAP:
    def __lt__(self, a, b):
        return a[0] > b[0] or (a[0] == b[0] and a[1] < b[1])

class MINHEAP:
    def __lt__(self, a, b):
        return a[0] < b[0] or (a[0] == b[0] and a[1] < b[1])

def main():
    testcase = int(input())
    for _ in range(testcase):
        n = int(input())
        buy = []  # max-heap
        sell = []  # min-heap
        stock = -1
        for _ in range(n):
            cmd, item, share, at, price = input().split()
            item = int(item)
            price = int(price)
            if cmd == 'b':
                heapq.heappush(buy, (-price, item))
            if cmd == 's':
                heapq.heappush(sell, (price, item))
            while buy and sell:
                p = buy[0]
                q = sell[0]
                if -p[0] < q[0]:
                    break
                heapq.heappop(buy)
                heapq.heappop(sell)
                change = min(p[1], q[1])
                stock = q[0]
                p = (p[0], p[1] - change)
                q = (q[0], q[1] - change)
                if p[1]:
                    heapq.heappush(buy, p)
                if q[1]:
                    heapq.heappush(sell, q)
            if sell:
                print(sell[0][0], end=" ")
            else:
                print("- ", end="")
            if buy:
                print(-buy[0][0], end=" ")
            else:
                print("- ", end="")
            if stock != -1:
                print(stock)
            else:
                print("-")

if __name__ == "__main__":
    main()
