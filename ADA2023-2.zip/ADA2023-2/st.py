from sys import stdin

def lectura():
    # numero de casos de prueba
    caso = int(stdin.readline())  
    #almacenar los casos de prueba
    listaCasos = []  
    i = 0
    while i < caso:
        #num de casos que tendra el caso de prueba
        n = int(stdin.readline()) 
        pruebaActual = []  
        j = 0
        while j < n:
            #lee y agrega a la lista 
            pruebaActual.append(stdin.readline().strip())  
            j += 1
        listaCasos.append((n, pruebaActual))
        i += 1
    return listaCasos

def acciones(n, pruebaActual):
    venta = {}  #alamacenar venta
    compra = {}  #alamcenar compra
    precio = -1  #precio accion 
    resultado = [] #final
    i = 0
    while i < len(pruebaActual):
        order = pruebaActual[i]
        #partir palabras
        cadenaCortada = order.split() 
        instruccion, cantAcciones, precioActual = cadenaCortada[0], int(cadenaCortada[1]), int(cadenaCortada[4])
        cantAcciones, precioActual = int(cantAcciones), int(precioActual)

        if instruccion == 'buy':
            #actualiza compra
            compra[precioActual] = compra.get(precioActual, 0) + cantAcciones  
        elif instruccion == 'sell':
            #actualiza venta
            venta[precioActual] = venta.get(precioActual, 0) + cantAcciones  
        i += 1

        while compra and venta and max(compra) >= min(venta):
            PrecioCompra = max(compra)
            PrecioVenta = min(venta)
            accionesCompra = compra[PrecioCompra]
            accionesVenta = venta[PrecioVenta]
            #numero de acciones para intercambiar
            intercambio = min(accionesCompra, accionesVenta)
            # Actualiza el precio de la acción
            precio = PrecioVenta  
            accionesCompra -= intercambio  #-compra
            accionesVenta -= intercambio  #-venta
            #compra completada
            compra.pop(PrecioCompra, None)  
            if accionesCompra != 0:
                compra[PrecioCompra] = accionesCompra
            #venta completada
            venta.pop(PrecioVenta, None)  
            if accionesVenta != 0:
                venta[PrecioVenta] = accionesVenta
        
        PrecioVenta = min(venta, default='-')  #minimo venta
        PrecioCompra = max(compra, default='-')  #maximo compra
        precioAccion = str(precio) if precio != -1 else '-'  #precio acción 
        resultado.append((PrecioVenta, PrecioCompra, precioAccion)) 
    return resultado

def main():
    listaCasos = lectura()  
    i = 0
    while i < len(listaCasos):
        n, pruebaActual = listaCasos[i]
        resultado = acciones(n, pruebaActual) 
        j = 0
        while j < len(resultado):
            result = resultado[j]
            print(" ".join(map(str, result))) 
            j += 1
        i += 1
main()
