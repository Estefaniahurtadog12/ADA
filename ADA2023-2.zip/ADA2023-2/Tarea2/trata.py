
import sys

def calculate_dp(max_value):
    dp = [0] + [float('inf')] * max_value
    for i in range(1, 101):
        for j in range(i * i, max_value + 1):
            dp[j] = min(dp[j], dp[j - i * i] + 1)
    return dp

def main():
    # Lee el número de casos de prueba
    test_cases = int(sys.stdin.readline())

    # Calcula dp con un valor máximo suficientemente grande
    max_value = 10001  # Ajusta este valor según tus necesidades
    dp = calculate_dp(max_value)

    # Procesa cada caso de prueba
    for _ in range(test_cases):
        n = int(sys.stdin.readline())
        print(dp[n])

main()


