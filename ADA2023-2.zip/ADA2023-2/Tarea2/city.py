def city(n, x, f):
    #lista tab para almacenar la max destruccion hasta el ultimo segundo
    tab = [0] * (n + 1)
    for i in range(1, n + 1):
        #inicializar la maxima destruccion 
        destuMax = 0
        for j in range(1, i + 1):
            #calcular la destruccion posible en este segundo teniendo en cuenta  EMP
            destuSecond = min(x[i - 1], f[j - 1]) + tab[i - j]
            #actualizar destuMax si hay alguna mejor
            destuMax = max(destuMax, destuSecond)
        #guardar la maxima destrucción en el segundo donde nos encontremos 
        tab[i] = destuMax
    return tab[n]
n = 5
x = [1, 2, 3, 4, 5]  #robots que llegan en cada segundo
f = [10, 1, 2, 3, 4]  #capacidad EMP en cada segundo
destuMax = city(n, x, f)
print("max destru:", destuMax)
