#import sys
from sys import stdin
def squares(cuadrados, dic):
    # Inicializa tabla con valores 0 al valormax
    for i in range(1, cuadrados + 1): #caso base = cuando el valor de i = 1,
                                    #al inicio, se asume que se necesita un cuadrado perfecto para representar cada num desde 1 hasta el valor de cuadruados
        dic[i] = cuadrados + 1
    i = 1
    while i <= 100: 
        # calcular cuadrado de i
        j = i ** 2 
        # si se puede reducir la cantidad de cuadrados que se necesita para j 
        while j <= cuadrados:
            #  i^2
            if dic[j] > dic[j - pow(i, 2)] + 1:  
                dic[j] = dic[j - pow(i, 2)] + 1
            j += 1
        i += 1
    return dic

def main():
    #casos de prueba
    casos = int(stdin.readline())
    # Inicializa diccionario con valor max
    dic = {0: 0}
    cuadrados = 10001  #tamano problem
    dic = squares(cuadrados, dic)

    #num caso de prueba
    while casos > 0:
        #valor n
        n = int(stdin.readline()) 
        print(dic[n])  # menor cantidad de casospara representar n
        casos -= 1  #menos un caso
 

main()
