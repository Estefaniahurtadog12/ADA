import sys

def calcular_resultado(n, c, val):
    # Inicializar el diccionario memo
    memo = {0: 0, 1: val[n - 1]}

    i = n - 2
    has = 1

    while i >= 0:
        temp = memo.copy()  # Copiar el estado actual de memo para no afectar el cálculo siguiente
        memo[has] = (has and max(val[i] + temp[0], temp[has])) or max(temp[1] - val[i] - c, temp[0])

        if has == 1:
            has = 0
        else:
            has = 1
            i -= 1

    return memo[0]

def main():
    datos = []
    for line in iter(sys.stdin.readline, ''):
        n, c = map(int, line.split()[:2])
        val = list(map(int, sys.stdin.readline().split()))
        datos.append((n, c, val))

    for n, c, val in datos:
        resultado = calcular_resultado(n, c, val)
        print(resultado)

main()
