import sys

def stocks(n, c, listaValores, memo, diaActual, flagAccion):
    #si se llega al ultimo dia, no hay mas decisiones (compra -venta)
    if diaActual == n:
        respuesta = 0
    #buscamos si ese respuestaaod se encuentra en memoria
    elif (diaActual, flagAccion) in memo:
        respuesta = memo[(diaActual, flagAccion)]

    else:
        #no hacer ninguna acción en el dia actual
        sinAccion = stocks(n, c, listaValores, memo, diaActual + 1, flagAccion)
        #realizar una acción en el dia actual
        conAccion = stocks(n, c, listaValores, memo, diaActual + 1, 1 - flagAccion)
        #ganancia en el dia
        ganancia = (flagAccion * 2 - 1) * listaValores[diaActual] - (1 - flagAccion) * c
        #ganancia maxima entre compra ryv ender
        respuesta = max(sinAccion, conAccion + ganancia)
        memo[(diaActual, flagAccion)] = respuesta

    return respuesta


def main():
    sys.setrecursionlimit(2**20)
    datos = []
    for line in iter(sys.stdin.readline, ''):
        n, c = map(int, line.split()[:2])
        listaValores = list(map(int, sys.stdin.readline().split()))
        datos.append((n, c, listaValores))

    for n, c, listaValores in datos:
        respuestaado = stocks(n, c, listaValores,{}, 0 ,0)
        print(respuestaado)

main()
