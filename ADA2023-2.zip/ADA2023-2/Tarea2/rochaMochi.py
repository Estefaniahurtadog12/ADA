def mochi(B,W,C):
    N=len(B)
    tab=[[0 for _ in range (C+1)] for _ in range(2)]
    n,c,prev,curr = 1,0,0,1
    while n!= N+1:
        if c==C+1:
            m,c,prev,curr=n+1,0,curr,prev
        else:
            tab[curr][c] = tab[prev][c]
            if c<=W[n-1]:
                tab[curr][c] = max(tab[curr][c],B[n-1]+tab[prev][c-W[n-1]])
            c +=1
    return tab[curr][C]

b,w,c = [100,90,25],[10,8,3],11
print("Maximum profit is",mochi(b, w ,c))