Funcion que reciba dos parametros (a,b)
n = longitud(a)
    #conjuntos para A y B
    A = conjunto_vacío()
    B = conjunto_vacío() 
    #primeros dos minutos
    addA(A, 0)
    addA(A, a[0])
    addA(B, 0)
    addA(B, b[0])
    i = 2
    Mientras i <= n:
        #max A
        A_i = máximo(A)
        B_i_2 = copiar(B)
        addA(B_i_2, A_i)
        #max b
        B_i = máximo(B)
        A_i_2 = copiar(A)
        addA(A_i_2, B_i)
        #actu A y B
        borrar(A)
        addA(A, A_i)
        addA(A, a[i - 1])
        borrar(B)
        addA(B, B_i)
        addA(B, b[i - 1])
        i = i + 1
        Terminara si
    Repita lo anterior si condicionales sustituyendo A por B y viceversa y reemplazando ai por bi
    i+1
    Return max(Max[A][n], Max[B][n])
    
