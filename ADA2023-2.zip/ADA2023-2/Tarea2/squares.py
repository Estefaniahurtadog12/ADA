#MAX_VALUE = 10000

def getMinSizeSquareSum(n):
    memoTable = [float('inf')] * (n + 1)
    memoTable[0] = 0
    for i in range(1, n + 1):
        j = 1
        while j * j <= i:
            memoTable[i] = min(memoTable[i], memoTable[i - j * j] + 1)
            j += 1
    return memoTable[n]


def main():
    T = int(input())
    while T:
        n = int(input())
        print(getMinSizeSquareSum(n))
        T -= 1

main()
