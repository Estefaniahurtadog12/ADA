def leer_datos(datos):
    for line in iter(sys.stdin.readline, ''):
        n, c = map(int, line.split()[:2])
        val = list(map(int, sys.stdin.readline().split()))
        datos.append((n, c, val))
    return datos

def calcular_resultado(n, c, val):
    # Inicializar la matriz memo con valores negativos
    memo = [[-float("inf"), -float("inf")] for _ in range(n)]
    for pos in range(n - 1, -1, -1):
        for has in range(2):
            if pos == n - 1:
                memo[pos][has] = val[pos] if has else 0
            else:
                if has:
                    memo[pos][has] = max(val[pos] + memo[pos + 1][0], memo[pos + 1][has])
                else:
                    memo[pos][has] = max(memo[pos + 1][1] - val[pos] - c, memo[pos + 1][0])
            
    return memo[0][0]

def main():
    datos = []
    for n, c, val in leer_datos(datos):
        resultado = calcular_resultado(n, c, val)
        print(resultado)

main()
