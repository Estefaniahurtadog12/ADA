from sys import stdin, setrecursionlimit

A, k = None, None

def phi(n, c, mem):
    ans, key = None, (n,c)
    if key in mem: ans = mem[key]
    else:
        if n == len(A): ans = 0
        elif c == 0: ans = max(phi(n+1, c, mem), phi(n+1, 1, mem)-A[n])
        else: ans = max(phi(n+1, c, mem), phi(n+1, 0, mem)+(A[n]-k))
        mem[key] = ans
    return ans

def main():
    global A, k
    line = stdin.readline().strip()
    while line != "":
        _, k = list(map(int, line.split()))
        A = list(map(int, stdin.readline().split()))
        print(phi(0, 0, dict()))
        line = stdin.readline().strip()
main()