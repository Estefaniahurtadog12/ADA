import sys

def stocks(n, c, listaValores,memo):
    # memo[0] inversor no tiene acciones
    # memo[1]inversor tiene accion
    i = n - 2  #desde el segundo día hasta el primero
    inver = 1    #el inversor tiene una acción
    while i >= 0:
        if inver == 1:
            #sumando
            #si el inversor tiene una accion hay dos posibilidades
            #vender y agregar el valor actual al resultado (memo[0]) o no vender y mantener el valor anterior (memo[1])
            #se toma  la opcion que maximiza
            memo[inver] = max(listaValores[i] + memo[0], memo[inver])
            inver = 0  #inversor sin acciones
        else:
            #restando
            #inversor no tiene acciones tiene igualemnte dos posibilidades
            #compra una accion, restando el costo de c, de lo que esta en memo[1] o no comprar  y mantener el valor de memo[0]
            memo[inver] = max(memo[1] - listaValores[i] - c, memo[0])
            inver = 1  #inversor tiene una accion
            i -= 1   #dia anterior

    return memo[0]  #máxima ganancia (inversor sin acciones)

def main():
    datos = []
    for line in iter(sys.stdin.readline, ''):  
        n, c = map(int, line.split()[:2])
        listaValores = list(map(int, sys.stdin.readline().split()))
        memo = {0: 0, 1: listaValores[n - 1]}
        datos.append((n, c, listaValores))

    for n, c, listaValores in datos:
        resultado = stocks(n, c, listaValores,memo)
        print(resultado)
main()

