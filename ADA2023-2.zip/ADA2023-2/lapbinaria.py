from sys import stdin

def bin(x, y):
    
    lento,maxVueltas = 1, y
    
    #vuelta en la que el piloto más lento lo rezagan
    while lento < maxVueltas:
        #encontrar mitad
        mid = (lento + maxVueltas) // 2

        vueltasMaxMid = mid * x
        vueltasMinMid = (mid - 1) * y
        # Si el lento no ha alcanzado al más rápido, rango se mueve hacia la izquierda
        if vueltasMaxMid <= vueltasMinMid:
            maxVueltas = mid
        # Si el lento ha superado al rapido, se ajusta el rango hacia la derecha
        else:
            lento = mid + 1
    # numero de vuelta en la que el mas lento es rezagado
    return lento

def lectura():
    valores = [] #almacenar en una lista todos los valores
    entrada = stdin.readline().strip() # lectura de datos en un archivo
    while entrada:
        x, y = map(int, entrada.split()) #lectura de ambos valores x y y
        valores.append((x, y)) # agrego estos valores a mi lista
        entrada = stdin.readline().strip() #leo hasta el ultimo caso, donde entrada no tenga nada
    return valores

def main():
    valores = lectura()
    for x, y in valores:
        res = bin(x, y)
        print(res)
main()
