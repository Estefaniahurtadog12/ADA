import math
import sys

def rezagado(x, y):
    # aplicar techo 
    #entrada 1 (10/10-1)=1,1 ---> aplicamos techo =2
    #entrada 2 (8/8-4)=2 ---> aplicamos techo =2
    #entrada 3 (7/7-5)=3.5 ---> aplicamos techo =4
    #entrada 4 (7109/7109-6875)=30.38 ---> aplicamos techo =31
    return math.ceil(y / (y - x))

def leer_datos():
    valores = []
    entrada = sys.stdin.readline().strip()
    while entrada:
        x, y = map(int, entrada.split())
        valores.append((x, y))
        entrada = sys.stdin.readline().strip()
    return valores

def main():
    valores = leer_datos()
    for x, y in valores:
        #valores estan en la lista que creamos vacia y fuimos agregando los datos de cada entrada
        result = rezagado(x, y)
        print(result)
main()
