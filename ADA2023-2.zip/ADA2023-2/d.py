'''def main():
    global T,A
    line = stdin.readline()
    print(line)
    while len(line)!=0:
        if len(line)==1: line=stdin.readline()
        T,n,A = int(line),int(stdin.readline()),list()
        while len(A)!=n:
            x = stdin.readline().split()
            A.append((float(x[0]), float(x[1])))
            ans = solve()
            if ans[0] < 0.0: print('The cheater cannot win.')
            else: print('The cheater can win by {0} seconds with r = {1:.2f}km and k = {2:.2f}km.'.format(ans[0], ans[1], ans[2]))
            line = stdin.readline()'''

from sys import stdin

def main():
    line = stdin.readline()
    while len(line.strip()) != 0:
        t = int(line)
        n = int(stdin.readline().strip())
        speeds = []
        for _ in range(n):
            speeds.append(tuple(map(float, stdin.readline().split())))
        cheater_speeds = speeds.pop()
        max_time_difference = 0
        best_r = 0
        best_k = 0
        for r in range(t * 1000 + 1):
            r /= 1000
            k = t - r
            cheater_time = r / cheater_speeds[0] + k / cheater_speeds[1]
            min_time = float('inf')
            for speed in speeds:
                time = r / speed[0] + k / speed[1]
                min_time = min(min_time, time)
            time_difference = min_time - cheater_time
            if time_difference > max_time_difference:
                max_time_difference = time_difference
                best_r = r
                best_k = k
        if max_time_difference > 0:
            print('The cheater can win by {0:.0f} seconds with r = {1:.2f}km and k = {2:.2f}km.'.format(max_time_difference * 3600, best_r, best_k))
        else:
            print('The cheater cannot win.')
        line = stdin.readline()
        line = stdin.readline()

if __name__ == '__main__':
    main()
